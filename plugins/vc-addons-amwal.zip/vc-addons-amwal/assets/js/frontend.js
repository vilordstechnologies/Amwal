var amwal = amwal || {},
	amwalShortCode = amwalShortCode || {};
(function ($) {
	'use strict';

	$(function () {

		servicesCarousel();
		contactsCarousel();
		planningCarousel();
		testimonialsCarousel();
		postsCarousel();
		portfoliosCarousel();
		clientsCarousel();
		teamsCarousel();
		lineCharts();
		barCharts();
		doughnutCharts();
		polarsCharts();
		amwalMaps();
		aboutsCarousel();

		/*Couterup*/
		$('.amwal-counter .counter').counterUp();

		//Section Parallax
		var $parallaxsRow = $('.vc_row.parallax');
		for (var i = 0; i < $parallaxsRow.length; i++) {
			$($parallaxsRow[i]).parallax('50%', 0.6);
		}

		/**
		 * Services Carousel
		 */

		function servicesCarousel() {
			if (amwalShortCode.length === 0 || typeof amwalShortCode.servicesCarousel === 'undefined') {
				return;
			}
			$.each(amwalShortCode.servicesCarousel, function (id, serviceData) {
				if (serviceData.iscarousel == 1) {
					$(document.getElementById(id)).owlCarousel({
						items            : serviceData.number,
						navigation       : serviceData.navigation,
						autoPlay         : serviceData.autoplay,
						pagination       : serviceData.pagination !== 'yes',
						navigationText   : ['<span class="fa fa-angle-left"></span>', '<span class="fa fa-angle-right"></span>'],
						paginationSpeed  : 1000,
						itemsDesktop     : [1200, 3],
						itemsDesktopSmall: [992, 2],
						itemsMobile      : [480, 1]
					});
				}

			});
		}


		/**
		 * Contacts Carousel
		 */

		function contactsCarousel() {
			if (amwalShortCode.length === 0 || typeof amwalShortCode.contactsCarousel === 'undefined') {
				return;
			}
			$.each(amwalShortCode.contactsCarousel, function (id, contactData) {

				if (contactData.iscarousel == 1) {
					$(document.getElementById(id)).owlCarousel({
						items            : contactData.number,
						navigation       : false,
						autoPlay         : contactData.autoplay,
						pagination       : contactData.pagination !== 'yes',
						paginationSpeed  : 1000,
						itemsDesktopSmall: [992, 3],
						itemsTablet      : [768, 2],
						itemsMobile      : [480, 1]
					});
				}

			});
		}


		/**
		 * Abouts Carousel
		 */

		function aboutsCarousel() {
			if (amwalShortCode.length === 0 || typeof amwalShortCode.aboutsCarousel === 'undefined') {
				return;
			}
			$.each(amwalShortCode.aboutsCarousel, function (id, aboutData) {

				var $main1 = $(document.getElementById(id)).find('.owl-abouts-img-list'),
					$main2 = $(document.getElementById(id)).find('.owl-abouts-content-list');

				$main1.owlCarousel({
					singleItem           : true,
					slideSpeed           : 1000,
					navigation           : false,
					autoPlay             : aboutData.autoplay,
					pagination           : aboutData.pagination !== 'yes',
					afterAction          : syncPosition,
					responsiveRefreshRate: 200
				});


				$main2.owlCarousel({
					singleItem           : true,
					autoPlay             : false,
					pagination           : false,
					navigation           : false,
					responsiveRefreshRate: 100,
					mouseDrag            : false,
					touchDrag            : false,
					afterInit            : function (el) {
						el.find('.owl-item').eq(0).addClass('synced');
					}
				});

				function syncPosition() {
					/*jshint validthis: true */
					var current = this.currentItem;
					$main2.find('.owl-item').removeClass('synced').eq(current).addClass('synced');
					if ($main2.data('owlCarousel') !== undefined) {
						center(current);
					}
				}

				function center(number) {
					var thumbsvisible = $main2.data('owlCarousel').owl.visibleItems,
						num = number,
						found = false;

					for (var i in thumbsvisible) {
						if (num === thumbsvisible[i]) {
							found = true;
						}
					}

					if (found === false) {
						if (num > thumbsvisible[thumbsvisible.length - 1]) {
							$main2.trigger('owl.goTo', num - thumbsvisible.length + 1);
						} else {
							if (num - 1 === -1) {
								num = 0;
							}
							$main2.trigger('owl.goTo', num);
						}
					} else if (num === thumbsvisible[thumbsvisible.length - 1]) {
						$main2.trigger('owl.goTo', thumbsvisible[1]);
					} else if (num === thumbsvisible[0]) {
						$main2.trigger('owl.goTo', num - 1);
					}
				}

			});
		}


		/**
		 * Planning Steps Carousel
		 */

		function planningCarousel() {
			if (amwalShortCode.length === 0 || typeof amwalShortCode.planningCarousel === 'undefined') {
				return;
			}
			$.each(amwalShortCode.planningCarousel, function (id, planningData) {
				$(document.getElementById(id)).owlCarousel({
					items            : planningData.number,
					navigation       : planningData.navigation,
					autoPlay         : planningData.autoplay,
					pagination       : true,
					paginationSpeed  : 1000,
					itemsDesktopSmall: [979, 3],
					itemsTablet      : [768, 2],
					itemsMobile      : [479, 1],
					navigationText   : ['<span class="fa fa-angle-left"></span>', '<span class="fa fa-angle-right"></span>']
				});
			});
		}

		/**
		 * Line Charts Carousel
		 */

		function lineCharts() {
			if (amwalShortCode.length === 0 || typeof amwalShortCode.lineCharts === 'undefined') {
				return;
			}
			$.each(amwalShortCode.lineCharts, function (id, chartsData) {
				var ctx = $(document.getElementById(id));

				new Chart(ctx, {
					type   : 'line',
					data   : {
						labels  : chartsData.label,
						datasets: chartsData.datasets
					},
					options: {
						scales: {
							yAxes: [{
								ticks: {
									beginAtZero: true
								}
							}]
						},
						title : {
							display: true,
							text   : chartsData.title

						}
					}
				});
			});
		}

		/**
		 * Line Charts
		 */

		function barCharts() {
			if (amwalShortCode.length === 0 || typeof amwalShortCode.barCharts === 'undefined') {
				return;
			}
			$.each(amwalShortCode.barCharts, function (id, chartsData) {
				var ctx = $(document.getElementById(id));
				new Chart(ctx, {
					type   : 'bar',
					data   : {
						labels  : chartsData.label,
						datasets: chartsData.datasets
					},
					options: {
						scales: {
							yAxes: [{
								ticks: {
									beginAtZero: true
								}
							}]
						}
					}
				});
			});
		}


		/**
		 * Doughnut Charts
		 */

		function doughnutCharts() {
			if (amwalShortCode.length === 0 || typeof amwalShortCode.doughnutCharts === 'undefined') {
				return;
			}
			$.each(amwalShortCode.doughnutCharts, function (id, doughnutData) {
				var ctx = $(document.getElementById(id));
				new Chart(ctx, {
					type   : doughnutData.type,
					data   : {
						labels  : doughnutData.label,
						datasets: [
							{
								data                : doughnutData.data,
								backgroundColor     : doughnutData.bgcolor,
								hoverBackgroundColor: doughnutData.hoverbgcolor
							}]
					},
					options: {}
				});
			});
		}

		/**
		 * Polar Area Charts
		 */

		function polarsCharts() {
			if (amwalShortCode.length === 0 || typeof amwalShortCode.polarCharts === 'undefined') {
				return;
			}
			$.each(amwalShortCode.polarCharts, function (id, polarData) {
				var ctx = $(document.getElementById(id));
				new Chart(ctx, {
					type   : 'polarArea',
					data   : {
						labels  : polarData.label,
						datasets: [
							{
								data           : polarData.data,
								backgroundColor: polarData.bgcolor,
								label          : polarData.title
							}
						]
					},
					options: {}
				});
			});
		}

		/**
		 * Testimonials Carousel
		 */

		function testimonialsCarousel() {
			if (amwalShortCode.length === 0 || typeof amwalShortCode.testimonialsCarousel === 'undefined') {
				return;
			}
			$.each(amwalShortCode.testimonialsCarousel, function (id, testimonialData) {
				$(document.getElementById(id)).owlCarousel({
					singleItem     : true,
					navigation     : false,
					autoPlay       : testimonialData.autoplay,
					pagination     : testimonialData.pagination !== 'yes',
					slideSpeed     : 800,
					paginationSpeed: 1000,
					itemsTablet    : [768, 3],
					itemsMobile    : [320, 1]
				});
			});
		}

		/**
		 * Teams Carousel
		 */

		function teamsCarousel() {
			if (amwalShortCode.length === 0 || typeof amwalShortCode.teamsCarousel === 'undefined') {
				return;
			}
			$.each(amwalShortCode.teamsCarousel, function (id, teamData) {

				if (teamData.iscarousel == 1) {
					$(document.getElementById(id)).owlCarousel({
						items            : teamData.number,
						navigation       : teamData.navigation,
						autoPlay         : teamData.autoplay,
						pagination       : true,
						slideSpeed       : 800,
						paginationSpeed  : 1000,
						navigationText   : ['<span class="fa fa-angle-left"></span>', '<span class="fa fa-angle-right"></span>'],
						itemsDesktopSmall: [991, 3],
						itemsTablet      : [768, 2],
						itemsMobile      : [479, 1]
					});
				}
			});
		}


		/**
		 * Posts Carousel
		 */

		function postsCarousel() {
			if (amwalShortCode.length === 0 || typeof amwalShortCode.postsCarousel === 'undefined') {
				return;
			}
			$.each(amwalShortCode.postsCarousel, function (id, postData) {

				if (postData.iscarousel == 1) {
					$(document.getElementById(id)).owlCarousel({
						items          : postData.number,
						navigation     : false,
						autoPlay       : postData.autoplay,
						pagination     : postData.pagination !== 'yes',
						slideSpeed     : 800,
						paginationSpeed: 1000,
						itemsDesktop   : [1199, 3],
						itemsTablet    : [992, 2],
						itemsMobile    : [650, 1]
					});
				}

			});
		}


		/**
		 * Posts Carousel
		 */

		function portfoliosCarousel() {
			if (amwalShortCode.length === 0 || typeof amwalShortCode.portfoliosCarousel === 'undefined') {
				return;
			}
			$.each(amwalShortCode.portfoliosCarousel, function (id, portfolioData) {
				if (portfolioData.iscarousel == 1) {
					$(document.getElementById(id)).owlCarousel({
						items          : portfolioData.number,
						navigation     : false,
						autoPlay       : portfolioData.autoplay,
						pagination     : portfolioData.pagination !== 'yes',
						slideSpeed     : 800,
						paginationSpeed: 1000,
						itemsDesktop   : [1199, 3],
						itemsTablet    : [768, 2],
						itemsMobile    : [480, 1]
					});
				}
			});
		}


		/**
		 * Clients Carousel
		 */

		function clientsCarousel() {
			if (amwalShortCode.length === 0 || typeof amwalShortCode.clientsCarousel === 'undefined') {
				return;
			}
			$.each(amwalShortCode.clientsCarousel, function (id, clientData) {
				if (clientData.iscarousel == 1) {
					$(document.getElementById(id)).owlCarousel({
						items          : 4,
						navigation     : true,
						autoPlay       : clientData.autoplay,
						pagination     : true,
						slideSpeed     : 800,
						paginationSpeed: 1000,
						navigationText : ['<span class="fa fa-angle-left"></span>', '<span class="fa fa-angle-right"></span>'],
						itemsTablet    : [768, 2],
						itemsMobile    : [480, 1]
					});
				}
			});
		}

		/**
		 * Init Google maps
		 */
		function amwalMaps() {
			if (amwalShortCode.length === 0 || typeof amwalShortCode.map === 'undefined') {
				return;
			}


			var mapOptions = {
				scrollwheel       : false,
				draggable         : true,
				zoom              : 10,
				mapTypeId         : google.maps.MapTypeId.ROADMAP,
				panControl        : false,
				zoomControl       : true,
				zoomControlOptions: {
					style: google.maps.ZoomControlStyle.SMALL
				},
				scaleControl      : false,
				streetViewControl : false

			};

			var bounds = new google.maps.LatLngBounds();
			var infoWindow = new google.maps.InfoWindow();

			var style1 = [
				{
					'featureType': 'administrative.country',
					'elementType': 'labels.icon',
					'stylers'    : [
						{
							'visibility': 'on'
						}
					]
				}
			];

			var style2 = [
				{
					'featureType': 'administrative',
					'elementType': 'labels.text.fill',
					'stylers'    : [{'color': '#444444'}]
				},
				{
					'featureType': 'administrative.country',
					'elementType': 'all',
					'stylers'    : [{'visibility': 'on'}]
				},
				{
					'featureType': 'administrative.province',
					'elementType': 'all',
					'stylers'    : [{'visibility': 'off'}]
				},
				{
					'featureType': 'administrative.locality',
					'elementType': 'all',
					'stylers'    : [{'visibility': 'off'}]
				},
				{
					'featureType': 'administrative.neighborhood',
					'elementType': 'all',
					'stylers'    : [{'visibility': 'off'}]
				},
				{
					'featureType': 'landscape',
					'elementType': 'all',
					'stylers'    : [{'color': '#f2f2f2'}, {'visibility': 'on'}]
				},
				{
					'featureType': 'landscape.natural',
					'elementType': 'geometry.fill',
					'stylers'    : [{'visibility': 'on'}, {'saturation': '17'}]
				},
				{
					'featureType': 'poi',
					'elementType': 'all',
					'stylers'    : [{'visibility': 'off'}]
				},
				{
					'featureType': 'road',
					'elementType': 'all',
					'stylers'    : [{'saturation': -100}, {'lightness': 45}, {'visibility': 'off'}]
				},
				{
					'featureType': 'road.highway',
					'elementType': 'all',
					'stylers'    : [{'visibility': 'simplified'}]
				},
				{
					'featureType': 'road.highway',
					'elementType': 'labels',
					'stylers'    : [{'visibility': 'off'}]
				},
				{
					'featureType': 'road.arterial',
					'elementType': 'labels.icon',
					'stylers'    : [{'visibility': 'off'}]
				},
				{
					'featureType': 'transit',
					'elementType': 'all',
					'stylers'    : [{'visibility': 'off'}]
				},
				{
					'featureType': 'water',
					'elementType': 'all',
					'stylers'    : [{'color': '#66c9f0'}, {'visibility': 'on'}]
				}
			];

			var styles, customMap;

			$.each(amwalShortCode.map, function (id, mapData) {
				if (mapData.style == '1') {
					styles = style1;
				} else {
					styles = style2;
				}

				customMap = new google.maps.StyledMapType(styles,
					{name: 'Styled Map'}
				);

				if (mapData.number > 1) {
					mutiMaps(infoWindow, bounds, mapOptions, mapData, id, styles, customMap);
				} else {
					singleMap(mapOptions, mapData, id, styles, customMap);
				}

			});
		}

		function singleMap(mapOptions, mapData, id, styles, customMap) {
			var map,
				marker,
				location = new google.maps.LatLng(mapData.lat, mapData.lng);


			// Update map options
			mapOptions.zoom = parseInt(mapData.zoom, 10);
			mapOptions.center = location;
			mapOptions.mapTypeControlOptions = {
				mapTypeIds: [google.maps.MapTypeId.ROADMAP]
			};

			// Init map
			map = new google.maps.Map(document.getElementById(id), mapOptions);

			// Create marker options
			var markerOptions = {
				map     : map,
				position: location
			};
			if (mapData.marker) {
				markerOptions.icon = {
					url: mapData.marker
				};
			}

			map.mapTypes.set('map_style', customMap);
			map.setMapTypeId('map_style');

			// Init marker
			marker = new google.maps.Marker(markerOptions);

			if (mapData.info) {
				var infoWindow = new google.maps.InfoWindow({
					content : '<div class="info-box amwal-map">' + mapData.info + '</div>',
					maxWidth: 600
				});

				google.maps.event.addListener(marker, 'click', function () {
					infoWindow.open(map, marker);
				});
			}
		}

		function mutiMaps(infoWindow, bounds, mapOptions, mapData, id, styles, customMap) {

			// Display a map on the page
			mapOptions.zoom = parseInt(mapData.zoom, 10);
			mapOptions.mapTypeControlOptions = {
				mapTypeIds: [google.maps.MapTypeId.ROADMAP]
			};

			var map = new google.maps.Map(document.getElementById(id), mapOptions);
			map.mapTypes.set('map_style', customMap);
			map.setMapTypeId('map_style');
			for (var i = 0; i < mapData.number; i++) {
				var lats = mapData.lat,
					lng = mapData.lng,
					info = mapData.info;

				var position = new google.maps.LatLng(lats[i], lng[i]);
				bounds.extend(position);

				// Create marker options
				var markerOptions = {
					map     : map,
					position: position
				};
				if (mapData.marker) {
					markerOptions.icon = {
						url: mapData.marker
					};
				}

				// Init marker
				var marker = new google.maps.Marker(markerOptions);

				// Allow each marker to have an info window
				googleMaps(infoWindow, map, marker, info[i]);

				// Automatically center the map fitting all markers on the screen
				map.fitBounds(bounds);
			}
		}

		function googleMaps(infoWindow, map, marker, info) {
			google.maps.event.addListener(marker, 'click', function () {
				infoWindow.setContent(info);
				infoWindow.open(map, marker);
			});
		}

		// Init countdown js
		$('.amwal-coming-soon').find('.sale-price-date').each(function () {
			$(this).countdown($(this).attr('data-date'), function (event) {
				var day = event.strftime('%D'),
					output = '',
					i = 0;
				for (i = 0; i < day.length; i++) {
					output += '<span>' + day[i] + '</span>';
				}
				$(this).find('.day').html(output);

				var hour = event.strftime('%H');
				output = '';
				for (i = 0; i < hour.length; i++) {
					output += '<span>' + hour[i] + '</span>';
				}
				$(this).find('.hour').html(output);

				var minu = event.strftime('%M');
				output = '';
				for (i = 0; i < minu.length; i++) {
					output += '<span>' + minu[i] + '</span>';
				}
				$(this).find('.minu').html(output);

				var secs = event.strftime('%S');
				output = '';
				for (i = 0; i < secs.length; i++) {
					output += '<span>' + secs[i] + '</span>';
				}
				$(this).find('.secs').html(output);
			});
		});


	});
})(jQuery);
