<?php

/**
 * Define theme shortcodes
 *
 * @package amwal
 */
class Amwal_Shortcodes {
	/**
	 * Store variables for js
	 *
	 * @var array
	 */
	public $l10n = array();

	public $maps = array();

	public $api_key = '';

	/**
	 * Check if WooCommerce plugin is actived or not
	 *
	 * @var bool
	 */
	private $wc_actived = false;

	public $services = array();

	public $contacts = array();

	public $steps = array();

	public $lines = array();

	public $bars = array();

	public $abouts_content = array();

	public $abouts_img = array();

	/**
	 * Construction
	 *
	 * @return Amwal_Shortcodes
	 */
	function __construct() {
		$this->wc_actived = function_exists( 'is_woocommerce' );

		$shortcodes = array(
			'section_title',
			'job_list',
			'icon_box',
			'counter',
			'clients',
			'services',
			'service',
			'contacts_info',
			'contact_info',
			'planning_steps',
			'planning_step',
			'abouts_carousel',
			'about_carousel',
			'line_charts',
			'line_chart',
			'bar_charts',
			'bar_chart',
			'pie_doughnut',
			'polar_area',
			'portfolio',
			'testimonials',
			'contact_form',
			'info_box',
			'newsletter',
			'cta',
			'pricing',
			'posts',
			'team',
			'image_box',
			'video',
			'company_history',
			'portfolio_info',
			'portfolio_advisors',
			'about',
			'about_2',
			'coming_soon',
			'socials',
			'partner',
			'multimaps',
			'gmap'
		);

		foreach ( $shortcodes as $shortcode ) {
			add_shortcode( 'amwal_' . $shortcode, array( $this, $shortcode ) );
		}

		add_action( 'wp_enqueue_scripts', array( $this, 'header' ) );
		add_action( 'wp_footer', array( $this, 'footer' ) );
	}

	/**
	 * Load custom js in footer
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function footer() {

		$key = '';

		// Load Google maps only when needed
		if ( isset( $this->l10n['map'] ) ) {
			echo '<script>if ( typeof google !== "object" || typeof google.maps !== "object" )
				document.write(\'<script src="//maps.google.com/maps/api/js?sensor=false&key=' . $this->api_key . '"><\/script>\')</script>';
		}

		wp_register_script('amwal-addons-plugins', AMWAL_ADDONS_URL . '/assets/js/plugins.js', array(), '1.0.0');
		wp_enqueue_script('amwal-shortcodes', AMWAL_ADDONS_URL . '/assets/js/frontend.js', array('jquery', 'amwal-addons-plugins'), '1.0.0', true);


		wp_localize_script( 'amwal', 'amwalShortCode', $this->l10n );
	}

	/**
	 * Load CSS in header
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function header() {
		wp_enqueue_style( 'amwal-shortcodes', AMWAL_ADDONS_URL . '/assets/css/frontend.css', array(), '1.0.0' );

		$color_scheme_option = '';
		if( function_exists( 'amwal_get_option' ) ) {
			$color_scheme_option = amwal_get_option( 'color_scheme' );
			$color = explode( '|', $color_scheme_option);

			$main_color = $color[0];
			$sub_color = $color[1];

			if( intval( amwal_get_option( 'custom_color_scheme' ) ) ) {
				$main_color = amwal_get_option( 'custom_color_1' );
				$sub_color = amwal_get_option( 'custom_color_2' );
			}
		} else {
			$color_scheme_option = get_theme_mod( 'color_scheme', '' );
			$color = explode( '|', $color_scheme_option);

			$main_color = $color[0];
			$sub_color = $color[1];

			if( intval( get_theme_mod( 'custom_color_scheme', '' ) ) ) {
				$color_scheme_option = get_theme_mod( 'custom_color', '' );
				$main_color = amwal_get_option( 'custom_color_1' );
				$sub_color = amwal_get_option( 'custom_color_2' );
			}
		}

		// Don't do anything if the default color scheme is selected.
		if ( $main_color != '0' && $sub_color != '0' ) {
			$css = $this->amwal_get_color_scheme_css( $main_color, $sub_color );
			wp_add_inline_style( 'amwal-shortcodes', $css );
		}
	}

	/**
	 * Get instagram shortcode
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function section_title( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'         => '1',
				'title'         => '',
				'subtitle'      => '',
				'light_skin'    => '',
				'text_position' => 'left',
				'el_class'      => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( $atts['style'] ) {
			$css_class[] = 'title-style-' . $atts['style'];
		}

		$output = array();

		if ( $atts['title'] ) {
			$output[] = sprintf( '<span class="top-title"></span><h2 class="title">%s</h2>', $atts['title'] );
		}

		if ( $atts['style'] == '1' ) {

			if ( $atts['light_skin'] ) {
				$css_class[] = ' light-skin';
			}

			if ( $atts['text_position'] ) {
				$css_class[] = ' text-' . $atts['text_position'];
			}

			if ( $atts['subtitle'] ) {
				$output[] = sprintf( '<div class="sub-title">%s</div><span class="bottom-title"></span>', $atts['subtitle'] );
			}

			if ( $content ) {
				if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
					$content = wpb_js_remove_wpautop( $content, true );
				}
				$output[] = sprintf( '<div class="desc">%s</div>', $content );
			}
		}

		return sprintf(
			'<div class="section-title title-block %s">%s</div>',
			esc_attr( implode( '', $css_class ) ),
			implode( '', $output )
		);
	}

	/**
	 * Map shortcode
	 *
	 * @since 1.0.0
	 * Display jod list shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */

	function job_list( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title'       => '',
				'number' 	  => '',
				'el_class'    => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		$title = '';

		if ( $atts['title'] ) {
			$title = sprintf( '<h2>%s</h2>', $atts['title'] );
		}

		$output = array();

		$output[] = sprintf(
			'<div class="row job-header">
				<div class="field col-md-2 col-sm-2 col-xs-6">%s</div>
				<div class="field col-md-3 col-sm-3 col-xs-6">%s</div>
				<div class="field col-md-3 col-sm-3 hidden-xs">%s</div>
				<div class="field col-md-2 col-sm-2 hidden-xs">%s</div>
				<div class="field col-md-2 col-sm-2 hidden-xs">%s</div>
			</div>',
			esc_html__( 'Job Code', 'amwal' ),
			esc_html__( 'Job Title', 'amwal'),
			esc_html__( 'Location', 'amwal' ),
			esc_html__( 'Department', 'amwal' ),
			esc_html__( 'Job Close', 'amwal' )
		);

		$jobs = new WP_Query(
			array(
				'posts_per_page'      => $atts['number'],
				'ignore_sticky_posts' => true,
				'post_type'           => 'job_listing',
				'paged'               => max( 1, get_query_var( 'paged' ) )
			)
		);

		if ( $jobs->have_posts() ) :

			while ( $jobs->have_posts() ) : $jobs->the_post();
				$department = get_post_meta( get_the_ID(), 'department', true );
				$date = get_post_meta( get_the_ID(), '_job_expires', true );
				$responsibility = get_post_meta( get_the_ID(), 'responsibility', true );
				$code = get_post_meta( get_the_ID(), 'code', true );
				$id = get_the_ID();
				$chara = substr( $department, 0, 3 );

				if ( empty( $code ) ) {
					$code = $chara . $id;
				}

				$class = '';
				if ( get_post_meta( get_the_ID(), 'open', true ) ) {
					$class = 'active';
				}

				$output[] = sprintf(
					'<div class="job-body %s">
						<div class="row job-info">
							<div class="field col-md-2 col-sm-2 col-xs-6">
								<span class="job-code">%s</span>
							</div>
							<div class="field col-md-3 col-sm-3 col-xs-6">
								<h3>%s</h3>
							</div>
							<div class="field col-md-3 col-sm-3 hidden-xs">
								<span>%s</span>
							</div>
							<div class="field col-md-2 col-sm-2 hidden-xs">
								<span>%s</span>
							</div>
							<div class="field col-md-2 col-sm-2 hidden-xs">
								<span>%s</span>
							</div>
						</div>
						<div class="job-desc">
							<h3>%s</h3>
							%s
							<p>%s</p>
							<a href="%s" class="btn-default">%s</a>
						</div>
					</div>',
					$class,
					$code,
					get_the_title(),
					get_the_job_location(),
					$department,
					$date,
					esc_html__( 'Responsibility', 'amwal' ),
					wpautop( $responsibility ),
					get_the_content(),
					esc_url( get_the_permalink() ),
					esc_html__( 'Job Details', 'amwal' )
				);
			endwhile;
		endif;
		wp_reset_postdata();

		return sprintf(
			'<div class="joblist %s">
				%s
				%s
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			$title,
			implode( '', $output )
		);
	}

	/**
	 * Map shortcode
	 *
	 * @since 1.0.0
	 * Display icon box shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function icon_box( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'       => '1',
				'text_center' => '',
				'icon'        => '',
				'title'       => '',
				'link'        => '',
				'el_class'    => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( $atts['style'] ) {
			$css_class[] = 'box-style-' . $atts['style'];
		}

		if ( $atts['style'] == '1' ) {
			if ( $atts['text_center'] ) {
				$css_class[] = ' text-center';
			}
		}

		$output = array();

		$link = array_filter( vc_build_link( $atts['link'] ) );

		if ( $atts['icon'] ) {

			if ( ! empty( $link ) ) {
				$output[] = sprintf(
					'<a href="%s" class="title-link">
						<span class="b-icon %s"></span>
					</a>',
					! empty ( $link['url'] ) ? esc_url( $link['url'] ) : '',
					$atts['icon']
				);
			} else {
				$output[] = sprintf( ' <span class="b-icon %s"></span>', $atts['icon'] );
			}
		}

		if ( $atts['title'] ) {

			if ( ! empty( $link ) ) {
				$output[] = sprintf(
					'<h4 class="title"><a href="%s" class="title-link">
						%s
					</a></h4>',
					! empty ( $link['url'] ) ? esc_url( $link['url'] ) : '',
					$atts['title']
				);
			} else {
				$output[] = sprintf( '<h4 class="title">%s</h4>', $atts['title'] );
			}
		}

		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}
			$output[] = sprintf( '<div class="desc">%s</div>', $content );
		}

		return sprintf(
			'<div class="amwal-icon-box %s">
				%s
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}

	function info_box( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'      => '1',
				'between'    => esc_html__( 'Mon-Sat|10.00am - 6.00p.m', 'amwal' ),
				'final'      => esc_html__( 'Sun|11.30am - 3.00p.m', 'amwal' ),
				'phone'      => '',
				'email'      => '',
				'light_skin' => '',
				'el_class'   => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( $atts['style'] ) {
			$css_class[] = 'info-style-' . $atts['style'];
		}

		if ( $atts['light_skin'] ) {
			$css_class[] = 'light-text';
		}

		$output = array();

		$col_class = 'col-md-6 col-sm-12';

		if ( $atts['style'] == '2' ) {
			$col_class = 'col-md-12 col-sm-12';
		}

		if ( $atts['between'] ) {
			$between = explode( '|', $atts['between'] );
			if ( sizeof( $between ) > 1 ) {
				$output[] = sprintf(
					'<div class="%s">
						<div class="info-content info-between">
							<span class="info-icon icon-clock"></span>
							<div class="info-title-bw">
								<span>%s</span>
								%s
							</div>
						</div>
					</div>',
					$col_class,
					array_shift( $between ),
					implode( ' ', $between )
				);
			} else {
				$output[] = sprintf(
					'<div class="%s">
						<div class="info-content info-between">
							<span class="info-icon icon-clock"></span>
							<div class="info-title-bw">
								%s
							</div>
						</div>
					</div>',
					$col_class,
					$atts['between']
				);
			}
		}

		if ( $atts['final'] ) {
			$final = explode( '|', $atts['final'] );
			if ( sizeof( $final ) > 1 ) {
				$output[] = sprintf(
					'<div class="%s">
						<div class="info-content info-final">
							<span>%s</span>
							%s
						</div>
					</div>',
					$col_class,
					array_shift( $final ),
					implode( ' ', $final )
				);
			} else {
				$output[] = sprintf(
					'<div class="%s">
						<div class="info-content info-final">%s</div>
					</div>',
					$col_class,
					$atts['final']
				);
			}
		}

		if ( $atts['phone'] ) {
			$output[] = sprintf(
				'<div class="%s">
					<div class="info-content info-phone">
						<span class="info-icon icon-phone"></span>
						%s
					</div>
				</div>',
				$col_class,
				$atts['phone']
			);
		}

		if ( $atts['email'] ) {
			$output[] = sprintf(
				'<div class="%s">
					<div class="info-content info-email">
						<span class="info-icon icon-envelop"></span>
						%s
					</div>
				</div>',
				$col_class,
				$atts['email']
			);
		}

		return sprintf(
			'<div class="amwal-info-box %s"><div class="row">%s</div></div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}

	/**
	 * Map shortcode
	 *
	 * @since 1.0.0
	 * Display Counter shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function counter( $atts ) {
		$atts = shortcode_atts(
			array(
				'icon'      => '',
				'number'    => '',
				'desc'      => '',
				'dark_text' => '',
				'el_class'  => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( $atts['dark_text'] ) {
			$css_class[] = 'dark-text';
		}

		$output = array();

		if ( $atts['icon'] ) {
			$output[] = sprintf( ' <span class="b-icon %s"></span>', $atts['icon'] );
		}

		if ( $atts['number'] ) {
			$output[] = sprintf( '<span class="counter">%s</span>', $atts['number'] );
		}

		if ( $atts['desc'] ) {
			$output[] = sprintf( '<div class="desc">%s</div>', $atts['desc'] );
		}

		return sprintf(
			'<div class="amwal-counter %s">
				%s
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}


	/**
	 * Clients shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function clients( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'               => '1',
				'images'              => '',
				'image_size'          => 'full',
				'custom_links'        => '',
				'custom_links_target' => '_self',
				'hide_border'         => '',
				'autoplay'            => 0,
				'navigation'          => true,
				'pagination'          => '',
				'el_class'            => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( $atts['style'] ) {
			$css_class[] = 'clients-style-' . $atts['style'];
		}

		if ( $atts['hide_border'] ) {
			$css_class[] = 'hide-border-img';
		}

		$autoplay = intval( $atts['autoplay'] );
		if ( ! $autoplay ) {
			$autoplay = false;
		}

		$is_carousel = 1;
		if ( $atts['style'] == '1' ) {
			$is_carousel = 0;
		}

		if ( $atts['style'] == '2'){
			if( $atts['navigation'] === 'false' ) {
				$css_class[] = 'hide-navigation';
			}

			if( $atts['pagination'] === 'yes' ){
				$css_class[] = 'hide-pagination';
			}
		}

		$id                                 = uniqid( 'clients-carousel-' );
		$this->l10n['clientsCarousel'][$id] = array(
			'autoplay'   => $autoplay,
			'iscarousel' => $is_carousel
		);


		$output       = array();
		$images       = $atts['images'] ? explode( ',', $atts['images'] ) : '';
		$custom_links = '';
		if( function_exists( 'vc_value_from_safe' ) ) {
			$custom_links = vc_value_from_safe( $atts['custom_links'] );
			$custom_links = explode( ',', $custom_links );
		}

		if ( $images ) {
			$i = 0;
			foreach ( $images as $attachment_id ) {
				$image = wp_get_attachment_image_src( $attachment_id, $atts['image_size'] );
				if ( $image ) {
					$link = '';
					if ( $custom_links && isset( $custom_links[$i] ) ) {
						$link = preg_replace( '/<br \/>/iU', '', $custom_links[$i] );
						$link = 'href="' . esc_url( $link ) . '"';

					}
					$output[] = sprintf(
						'<div class="client-item col-md-3 col-sm-6 col-xs-12"><a class="image-item" %s target="%s"><img class="img-responsive partner-img" alt="%s"  src="%s"></a></div>',
						$link,
						esc_attr( $atts['custom_links_target'] ),
						esc_attr( $attachment_id ),
						esc_url( $image[0] )
					);
				}
				$i ++;
			}
		}

		return sprintf(
			'<div class="amwal-clients %s"><div class="owl-client-list row" id="%s">%s</div></div>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_attr( $id ),
			implode( ' ', $output )
		);
	}

	/**
	 * Services shortcode
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function services( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'               => '1',
				'services_view'       => '1',
				'service_transparent' => '',
				'light_text'          => '',
				'number'              => '4',
				'autoplay'            => 0,
				'padding'             => '',
				'hide_btn'            => '',
				'link'                => '',
				'pagination'          => true,
				'navigation'          => true,
				'el_class'            => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( $atts['style'] ) {
			$css_class[] = 'services-style-' . $atts['style'];
		}

		if ( $atts['style'] == '2' ) {
			if ( $atts['hide_btn'] ) {
				$css_class[] = ' service-hide-btn';
			}

			if( $atts['pagination'] === 'yes' ){
				$css_class[] = ' hide-pagination';
			}

		}

		if ( $atts['padding'] ) {
			$css_class[] = 'service-has-padding';
		}

		if ( $atts['pagination'] === 'yes' && $atts['navigation'] === 'false' ) {
			$css_class[] = 'hide-control';
		}

		$autoplay = intval( $atts['autoplay'] );

		$autoplay = $autoplay ? $autoplay : false;

		$this->services = array();
		do_shortcode( $content );

		if ( empty( $this->services ) ) {
			return '';
		}

		$output = array();

		$iscarousel = 1;

		if ( $atts['style'] == '1' ) {
			if ( $atts['services_view'] == '0' ) {
				$iscarousel  = 0;
				$css_class[] = 'view-uncarousel';
			}

			if ( $atts['services_view'] == '1' ) {
				if ( $atts['service_transparent'] ) {
					$css_class[] = 'service-transparent';
				}

				if ( $atts['light_text'] ) {
					$css_class[] = 'service-light-text';
				}

			}
		}

		$id                                  = uniqid( 'services-carousel-' );
		$this->l10n['servicesCarousel'][$id] = array(
			'autoplay'   => $autoplay,
			'pagination' => $atts['pagination'],
			'navigation' => $atts['navigation'],
			'number'     => $atts['number'],
			'iscarousel' => $iscarousel,
		);


		foreach ( $this->services as $index => $service ) {
			$output[] = $service;
		}

		$link   = array_filter( vc_build_link( $atts['link'] ) );
		$button = '';
		if ( $atts['style'] == '1' ) {
			if ( ! empty( $link ) ) {
				$button = sprintf(
					'<div class="button-link"><a href="%s" class="view-more" %s%s>%s</a></div>',
					! empty ( $link['url'] ) ? esc_url( $link['url'] ) : '',
					! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
					! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
					! empty( $link['title'] ) ? esc_html( $link['title'] ) : ''
				);

			}
		}

		return sprintf(
			'<div class="amwal-services-carousel %s">
            	<div class="owl-services-list" id="%s">
            		%s
                </div>
                %s
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_attr( $id ),
			implode( ' ', $output ),
			$button
		);
	}

	/**
	 * Service shortcode
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function service( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'image'      => '',
				'image_size' => 'full',
				'icon'       => '',
				'title'      => '',
				'link'       => '',
			), $atts
		);

		$output = array();

		$css_class = 'no-bg';
		$style     = '';
		if ( $atts['image'] ) {
			$img = wp_get_attachment_image_src( intval( $atts['image'] ), 'full' );
			if ( $img ) {
				$style     = 'style="background-image: url(' . esc_attr( $img[0] ) . ')"';
				$css_class = 'has-bg';

				$output[] = $this->get_image_src( $atts['image'], $atts['image_size'] );
			}
		}

		$output[] = sprintf( '<div class="service-bg" %s></div>', $style );

		$link = array_filter( vc_build_link( $atts['link'] ) );

		$output[] = '<div class="service-box-content">';

		if ( $atts['icon'] ) {
			$output[] = sprintf( ' <span class="b-icon %s"></span>', $atts['icon'] );
		}

		if ( $atts['title'] ) {

			if ( ! empty( $link ) ) {
				$output[] = sprintf(
					'<h4 class="title"><a href="%s" class="title-link">
						%s
					</a></h4>',
					! empty ( $link['url'] ) ? esc_url( $link['url'] ) : '',
					$atts['title']
				);
			} else {
				$output[] = sprintf( '<h4 class="title">%s</h4>', $atts['title'] );
			}
		}

		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}
			$output[] = sprintf( '<div class="desc">%s</div>', $content );
		}

		if ( ! empty( $link ) ) {
			$output[] = sprintf(
				'<a href="%s" class="view-more" %s%s>%s</a>',
				! empty ( $link['url'] ) ? esc_url( $link['url'] ) : '',
				! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
				! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
				! empty( $link['title'] ) ? esc_html( $link['title'] ) : ''
			);

		}

		$output[] = '</div>';

		$this->services[] = sprintf( '<div class="item-services %s"><div class="service-content">%s</div></div>', esc_attr( $css_class ), implode( ' ', $output ) );

		return '';
	}


	/**
	 * Service shortcode
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function image_box( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'image'      => '',
				'image_size' => 'full',
				'title'      => '',
				'el_class'   => '',
			), $atts
		);

		$output = array();

		$css_class[] = $atts['el_class'];

		$col_class = 'col-md-12 col-sm-12 col-xs-12 no-offset no-image';

		if ( $atts['image'] ) {
			$img = wp_get_attachment_image_src( intval( $atts['image'] ), 'full' );
			if ( $img ) {
				$output[] = sprintf(
					'<div class="img-box-left col-md-8 col-sm-8 col-xs-12">
						<div class="entry-image">%s</div>
					</div>',
					$this->get_image_src(
						$atts['image'], $atts['image_size']
					)
				);

				$col_class = 'img-box-right col-md-6 col-sm-6 col-xs-12 entry-content-offset';
			}
		}

		$output[] = sprintf( '<div class="%s">', $col_class );

		if ( $atts['title'] ) {
			$output[] = sprintf( '<div class="title">%s</div>', $atts['title'] );
		}

		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}
			$output[] = sprintf( '<div class="desc">%s</div>', $content );
		}

		$output[] = '</div>';

		return sprintf(
			'<div class="amwal-image-box %s">
            	<div class="row">
            		%s
                </div>
			</div>',
			esc_attr( implode( '', $css_class ) ),
			implode( ' ', $output )
		);
	}

	/**
	 * Contacts info shortcode
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function contacts_info( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'      => '1',
				'box_shadow' => '',
				'autoplay'   => 0,
				'pagination' => true,
				'el_class'   => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( $atts['style'] ) {
			$css_class[] = 'contacts-info-style-' . $atts['style'];
		}


		if ( $atts['style'] == '1' ) {
			if ( $atts['box_shadow'] ) {
				$css_class[] = 'contacts-box-shadow';
			}
		}

		$autoplay = intval( $atts['autoplay'] );

		$autoplay = $autoplay ? $autoplay : false;

		$this->contacts = array();
		do_shortcode( $content );

		if ( empty( $this->contacts ) ) {
			return '';
		}

		$output = array();
		$total  = count( $this->contacts );
		$number = 4;
		if ( ! $total ) {
			return '';
		} elseif ( $total < 4 ) {
			$number = $total;
		}

		$is_carousel = 1;
		if ( $atts['style'] == '2' ) {
			$is_carousel = 0;
		}

		$id                                  = uniqid( 'contacts-carousel-' );
		$this->l10n['contactsCarousel'][$id] = array(
			'autoplay'   => $autoplay,
			'pagination' => $atts['pagination'],
			'number'     => $number,
			'iscarousel' => $is_carousel
		);

		foreach ( $this->contacts as $index => $contact ) {
			$output[] = $contact;
		}

		return sprintf(
			'<div class="amwal-contacts-carousel %s">
            	<div class="owl-contacts-list row" id="%s">
            		%s
                </div>
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_attr( $id ),
			implode( ' ', $output )
		);
	}


	/**
	 * Contact info shortcode
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function contact_info( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title' => '',
			), $atts
		);

		$output = array();

		if ( $atts['title'] ) {

			$output[] = sprintf( '<h4 class="title">%s</h4>', $atts['title'] );
		}

		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}
			$output[] = sprintf( '<div class="desc">%s</div>', $content );
		}


		$this->contacts[] = sprintf( '<div class="item-contact col-md-3 col-sm-6 col-xs-12"><div class="contact-info">%s</div></div>', implode( ' ', $output ) );

		return '';
	}

	/**
	 * Planning Steps shortcode
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function planning_steps( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'autoplay'   => 0,
				'navigation' => true,
				'el_class'   => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];


		$autoplay = intval( $atts['autoplay'] );

		$autoplay = $autoplay ? $autoplay : false;

		$this->steps = array();
		do_shortcode( $content );

		if ( empty( $this->steps ) ) {
			return '';
		}

		$output = array();
		$total  = count( $this->steps );
		$number = 4;
		if ( ! $total ) {
			return '';
		} elseif ( $total < 4 ) {
			$number = $total;
		}

		$id                                  = uniqid( 'planning-carousel-' );
		$this->l10n['planningCarousel'][$id] = array(
			'autoplay'   => $autoplay,
			'navigation' => $atts['navigation'],
			'number'     => $number
		);

		foreach ( $this->steps as $index => $step ) {
			$output[] = $step;
		}

		return sprintf(
			'<div class="amwal-planning-carousel %s">
            	<div class="owl-planning-list" id="%s">
            		%s
                </div>
			</div>',
			esc_attr( implode( '', $css_class ) ),
			esc_attr( $id ),
			implode( ' ', $output )
		);
	}


	/**
	 * Planning Step info shortcode
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function planning_step( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'number' => '',
				'title'  => '',
			), $atts
		);

		$output = array();

		if ( $atts['number'] ) {
			$output[] = sprintf( '<div class="number-step">%s</div>', $atts['number'] );
		}


		if ( $atts['title'] ) {

			$output[] = sprintf( '<h4 class="title">%s</h4>', $atts['title'] );
		}

		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}
			$output[] = sprintf( '<div class="desc">%s</div>', $content );
		}


		$this->steps[] = sprintf( '<div class="item-planning">%s</div>', implode( ' ', $output ) );

		return '';
	}


	/**
	 * Abouts carousel shortcode
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function abouts_carousel( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title'      => '',
				'subtitle'   => '',
				'autoplay'   => 0,
				'pagination' => true,
				'el_class'   => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		$autoplay = intval( $atts['autoplay'] );

		$autoplay = $autoplay ? $autoplay : false;

		$this->abouts_content = array();
		$this->abouts_img     = array();

		do_shortcode( $content );

		if ( empty( $this->abouts_content ) ) {
			return '';
		}

		if ( empty( $this->abouts_img ) ) {
			return '';
		}

		$title = array();
		if ( $atts['title'] ) {
			$title[] = sprintf( '<span class="top-title"></span><h2 class="title">%s</h2>', $atts['title'] );
		}
		if ( $atts['subtitle'] ) {
			$title[] = sprintf( '<div class="sub-title">%s</div><span class="bottom-title"></span>', $atts['subtitle'] );
		}

		$output = array();
		$img    = array();

		$id                                = uniqid( 'amwal-abouts-carousel-' );
		$this->l10n['aboutsCarousel'][$id] = array(
			'autoplay'   => $autoplay,
			'pagination' => $atts['pagination'],
		);

		foreach ( $this->abouts_content as $index => $about ) {
			$output[] = $about;
		}

		foreach ( $this->abouts_img as $index => $image ) {
			$img[] = $image;
		}


		return sprintf(
			'<div class="amwal-abouts-carousel %s">
            	<div class="owl-abouts-list row" id="%s">
            		<div class="about-col-left col-md-6 col-sm-6 col-xs-12">
            			<div class="section-title title-block">
							%s
						</div>
            			<div class="owl-abouts-content-list">
            				%s
						</div>
            		</div>
            		<div class="about-col-right col-md-6 col-sm-6 col-xs-12">
            			<div class="owl-abouts-img-list">
            				%s
						</div>
            		</div>
                </div>
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_attr( $id ),
			implode( $title ),
			implode( ' ', $output ),
			implode( ' ', $img )
		);
	}


	/**
	 * About carousel shortcode
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function about_carousel( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'icon'  => '',
				'title' => '',
				'link'  => '',
				'image' => '',
			), $atts
		);

		$output = array();

		if ( $atts['icon'] ) {
			$output[] = sprintf( ' <span class="b-icon %s"></span>', $atts['icon'] );
		}

		if ( $atts['title'] ) {

			$output[] = sprintf( '<h4 class="title">%s</h4>', $atts['title'] );
		}

		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}
			$output[] = sprintf( '<div class="desc">%s</div>', $content );
		}

		$link = array_filter( vc_build_link( $atts['link'] ) );
		if ( ! empty( $link ) ) {
			$output[] = sprintf(
				'<a href="%s" class="view-more" %s%s>%s</a>',
				! empty ( $link['url'] ) ? esc_url( $link['url'] ) : '',
				! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
				! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
				! empty( $link['title'] ) ? esc_html( $link['title'] ) : ''
			);
		}

		$img = '';
		if ( $atts['image'] ) {
			$image = wp_get_attachment_image_src( intval( $atts['image'] ), 'full' );
			if ( $image ) {
				$img = sprintf(
					'<img alt="%s" src="%s">',
					esc_attr( $atts['image'] ),
					esc_url( $image[0] )
				);
			}
		}

		$this->abouts_content[] = sprintf(
			'<div class="item-about-content">
				%s
			</div>',
			implode( ' ', $output )
		);

		$this->abouts_img[] = sprintf(
			'<div class="item-img">
				%s
			 </div>',
			! empty( $img ) ? $img : ''
		);

		return '';
	}


	/**
	 * Line Charts shortcode
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function line_charts( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'width'    => 0,
				'height'   => 0,
				'label'    => '27 May|29 May',
				'title'    => '',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		$width = intval( $atts['width'] );

		$height = intval( $atts['height'] );

		$this->lines = array();
		do_shortcode( $content );

		if ( empty( $this->lines ) ) {
			return '';
		}
		$label = array();
		if ( $atts['label'] ) {
			$label = explode( '|', $atts['label'] );
		}

		$datasets = $this->lines;

		$id                            = uniqid( 'line-charts-' );
		$this->l10n['lineCharts'][$id] = array(
			'datasets' => $datasets,
			'label'    => $label,
			'title'    => $atts['title']
		);


		return sprintf(
			'<canvas class="amwal-line-charts %s" width="1170" height="585" id="%s">

			</canvas>',
			esc_attr( implode( '', $css_class ) ),

			esc_attr( $id )
		);
	}

	/**
	 * Line Chart info shortcode
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function line_chart( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title'          => '',
				'bg_color'       => '',
				'bd_color'       => '',
				'point_bd_color' => '',
				'point_bg_color' => '',
				'point_hover_bd' => '',
				'point_hover_bg' => '',
				'data'           => '11|20',
			), $atts
		);

		$output = array();

		if ( $atts['title'] ) {
			$output['label'] = $atts['title'];
		}

		if ( $atts['bg_color'] ) {
			$output['backgroundColor'] = $atts['bg_color'];
		}

		if ( $atts['bd_color'] ) {
			$output['borderColor'] = $atts['bd_color'];
		}

		if ( $atts['point_bd_color'] ) {
			$output['pointBorderColor'] = $atts['point_bd_color'];
		}

		if ( $atts['point_bg_color'] ) {
			$output['pointBackgroundColor'] = $atts['point_bg_color'];
		}

		if ( $atts['point_hover_bd'] ) {
			$output['pointHoverBorderColor'] = $atts['point_hover_bd'];
		}

		if ( $atts['point_hover_bg'] ) {
			$output['pointHoverBackgroundColor'] = $atts['point_hover_bg'];
		}

		$output['fill']             = false;
		$output['lineTension']      = 0;
		$output['pointBorderWidth'] = 3;

		if ( $atts['data'] ) {
			$data           = explode( '|', $atts['data'] );
			$output['data'] = $data;
		}

		$this->lines[] = $output;

		return '';
	}


	/**
	 * Bar Charts shortcode
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function bar_charts( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'label'    => '27 May|29 May',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		$this->bars = array();
		do_shortcode( $content );

		if ( empty( $this->bars ) ) {
			return '';
		}
		$label = array();
		if ( $atts['label'] ) {
			$label = explode( '|', $atts['label'] );
		}

		$datasets = $this->bars;

		$id                           = uniqid( 'bar-charts-' );
		$this->l10n['barCharts'][$id] = array(
			'datasets' => $datasets,
			'label'    => $label,
		);

		return sprintf(
			'<canvas class="amwal-bar-charts %s" id="%s">

			</canvas>',
			esc_attr( implode( '', $css_class ) ),
			esc_attr( $id )
		);
	}

	/**
	 * Bar Chart info shortcode
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function bar_chart( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title'    => '',
				'bg_color' => '',
				'bd_color' => '',
				'data'     => '11|20',
			), $atts
		);

		$output = array();

		if ( $atts['title'] ) {
			$output['label'] = $atts['title'];
		}

		if ( $atts['bg_color'] ) {
			$bg_color                  = explode( '|', $atts['bg_color'] );
			$output['backgroundColor'] = $bg_color;
		}

		if ( $atts['bd_color'] ) {
			$bd_color              = explode( '|', $atts['bd_color'] );
			$output['borderColor'] = $bd_color;
		}

		if ( $atts['data'] ) {
			$data           = explode( '|', $atts['data'] );
			$output['data'] = $data;
		}

		$output['borderWidth'] = 1;


		$this->bars[] = $output;

		return '';
	}


	/**
	 * Pie doughnut Charts shortcode
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function pie_doughnut( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'width'          => 0,
				'height'         => 0,
				'style'          => 'doughnut',
				'label'          => 'Red|Blue|Yellow',
				'bg_color'       => '#FF6384|#36A2EB|#FFCE56',
				'hover_bg_color' => '#FF6384|#36A2EB|#FFCE56',
				'data'           => '300|50|100',
				'el_class'       => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		$width = intval( $atts['width'] );

		$height = intval( $atts['height'] );

		$label = array();
		if ( $atts['label'] ) {
			$label = explode( '|', $atts['label'] );
		}

		$bg_color = array();
		if ( $atts['bg_color'] ) {
			$bg_color = explode( '|', $atts['bg_color'] );
		}

		$hover = array();
		if ( $atts['hover_bg_color'] ) {
			$hover = explode( '|', $atts['hover_bg_color'] );
		}

		$data = array();
		if ( $atts['data'] ) {
			$data = explode( '|', $atts['data'] );
		}

		$id                                = uniqid( 'pie-doughnut-charts-' );
		$this->l10n['doughnutCharts'][$id] = array(
			'type'         => $atts['style'],
			'label'        => $label,
			'bgcolor'      => $bg_color,
			'hoverbgcolor' => $hover,
			'data'         => $data,

		);

		return sprintf(
			'<canvas class="amwal-doughnut-charts %s" width="%s" height="%s" id="%s">

			</canvas>',
			esc_attr( implode( '', $css_class ) ),
			esc_attr( $width ),
			esc_attr( $height ),
			esc_attr( $id )
		);
	}


	/**
	 * Bar Charts shortcode
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function polar_area( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'width'    => 0,
				'height'   => 0,
				'title'    => 'My dataset',
				'label'    => 'Red|Blue|Yellow|Green|Grey',
				'bg_color' => '#FF6384|#4BC0C0|#FFCE56|#E7E9ED|#36A2EB',
				'data'     => '11|16|7|3|14',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		$width = intval( $atts['width'] );

		$height = intval( $atts['height'] );

		$label = array();
		if ( $atts['label'] ) {
			$label = explode( '|', $atts['label'] );
		}

		$bg_color = array();
		if ( $atts['bg_color'] ) {
			$bg_color = explode( '|', $atts['bg_color'] );
		}

		$data = array();
		if ( $atts['data'] ) {
			$data = explode( '|', $atts['data'] );
		}

		$id                             = uniqid( 'polar-are-charts-' );
		$this->l10n['polarCharts'][$id] = array(
			'title'   => $atts['title'],
			'label'   => $label,
			'bgcolor' => $bg_color,
			'data'    => $data,

		);

		return sprintf(
			'<canvas class="amwal-polar-area %s" width="%s" height="%s" id="%s">

			</canvas>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_attr( $width ),
			esc_attr( $height ),
			esc_attr( $id )
		);
	}

	/**
	 * Portfolio shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function portfolio( $atts ) {
		$atts = shortcode_atts(
			array(
				'style'           => '1',
				'number'          => 3,
				'total'           => 4,
				'show_padding'    => '',
				'autoplay'        => 0,
				'pagination'      => '',
				'show_filter'     => '',
				'button_position' => 'top',
				'filter_position' => 'center',
				'link'            => '',
				'el_class'        => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( $atts['style'] ) {
			$css_class[] = 'portfolio-style-' . $atts['style'];
		}

		if ( $atts['style'] == '1' ) {
			$css_class[] = 'amwal-portfolio-masonry portfolio-showcase';
		} elseif ( $atts['style'] == '3' ) {
			$css_class[] = 'amwal-portfolio-carousel ';
		} else {
			$css_class[] = 'amwal-portfolio-grid portfolio-showcase';

			if ( $atts['filter_position'] ) {
				$css_class[] = 'filter-position-' . $atts['filter_position'];
			}
		}

		if ( $atts['show_padding'] ) {
			$css_class[] = 'portfolio-has-padding';
		} else {
			$css_class[] = 'portfolio-no-padding';
		}

		$autoplay = intval( $atts['autoplay'] );
		if ( ! $autoplay ) {
			$autoplay = false;
		}

		$is_carousel = 0;
		if ( $atts['style'] == 3 ) {
			$is_carousel = 1;
		}

		$id                                    = uniqid( 'portfolios-carousel-' );
		$this->l10n['portfoliosCarousel'][$id] = array(
			'autoplay'   => $autoplay,
			'pagination' => $atts['pagination'],
			'number'     => $atts['number'],
			'iscarousel' => $is_carousel,
		);


		$output = array();

		$query_args = array(
			'posts_per_page'      => $atts['total'],
			'post_type'           => 'portfolio_project',
			'ignore_sticky_posts' => true,
		);

		$query = new WP_Query( $query_args );
		$i     = 0;
		$cats  = array();
		while ( $query->have_posts() ) : $query->the_post();

			$image_size = 'amwal-portfolio-normal';
			$item_class = ' portfolio-wapper ';

			if ( $atts['style'] == '1' ) {
				if ( $atts['show_padding'] ) {
					if ( $i == 0 ) {
						$image_size = 'amwal-portfolio-wide';
						$item_class .= ' portfolio-item-wide ';
					} elseif ( $i == 1 ) {
						$image_size = 'amwal-portfolio-full';
						$item_class .= ' portfolio-item-full ';
					}
				} else {
					$image_size = 'amwal-portfolio-normal-2';
					if ( $i == 0 ) {
						$image_size = 'amwal-portfolio-full-2';
						$item_class .= ' portfolio-item-full ';
					} elseif ( $i == 1 ) {
						$image_size = 'amwal-portfolio-wide-2';
						$item_class .= ' portfolio-item-wide ';
					}
				}


			} else {
				$image_size = 'amwal-portfolio-grid';
			}


			$categories = wp_get_post_terms( get_the_ID(), 'portfolio_category' );
			$cate       = '';
			if ( ! empty( $categories ) ) {

				foreach ( $categories as $cat ) {
					if ( empty( $cats[$cat->term_id] ) ) {
						$cats[$cat->term_id] = array( 'name' => $cat->name, 'slug' => $cat->slug, );
					}
				}

				$cate = sprintf(
					'<a class="portfolio-cat" href="%s">%s</a>',
					esc_url( get_term_link( $categories[0]->term_id ) ),
					esc_attr( $categories[0]->name )
				);
			}
			$article = array();

			$article[] = sprintf(
				'   <div class="portfolio-image">' .
				'        %1$s' .
				'     <div class="overlay-project"></div>' .
				'     <div class="content">' .
				'         <a class="title" href="%2$s">%3$s</a>' .
				'         %4$s' .
				'     </div>' .
				'   </div>',
				get_the_post_thumbnail( get_the_ID(), $image_size ),
				esc_url( get_permalink() ),
				get_the_title(),
				$cate
			);

			$item_class .= get_the_post_thumbnail( get_the_ID() ) ? ' has-img' : ' no-img';

			$output[] = sprintf(
				'<div class="portfolio-item %s %s">%s</div>',
				esc_attr( $item_class ),
				implode( ' ', get_post_class() ),
				implode( ' ', $article )
			);

			$i ++;
		endwhile;
		wp_reset_postdata();

		$view_more = '';
		if ( $atts['style'] == '1' ) {

			if ( $atts['button_position'] ) {
				$css_class[] = 'amwal-button-' . $atts['button_position'];
			}

			$link = array_filter( vc_build_link( $atts['link'] ) );
			if ( ! empty( $link ) ) {
				$view_more = sprintf(
					'<div class="view-more"><a href="%s" class="link"%s%s>%s</a></div>',
					! empty ( $link['url'] ) ? esc_url( $link['url'] ) : '',
					! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
					! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
					! empty( $link['title'] ) ? esc_html( $link['title'] ) : ''
				);
			}
		}


		$tab_filter = '';
		if ( in_array( $atts['style'], array( '1', '2' ) ) ) {


			if ( $atts['show_filter'] ) {
				$filter = array(
					'<li><a href="#filter" class="selected" data-option-value="*"> ' . esc_html__( 'All', 'amwal' ) . '</a></li>'
				);
				foreach ( $cats as $category ) {
					$filter[] = sprintf( '<li><a href="#filter" data-option-value=".portfolio_category-%s">%s</a></li>', esc_attr( $category['slug'] ), esc_html( $category['name'] ) );
				}

				$tab_filter = '<div class="filters-dropdown"><ul class="option-set" data-option-key="filter">' . implode( "\n", $filter ) . '</ul></div>';
			}
		}

		return sprintf(
			'<div class="amwal-portfolio %s">
				%s
				<div class="portfolio-list">
					<div class="portfolio-sizer"></div>
					<div class="owl-portfolio-list" id="%s">
						%s
					</div>
				</div>
				%s
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			$tab_filter,
			esc_attr( $id ),
			implode( '', $output ),
			$view_more
		);
	}

	/**
	 * Testimonials Shortcode
	 * Display testimonials carousel
	 *
	 * @param array $atts
	 *
	 * @return string
	 */
	function testimonials( $atts ) {
		$atts = shortcode_atts(
			array(
				'style'         => '1',
				'number'        => 3,
				'category'      => '',
				'light_skin'    => '',
				'hide_avatar'   => '',
				'pagi_position' => 'top',
				'pagination'    => true,
				'autoplay'      => 0,
				'el_class'      => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( $atts['style'] ) {
			$css_class[] = 'testimonial-style-' . $atts['style'];
		}

		if ( $atts['style'] == '1' ) {
			if ( $atts['pagi_position'] ) {
				$css_class[] = 'pagination-' . $atts['pagi_position'];
			}
		}

		if ( $atts['style'] == '2' ) {
			if ( $atts['hide_avatar'] ) {
				$css_class[] = 'hide-avatar';
			}
		}

		if ( $atts['light_skin'] ) {
			$css_class[] = 'light-skin';
		}

		if ( ! $atts['number'] ) {
			return '';
		}

		$autoplay = intval( $atts['autoplay'] );
		if ( ! $autoplay ) {
			$autoplay = false;
		}

		$id                                      = uniqid( 'testimonials-carousel-' );
		$this->l10n['testimonialsCarousel'][$id] = array(
			'autoplay'   => $autoplay,
			'pagination' => $atts['pagination']
		);

		$testimonials = get_posts(
			array(
				'post_type'            => 'testimonial',
				'posts_per_page'       => intval( $atts['number'] ),
				'testimonial_category' => trim( $atts['category'] ),
			)
		);

		if ( empty( $testimonials ) ) {
			return '';
		}

		$output = array();
		foreach ( $testimonials as $testimonial ) {
			$email = get_post_meta( $testimonial->ID, 'email', true );

			$output[] = sprintf(
				'<div class="item-testimonial">' .
				'   <div class="avatar">' .
				'       %s' .
				'   </div>' .
				'   <div class="testimonial-content">' .
				'       %s' .
				'       <span class="name">' .
				'           %s' .
				'       </span>' .
				'   </div>' .
				'</div>',
				has_post_thumbnail( $testimonial->ID ) ? get_the_post_thumbnail( $testimonial->ID, 'thumbnail' ) : get_avatar( $email, 100 ),
				apply_filters( 'the_content', $testimonial->post_content ),
				$testimonial->post_title

			);
		}

		return sprintf(
			'<div class="amwal-testimonials %s">' .
			'	<div class="owl-testimonial-list" id="%s">%s</div>' .
			'</div>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_attr( $id ),
			implode( ' ', $output )
		);
	}

	/**
	 * Shortcode to display contact form
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function contact_form( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'form'       => '',
				'light_skin' => '',
				'el_class'   => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( $atts['light_skin'] ) {
			$css_class[] = 'light-skin';
		}

		return sprintf(
			'<div class="amwal-contact-form %s">
				%s
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			do_shortcode( '[contact-form-7 id="' . esc_attr( $atts['form'] ) . '"]' )
		);
	}


	/**
	 * Shortcode to display newsletter
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function newsletter( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'light_skin' => '',
				'sub_title'  => '',
				'title'      => '',
				'form'       => '',
				'el_class'   => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( $atts['light_skin'] ) {
			$css_class[] = ' light-skin';
		}

		$output = array();

		if ( $atts['sub_title'] ) {
			$output[] = sprintf( '<div class="sub-title">%s</div>', $atts['sub_title'] );
		}

		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}
			$output[] = sprintf( '<div class="title">%s</div>', $content );
		}

		return sprintf(
			'<div class="amwal-newletter %s">
				<div class="container">
	                <div class="row">
	                    <div class="col-md-4 col-sm-4 col-xs-12 b-content">
	                        %s
	                    </div>
	                    <div class="col-md-8 col-sm-8 col-xs-12 b-form">
	                    	<div class="letter-field">
	  	                        %s
							</div>
	                    </div>
	                </div>
	            </div>
			</div>',
			esc_attr( implode( '', $css_class ) ),
			implode( '', $output ),
			do_shortcode( '[mc4wp_form id="' . esc_attr( $atts['form'] ) . '"]' )
		);
	}

	/**
	 * Shortcode to display contact form
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function cta( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'link'       => '',
				'light_skin' => '',
				'el_class'   => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( $atts['light_skin'] ) {
			$css_class[] = ' light-text';
		}

		$output = array();
		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}
			$output[] = sprintf( '<div class="title">%s</div>', $content );
		}

		$link = array_filter( vc_build_link( $atts['link'] ) );
		if ( ! empty( $link ) ) {
			$output[] = sprintf(
				'<a href="%s" class="view-more" %s%s>%s</a>',
				! empty ( $link['url'] ) ? esc_url( $link['url'] ) : '',
				! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
				! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
				! empty( $link['title'] ) ? esc_html( $link['title'] ) : ''
			);
		}

		return sprintf(
			'<div class="amwal-call-to-action %s">
				%s
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}


	/**
	 * Shortcode to display pricing table
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function pricing( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'featured'      => '',
				'title'         => '',
				'unit'          => '',
				'price'         => '',
				'time_duration' => '',
				'link'          => '',
				'el_class'      => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( $atts['featured'] ) {
			$css_class[] .= 'featured';
		}

		if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
			$content = wpb_js_remove_wpautop( $content, true );
		}
		$output = array();

		$button = '';
		$link   = array_filter( vc_build_link( $atts['link'] ) );
		if ( ! empty( $link ) ) {
			$button = sprintf(
				'<a href="%s" class="view-more" %s%s>%s</a>',
				! empty ( $link['url'] ) ? esc_url( $link['url'] ) : '',
				! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
				! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
				! empty( $link['title'] ) ? esc_html( $link['title'] ) : ''
			);
		}
		$output[] = sprintf(
			'<div class="pricing-title">' .
			'   <span class="title">%s</span>' .
			'</div>' .
			'<div class="pricing-box">' .
			'   <div class="pricing-info">' .
			'       <div class="pricing-inner">' .
			'           <div class="p-money">' .
			'                <span class="p-price">%s</span>' .
			'                <span class="p-unit">%s</span>' .
			'           </div>' .
			'           <span class="p-duration">%s</span>' .
			'       </div>' .
			'   </div>' .
			'   <div class="pricing-desc">%s</div>' .
			'   %s' .
			'</div>',
			esc_attr( $atts['title'] ),
			esc_attr( $atts['price'] ),
			esc_attr( $atts['unit'] ),
			esc_attr( $atts['time_duration'] ),
			$content,
			$button

		);

		return sprintf(
			'<div class="amwal-pricing %s">%s</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}

	/**
	 * Posts carousel shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function posts( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'        => '1',
				'title'        => '',
				'subtitle'     => '',
				'number'       => 4,
				'total'        => 4,
				'category'     => '',
				'link'         => '',
				'padding'      => '',
				'pag_position' => 'top',
				'autoplay'     => 0,
				'pagination'   => '',
				'el_class'     => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( $atts['style'] ) {
			$css_class[] = 'posts-style-' . $atts['style'];
		}

		if ( $atts['style'] == '1' ) {
			if ( $atts['padding'] ) {
				$css_class[] = 'post-has-padding';
			}

			if ( $atts['pag_position'] ) {
				$css_class[] = 'pagination-' . $atts['pag_position'];
			}
		}

		$autoplay = intval( $atts['autoplay'] );
		if ( ! $autoplay ) {
			$autoplay = false;
		}

		$is_carousel = 1;
		$col_class   = 'col-md-6 col-sm-6 col-xs-12';
		if ( $atts['style'] == '2' ) {
			$is_carousel = 0;

			if ( $atts['number'] == 4 ) {
				$col_class = 'col-md-3 col-sm-3 col-xs-12';
			} elseif ( $atts['number'] == 3 ) {
				$col_class = 'col-md-4 col-sm-4 col-xs-12';
			}
		}

		$id                               = uniqid( 'posts-carousel-' );
		$this->l10n['postsCarousel'][$id] = array(
			'autoplay'   => $autoplay,
			'pagination' => $atts['pagination'],
			'number'     => $atts['number'],
			'iscarousel' => $is_carousel
		);

		$title = '';
		if ( $atts['title'] ) {
			$title .= sprintf( '<span class="top-title"></span><h2 class="title">%s</h2>', $atts['title'] );
		}

		if ( $atts['subtitle'] ) {
			$title .= sprintf( '<div class="sub-title">%s</div><span class="bottom-title"></span>', $atts['subtitle'] );
		}

		if ( $title == '' ) {
			$css_class[] = 'no-title';
		}

		$link   = array_filter( vc_build_link( $atts['link'] ) );
		$button = '';
		if ( $atts['style'] == '2' ) {
			if ( ! empty( $link ) ) {
				$button = sprintf(
					'<a href="%s" class="view-more" %s%s>%s</a>',
					! empty ( $link['url'] ) ? esc_url( $link['url'] ) : '',
					! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
					! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
					! empty( $link['title'] ) ? esc_html( $link['title'] ) : ''
				);

			}
		}

		$output = array();

		$query_args = array(
			'posts_per_page'      => intval( $atts['total'] ),
			'post_type'           => 'post',
			'ignore_sticky_posts' => true,
		);
		if ( ! empty( $atts['category'] ) ) {
			$query_args['category_name'] = $atts['category'];
		}

		$image_size = 'amwal-post-grid';

		$query = new WP_Query( $query_args );
		while ( $query->have_posts() ) : $query->the_post();

			$article        = array();
			$comments_count = wp_count_comments( get_the_ID() );


			$article[] = sprintf(
				'<a class="blog-image" href="%1$s" title="%2$s">
					%7$s
				</a>
				<div class="blog-content">
					 <h3 class="post-title">
					 	<a class="post-link" href="%1$s">%2$s</a>
					 </h3>
		          	 <div class="blog-date">
                     	<span class="b-icon icon-calendar"></span>
                     	<span class="p-date">%3$s</span>
                     </div>
                     <div class="blog-author">
                     	<span class="b-icon icon-user"></span>
                     	<a class="p-author" href="%4$s" rel="author">%5$s</a>
					 </div>
                     <div class="blog-comment">
                    	 <span class="b-icon fa fa-comments"></span>
                     	 <span class="p-comment">%6$s</span>
					 </div>
				</div>',
				esc_url( get_permalink() ),
				get_the_title(),
				get_the_date( 'M d, Y' ),
				esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
				esc_attr( get_the_author() ),
				intval( $comments_count->total_comments ),
				get_the_post_thumbnail( get_the_ID(), $image_size )

			);

			$item_class = get_the_post_thumbnail( get_the_ID() ) ? 'has-img' : 'no-img';

			$output[] = sprintf(
				'<div class="single-blog-item %s %s"><div class="box-content-blog %s">%s</div></div>',
				esc_attr( $col_class ),
				implode( ' ', get_post_class() ),
				esc_attr( $item_class ),
				implode( ' ', $article )
			);

		endwhile;
		wp_reset_postdata();

		return sprintf(
			'<div class="amwal-posts %s">
				<div class="container title-block">%s %s</div>
				<div class="owl-post-list  row" id="%s">
					%s
				</div>
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			$title,
			$button,
			esc_attr( $id ),
			implode( '', $output )

		);
	}

	/**
	 * Display team shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function team( $atts ) {
		$atts = shortcode_atts(
			array(
				'style'        => '1',
				'total'        => '4',
				'groupteams'   => '',
				'number'       => 4,
				'autoplay'     => 0,
				'nav_position' => 'center',
				'navigation'   => true,
				'el_class'     => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( $atts['style'] ) {
			$css_class[] = 'team-style-' . $atts['style'];
		}

		if ( $atts['style'] == '1' ) {
			$css_class[] = 'team-nav-' . $atts['nav_position'];
		}

		$output = array();

		$autoplay = intval( $atts['autoplay'] );
		if ( ! $autoplay ) {
			$autoplay = false;
		}

		$is_carousel = 1;
		if ( $atts['style'] == '2' ) {
			$is_carousel = 0;
		}

		$id                               = uniqid( 'team-carousel-' );
		$this->l10n['teamsCarousel'][$id] = array(
			'autoplay'   => $autoplay,
			'navigation' => $atts['navigation'],
			'number'     => $atts['number'],
			'iscarousel' => $is_carousel
		);

		$query_args = array(
			'posts_per_page' => $atts['total'],
			'post_type'      => 'team_member',
		);

		if ( ! empty( $atts['groupteams'] ) ) {
			$query_args['tax_query'] = array(
				array(
					'taxonomy' => 'team_group',
					'field'    => 'id',
					'terms'    => $atts['groupteams'],
				),
			);
		}

		$query = new WP_Query( $query_args );
		while ( $query->have_posts() ) : $query->the_post();
			$image = get_the_post_thumbnail( get_the_ID(), 'amwal-portfolio-grid' );

			$socials       = get_post_meta( get_the_ID(), '_team_member_socials', true );
			$socials_links = '';

			if ( $socials ) {
				$social_links = array();
				foreach ( $socials as $social => $link ) {
					if ( $link ) {
						$social = 'googleplus' == $social ? 'google-plus' : $social;
						$social = 'vimeo' == $social ? 'vimeo-square' : $social;

						$social_links[] = sprintf( '<li><a href="%s" class="fa fa-%s"></a></li>', $link, $social );
					}
				}

				$social_links = '<ul class="socials-icon">' . implode( '', $social_links ) . '</ul>';
			}

			$output[] = sprintf(
				'<div class="team-item col-md-4 col-sm-4 col-xs-12">
						<div class="team-thumb">%s</div>
						<div class="team-content">
							<h2 class="t-title"><a href="%s">%s</a></h2>
							<span class="t-job">%s</span>
						</div>
						%s
				</div>',
				$image,
				esc_url( get_the_permalink() ),
				get_the_title(),
				get_post_meta( get_the_ID(), '_team_member_job', true ),
				$social_links
			);
		endwhile;

		wp_reset_postdata();

		return sprintf(
			'<div class="amwal-team %s">
				<div class="owl-team-list row" id="%s">%s</div>
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			esc_attr( $id ),
			implode( '', $output )
		);
	}


	/**
	 * Video banner shortcode
	 *
	 * @since  1.0
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function video( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'video'             => '',
				'image'             => '',
				'title'             => '',
				'poster_full_width' => '',
				'el_class'          => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( empty( $atts['video'] ) ) {
			return '';
		}

		$output = array();
		if ( $atts['image'] ) {
			$image = wp_get_attachment_image_src( intval( $atts['image'] ), 'full' );

			if ( $image ) {
				$output[] = sprintf(
					'<img class="video-img" alt="%s" src="%s">',
					esc_attr( $atts['image'] ),
					esc_url( $image[0] )
				);

				if ( $atts['poster_full_width'] ) {
					$css_class[] = 'video-poster-full';
				}

			}
		}

		$video = '';
		if ( $atts['video'] ) {
			$video = sprintf( '<a href="%s" class="status video-play"><i class="fa fa-play" aria-hidden="true"></i></a>', esc_url( $atts['video'] ) );
		}

		$title = '';
		if ( $atts['title'] ) {
			$title = sprintf( '<div class="video-title">%s</div>', esc_html( $atts['title'] ) );
		}

		$output[] = sprintf( '<div class="video-content">%s %s</div>', $video, $title );


		return sprintf(
			'<div class="amwal-video-banner format-video %s">
				%s
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);

	}


	/**
	 * Get instagram shortcode
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function company_history( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'style'        => '1',
				'year'         => '',
				'title'        => '',
				'hide_padding' => '',
				'el_class'     => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		if ( $atts['style'] ) {
			$css_class[] = 'history-style-' . $atts['style'];
		}

		if ( $atts['style'] == '2' ) {
			if ( $atts['hide_padding'] ) {
				$css_class[] = 'hide-padding';
			}
		}

		$year = '';
		if ( $atts['year'] ) {
			$year = sprintf( '<span class="year">%s</span>', $atts['year'] );
		}

		$title = '';
		if ( $atts['title'] ) {
			$title = sprintf( '<span class="title">%s</span>', $atts['title'] );
		}

		$desc = '';
		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}
			$desc = sprintf( '<div class="desc">%s</div>', $content );
		}

		$output = array();

		if ( $atts['style'] == '1' ) {
			$output[] = sprintf(
				'<div class="header-content">%s %s</div> %s',
				$year,
				$title,
				$desc
			);
		} else {
			$output[] = sprintf(
				'	%s
					<div class="box-content">
						<div class="history-desc">
							%s
							%s
						</div>
					</div>
				',
				$year,
				$title,
				$desc
			);
		}

		return sprintf(
			'<div class="amwal-company-history %s">%s</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( ' ', $output )
		);
	}


	/**
	 * Get portfolio info shortcode
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function portfolio_info( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title'    => '',
				'subtitle' => '',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		$output = array();

		if ( $atts['title'] ) {
			$output[] = sprintf( '<h2 class="title">%s</h2>', $atts['title'] );
		}

		if ( $atts['subtitle'] ) {
			$output[] = sprintf( '<div class="sub-title">%s</div>', $atts['subtitle'] );
		}

		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}
			$output[] = sprintf( '<div class="desc">%s</div>', $content );
		}

		return sprintf(
			'<div class="amwal-portfolio-info %s">%s</div>',
			esc_attr( implode( '', $css_class ) ),
			implode( '', $output )
		);
	}


	/**
	 * Get portfolio info shortcode
	 *
	 * @since  1.0
	 *
	 * @return string
	 */
	function portfolio_advisors( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title'    => '',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		$output = array();

		if ( $atts['title'] ) {
			$output[] = sprintf( '<h2 class="title">%s</h2>', $atts['title'] );
		}

		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}
			$output[] = sprintf( '<div class="desc">%s</div>', $content );
		}

		return sprintf(
			'<div class="amwal-portfolio-advisors %s">%s</div>',
			esc_attr( implode( '', $css_class ) ),
			implode( '', $output )
		);
	}

	/**
	 * Shortcode to display about
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function about( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title'    => '',
				'image'    => '',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		$output = array();

		if ( $atts['title'] ) {
			$output[] = sprintf( '<div class="title">%s</div>', $atts['title'] );
		}

		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}

			$output[] = sprintf( '<div class="desc">%s</div>', $content );
		}

		if ( $atts['image'] ) {
			$image = wp_get_attachment_image_src( intval( $atts['image'] ), 'full' );
			if ( $image ) {
				$output[] = sprintf(
					'<div class="about-img"><img alt="%s" src="%s"></div>',
					esc_attr( $atts['image'] ),
					esc_url( $image[0] )
				);
			}
		}

		return sprintf(
			'<div class="amwal-about %s">
				%s
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}


	/**
	 * Shortcode to display about
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function about_2( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title'      => '',
				'image'      => '',
				'image_size' => 'full',
				'video'      => '',
				'light_skin' => '',
				'el_class'   => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];
		if ( $atts['light_skin'] ) {
			$css_class[] = 'light-text';
		}

		$img = '';
		if ( $atts['image'] ) {
			$img = $this->get_image_src( $atts['image'], $atts['image_size'] );
		}

		$video = '';
		if ( $atts['video'] ) {
			$css_class[] = 'format-video';
			$video       = sprintf( '<a href="%s" class="status video-play"><i class="fa fa-play" aria-hidden="true"></i></a>', esc_url( $atts['video'] ) );
		}

		$output   = array();
		$output[] = sprintf( '<div class="about-head">%s %s</div>', $img, $video );

		if ( $atts['title'] ) {
			$output[] = sprintf( '<div class="title">%s</div>', $atts['title'] );
		}

		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}

			$output[] = sprintf( '<div class="desc">%s</div>', $content );
		}


		return sprintf(
			'<div class="amwal-about-2 %s">
				%s
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			implode( '', $output )
		);
	}


	/**
	 * Comming soon shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function coming_soon( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'image'    => '',
				'title'    => '',
				'date'     => '',
				'el_class' => '',
			), $atts
		);

		$output = array();

		if ( $atts['image'] ) {
			$image = wp_get_attachment_image_src( intval( $atts['image'] ), 'full' );
			if ( $image ) {
				$output[] = sprintf(
					'<a href="%s" class="coming-logo"><img alt="%s" src="%s"></a>',
					esc_url( home_url() ),
					esc_attr( $atts['image'] ),
					esc_url( $image[0] )
				);
			}
		}

		if ( $content ) {
			$output[] = sprintf( '<div class="coming-title">%s</div>', $content );
		}

		if ( $atts['date'] ) :
			$output[] = sprintf( '<div class="sale-price-date" data-date="%s">', esc_attr( $atts['date'] ) );
			$output[] = sprintf( '<div class="timer-day box"><span class="timer-content"><span class="day"></span><span class="title">%s</span></span></div>', esc_html__( 'Days', 'rockethost' ) );
			$output[] = sprintf( '<div class="timer-hour box"><span class="timer-content"><span class="hour"></span><span class="title">%s</span></span></div>', esc_html__( 'Hours', 'rockethost' ) );
			$output[] = sprintf( '<div class="timer-minu box"><span class="timer-content"><span class="minu"></span><span class="title">%s</span></span></div>', esc_html__( 'MINUTES', 'rockethost' ) );
			$output[] = sprintf( '<div class="timer-secs box"><span class="timer-content"><span class="secs"></span><span class="title">%s</span></span></div>', esc_html__( 'SECONDS', 'rockethost' ) );
			$output[] = '</div>';
		endif;


		return sprintf(
			'<div class="amwal-coming-soon %s"><div class="col-sm-offset-2 col-sm-8  text-center">%s</div></div>',
			esc_attr( $atts['el_class'] ),
			implode( '', $output )
		);
	}


	/**
	 * Socials shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	function socials( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'title'       => '',
				'facebook'    => '',
				'twitter'     => '',
				'google-plus' => '',
				'linkedin'    => '',
				'behance'     => '',
				'instagram'   => '',
				'skype'       => '',
				'apple'       => '',
				'youtube'     => '',
				'el_class'    => '',
			), $atts
		);

		$output = array();

		if ( $atts['title'] ) {
			$output[] = sprintf( '<div class="socials-title">%s</div>', $atts['title'] );
		}

		$output[] = '<div class="socials-list">';

		if ( $atts['facebook'] ) {
			$output[] = sprintf( '<a href="%s" class="social-facebook"><i class="fa fa-facebook"></i></a>', esc_url( $atts['facebook'] ) );
		}

		if ( $atts['twitter'] ) {
			$output[] = sprintf( '<a href="%s" class="social-twitter"><i class="fa fa-twitter"></i></a>', esc_url( $atts['twitter'] ) );
		}

		if ( $atts['google-plus'] ) {
			$output[] = sprintf( '<a href="%s" class="social-google-plus"><i class="fa fa-google-plus"></i></a>', esc_url( $atts['google-plus'] ) );
		}

		if ( $atts['linkedin'] ) {
			$output[] = sprintf( '<a href="%s" class="social-linkedin"><i class="fa fa-linkedin"></i></a>', esc_url( $atts['linkedin'] ) );
		}

		if ( $atts['behance'] ) {
			$output[] = sprintf( '<a href="%s" class="social-behance"><i class="fa fa-behance"></i></a>', esc_url( $atts['behance'] ) );
		}

		if ( $atts['instagram'] ) {
			$output[] = sprintf( '<a href="%s" class="social-instagram"><i class="fa fa-instagram"></i></a>', esc_url( $atts['instagram'] ) );
		}

		if ( $atts['skype'] ) {
			$output[] = sprintf( '<a href="%s" class="social-skype"><i class="fa fa-skype"></i></a>', esc_url( $atts['skype'] ) );
		}

		if ( $atts['apple'] ) {
			$output[] = sprintf( '<a href="%s" class="social-apple"><i class="fa fa-apple"></i></a>', esc_url( $atts['apple'] ) );
		}

		if ( $atts['youtube'] ) {
			$output[] = sprintf( '<a href="%s" class="social-youtube"><i class="fa fa-youtube"></i></a>', esc_url( $atts['youtube'] ) );
		}

		$output[] = '</div>';

		return sprintf(
			'<div class="amwal-socials %s">%s</div>',
			esc_attr( $atts['el_class'] ),
			implode( '', $output )
		);
	}


	/**
	 * Shortcode to display partner
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function partner( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'image'    => '',
				'title'    => '',
				'subtitle' => '',
				'address'  => '',
				'link'     => '',
				'el_class' => '',
			), $atts
		);

		$css_class[] = $atts['el_class'];

		$output = array();

		$link = array_filter( vc_build_link( $atts['link'] ) );

		$img       = '';
		$col_left  = '';
		$col_right = 'col-md-12 col-sm-12';

		if ( $atts['image'] ) {
			$image = wp_get_attachment_image_src( intval( $atts['image'] ), 'full' );
			if ( $image ) {
				$col_left  = 'partner-col-left col-md-3 col-sm-3 col-xs-12';
				$col_right = 'partner-col-right col-md-9 col-sm-9 col-xs-12';

				if ( ! empty( $link ) ) {
					$img = sprintf(
						'<a href="%s" class="partner-img"><img alt="%s" src="%s"></a>',
						! empty ( $link['url'] ) ? esc_url( $link['url'] ) : '',
						esc_attr( $atts['image'] ),
						esc_url( $image[0] )
					);
				} else {
					$img = sprintf(
						'<div class="partner-img"><img alt="%s" src="%s"></div>',
						esc_attr( $atts['image'] ),
						esc_url( $image[0] )
					);
				}
			}
		}


		if ( $atts['title'] ) {
			if ( ! empty( $link ) ) {
				$output[] = sprintf(
					'<a href="%s" class="title">%s</a>',
					! empty ( $link['url'] ) ? esc_url( $link['url'] ) : '',
					$atts['title']
				);
			} else {
				$output[] = sprintf( '<div class="title">%s</div>', $atts['title'] );

			}
		}

		$subtitle = '';
		if ( $atts['subtitle'] ) {
			$subtitle = sprintf( '<span class="subtitle">%s</span>', $atts['subtitle'] );
		}
		$address = '';
		if ( $atts['address'] ) {
			$address = sprintf( '<span class="address">%s</span>', $atts['address'] );
		}

		$output[] = sprintf( '<div class="partner-info"> %s %s</div>', $subtitle, $address );

		if ( $content ) {
			if ( function_exists( 'wpb_js_remove_wpautop' ) ) {
				$content = wpb_js_remove_wpautop( $content, true );
			}
			$output[] = sprintf( '<div class="desc">%s</div>', $content );
		}


		if ( ! empty( $link ) ) {
			$output[] = sprintf(
				'<a href="%s" class="view-more" %s%s>%s</a>',
				! empty ( $link['url'] ) ? esc_url( $link['url'] ) : '',
				! empty( $link['target'] ) ? ' target="' . esc_attr( $link['target'] ) . '"' : '',
				! empty( $link['rel'] ) ? ' rel="' . esc_attr( $link['rel'] ) . '"' : '',
				! empty( $link['title'] ) ? esc_html( $link['title'] ) : ''
			);
		}

		return sprintf(
			'<div class="amwal-partner %s">
				<div class="row">
					<div class="%s">%s</div>
					<div class="%s">%s</div>
				</div>
			</div>',
			esc_attr( implode( ' ', $css_class ) ),
			$col_left,
			$img,
			$col_right,
			implode( '', $output )
		);
	}

	/**
	 * Icon box tabs shortcode
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function multimaps( $atts, $content ) {
		$atts  = shortcode_atts(
			array(
				'api_key' => '',
				'style'   => '1',
				'marker'  => '',
				'width'   => '',
				'height'  => '450',
				'zoom'    => '13',
				'css'     => '',
			), $atts
		);
		$class = array(
			'amwal-map-shortcode',
			$atts['css'],
		);

		if ( $atts['style'] ) {
			$class[] = 'amwal-map-style-' . $atts['style'];
		}

		$style = '';
		if ( $atts['width'] ) {
			$unit = 'px';
			if ( strpos( $atts['width'], '%' ) ) {
				$unit = '%;';
			}

			$atts['width'] = intval( $atts['width'] );
			$style .= 'width: ' . $atts['width'] . $unit;
		}
		if ( $atts['height'] ) {
			$unit = 'px';
			if ( strpos( $atts['height'], '%' ) ) {
				$unit = '%;';
			}

			$atts['height'] = intval( $atts['height'] );
			$style .= 'height: ' . $atts['height'] . $unit;
		}
		if ( $atts['zoom'] ) {
			$atts['zoom'] = intval( $atts['zoom'] );
		}

		$id   = uniqid( 'amwal_map_' );
		$html = sprintf(
			'<div class="%s"><div id="%s" class="amwal-map" style="%s"></div></div>',
			implode( ' ', $class ),
			$id,
			$style
		);

		$this->maps = array();
		do_shortcode( $content );

		if ( empty( $this->maps ) ) {
			return '';
		}

		$output = array();
		$total  = count( $this->maps );

		if ( ! $total ) {
			return '';
		}

		$lats = array();
		$lng  = array();
		$info = array();
		$i    = 0;

		foreach ( $this->maps as $index => $map ) {

			$coordinates = $this->get_coordinates( $map['address'] );
			$lats[]      = $coordinates['lat'];
			$lng[]       = $coordinates['lng'];
			$info[]      = $map['content'];

			if ( isset( $coordinates['error'] ) ) {
				return $coordinates['error'];
			}

			$i ++;

		}

		$marker = '';
		if ( $atts['marker'] ) {
			if ( filter_var( $atts['marker'], FILTER_VALIDATE_URL ) ) {
				$marker = $atts['marker'];
			} else {
				$attachment_image = wp_get_attachment_image_src( intval( $atts['marker'] ), 'full' );
				$marker           = $attachment_image ? $attachment_image[0] : '';
			}
		}

		$this->api_key = $atts['api_key'];

		$this->l10n['map'][$id] = array(
			'style'  => $atts['style'],
			'type'   => 'normal',
			'lat'    => $lats,
			'lng'    => $lng,
			'zoom'   => $atts['zoom'],
			'marker' => $marker,
			'height' => $atts['height'],
			'info'   => $info,
			'number' => $i
		);

		return $html;

	}

	/**
	 * Icon box tab shortcode
	 *
	 * @param  array  $atts
	 * @param  string $content
	 *
	 * @return string
	 */
	function gmap( $atts, $content ) {
		$atts = shortcode_atts(
			array(
				'address' => '',
			), $atts
		);

		$this->maps[] = array(
			'address' => $atts['address'],
			'content' => $content,
		);

		return '';
	}

	/**
	 * Helper function to get coordinates for map
	 *
	 * @since 1.0.0
	 *
	 * @param string $address
	 * @param bool   $refresh
	 *
	 * @return array
	 */
	function get_coordinates( $address, $refresh = false ) {
		$address_hash = md5( $address );
		$coordinates  = get_transient( $address_hash );
		$results      = array( 'lat' => '', 'lng' => '' );

		if ( $refresh || $coordinates === false ) {
			$args     = array( 'address' => urlencode( $address ), 'sensor' => 'false' );
			$url      = add_query_arg( $args, 'http://maps.googleapis.com/maps/api/geocode/json' );
			$response = wp_remote_get( $url );

			if ( is_wp_error( $response ) ) {
				$results['error'] = esc_html__( 'Can not connect to Google Maps APIs', 'amwal' );

				return $results;
			}

			$data = wp_remote_retrieve_body( $response );

			if ( is_wp_error( $data ) ) {
				$results['error'] = esc_html__( 'Can not connect to Google Maps APIs', 'amwal' );

				return $results;
			}

			if ( $response['response']['code'] == 200 ) {
				$data = json_decode( $data );

				if ( $data->status === 'OK' ) {
					$coordinates = $data->results[0]->geometry->location;

					$results['lat']     = $coordinates->lat;
					$results['lng']     = $coordinates->lng;
					$results['address'] = (string) $data->results[0]->formatted_address;

					// cache coordinates for 3 months
					set_transient( $address_hash, $results, 3600 * 24 * 30 * 3 );
				} elseif ( $data->status === 'ZERO_RESULTS' ) {
					$results['error'] = esc_html__( 'No location found for the entered address.', 'amwal' );
				} elseif ( $data->status === 'INVALID_REQUEST' ) {
					$results['error'] = esc_html__( 'Invalid request. Did you enter an address?', 'amwal' );
				} else {
					$results['error'] = esc_html__( 'Something went wrong while retrieving your map, please ensure you have entered the short code correctly.', 'amwal' );
				}
			} else {
				$results['error'] = esc_html__( 'Unable to contact Google API service.', 'amwal' );
			}
		} else {
			$results = $coordinates; // return cached results
		}

		return $results;
	}

	/**
	 * Adjust brightness color
	 *
	 * @param  string $hex
	 * @param  int    $steps Steps should be between -255 and 255
	 *
	 * @return string
	 */
	function adjust_brightness( $hex, $steps ) {
		// Steps should be between -255 and 255. Negative = darker, positive = lighter
		$steps = max( - 255, min( 255, $steps ) );

		// Format the hex color string
		$hex = str_replace( '#', '', $hex );
		if ( strlen( $hex ) == 3 ) {
			$hex = str_repeat( substr( $hex, 0, 1 ), 2 ) . str_repeat( substr( $hex, 1, 1 ), 2 ) . str_repeat( substr( $hex, 2, 1 ), 2 );
		}

		// Get decimal values
		$r = hexdec( substr( $hex, 0, 2 ) );
		$g = hexdec( substr( $hex, 2, 2 ) );
		$b = hexdec( substr( $hex, 4, 2 ) );

		// Adjust number of steps and keep it inside 0 to 255
		$r = max( 0, min( 255, $r + $steps ) );
		$g = max( 0, min( 255, $g + $steps ) );
		$b = max( 0, min( 255, $b + $steps ) );

		$r_hex = str_pad( dechex( $r ), 2, '0', STR_PAD_LEFT );
		$g_hex = str_pad( dechex( $g ), 2, '0', STR_PAD_LEFT );
		$b_hex = str_pad( dechex( $b ), 2, '0', STR_PAD_LEFT );

		return '#' . $r_hex . $g_hex . $b_hex;
	}

	/**
	 * @param $atts
	 * @param $output
	 *
	 * @return array
	 */
	public function get_image_src( $image, $image_size ) {
		$output = '';
		if ( $image_size != 'full' ) {
			if ( $image ) {
				if ( function_exists( 'wpb_getImageBySize' ) ) {
					$image = wpb_getImageBySize(
						array(
							'attach_id'  => $image,
							'thumb_size' => $image_size,
						)
					);

					if ( $image['thumbnail'] ) {
						$output = $image['thumbnail'];
					} elseif ( $image['p_img_large'] ) {
						$output = sprintf(
							'<img alt="" src="%s">',
							esc_attr( $image['p_img_large'][0] )
						);
					}

				}
			}
		}

		if ( empty ( $output ) ) {
			$image = wp_get_attachment_image_src( $image, 'full' );
			if ( $image ) {
				$output = sprintf(
					'<img alt="" src="%s">',
					esc_url( $image[0] )
				);

			}

		}

		return $output;
	}

	/**
	 * Returns CSS for the color schemes.
	 *
	 *
	 * @param array $colors Color scheme colors.
	 *
	 * @return string Color scheme CSS.
	 */
	function amwal_get_color_scheme_css( $main_color, $sub_color ) {
		return <<<CSS
		/* Color Scheme */
		/* Primary Color */
		/*Background Color*/

		.btn-primary:hover,.btn-primary:active,.btn-primary:focus,
		.btn-default,
		.btn-default:hover,.btn-default:active,.btn-default:focus,
		.woo-btn,
		.woo-btn-2:hover,.woo-btn-2:focus,
		.amwal-clients.clients-style-2 .owl-controls .owl-buttons div,
		.amwal-services-carousel .item-services .service-content .service-box-content .view-more:hover,
		.amwal-services-carousel .item-services .service-content .service-box-content .view-more:active,
		.amwal-services-carousel .item-services .service-content .service-box-content .view-more:focus,
		.amwal-services-carousel .owl-controls .owl-pagination,
		.amwal-services-carousel .button-link .view-more:hover,
		.amwal-services-carousel .button-link .view-more:active,
		.amwal-services-carousel .button-link .view-more:focus,
		.amwal-services-carousel.services-style-1 .owl-controls,
		.amwal-services-carousel.services-style-2 .item-services.no-bg .service-content .service-bg:after,
		.amwal-portfolio .filters-dropdown ul.option-set li a,
		.amwal-portfolio .filters-dropdown ul.option-set li a:hover,.amwal-portfolio .filters-dropdown ul.option-set li a:active,.amwal-portfolio .filters-dropdown ul.option-set li a:focus,
		.amwal-portfolio.portfolio-style-1 .view-more .link:hover,.amwal-portfolio.portfolio-style-1 .view-more .link:active,.amwal-portfolio.portfolio-style-1 .view-more .link:focus,
		.amwal-portfolio.portfolio-style-1 .view-more .link:hover,
		.amwal-portfolio.portfolio-style-2 .portfolio-item .portfolio-image .content,
		.wpcf7-form input.wpcf7-form-control.wpcf7-submit,.wpcf7-form textarea.wpcf7-form-control.wpcf7-submit,
		.wpcf7-form .fancy-select ul.options,
		.amwal-call-to-action .view-more:hover,.amwal-call-to-action .view-more:active,.amwal-call-to-action .view-more:focus,
		.amwal-call-to-action .view-more:hover,
		.amwal-pricing .pricing-title,
		.amwal-pricing .pricing-box .view-more,
		.amwal-pricing.featured .pricing-box .view-more:hover,
		.amwal-posts.posts-style-2 .title-block .view-more:hover,.amwal-posts.posts-style-2 .title-block .view-more:active,.amwal-posts.posts-style-2 .title-block .view-more:focus,
		.amwal-team .team-item .socials-icon,
		.amwal-team.team-nav-center .owl-controls .owl-buttons div,
		.amwal-team.team-nav-top .owl-controls .owl-buttons div,
		.amwal-contacts-carousel.contacts-info-style-2 .item-contact .title,
		.amwal-planning-carousel .owl-planning-list .owl-controls .owl-buttons div,
		.amwal-company-history.history-style-1 .header-content .title,
		.amwal-company-history.history-style-2 .box-content .history-desc,
		.amwal-partner .view-more:hover,.amwal-partner .view-more:active,.amwal-partner .view-more:focus,
		.amwal-abouts-carousel .owl-abouts-content-list .view-more:hover,.amwal-abouts-carousel .owl-abouts-content-list .view-more:active,.amwal-abouts-carousel .owl-abouts-content-list .view-more:focus,
		.vc_tta.vc_tta-accordion.vc_tta-color-white .vc_tta-panel.vc_active .vc_tta-panel-heading,.vc_tta.vc_tta-accordion.vc_tta-color-orange .vc_tta-panel.vc_active .vc_tta-panel-heading,
		.vc_tta.vc_tta-accordion.vc_tta-color-grey .vc_tta-panel .vc_tta-panel-title > a,
		.vc_progress_bar.vc_progress-bar-color-custom .vc_single_bar .vc_bar,
		.tooltip .tooltip-inner,
		.joblist .job-header,
		.job-manager-form input.button,
		.job-manager-form input.button:hover,.job-manager-form input.button:active,.job-manager-form input.button:focus
		{
			background-color: $main_color
		}
		/*Border Color*/

		.amwal-clients.clients-style-2 .owl-controls .owl-pagination .owl-page,
		.amwal-services-carousel .item-services .service-content .service-box-content .view-more:hover,
		.amwal-services-carousel .owl-controls .owl-pagination .owl-page,
		.amwal-services-carousel .button-link .view-more:hover,
		.amwal-services-carousel.services-style-3 .item-services .service-content .service-box-content .view-more:hover,
		.amwal-services-carousel.services-style-3 .item-services.no-bg .service-content .service-box-content .view-more,
		.amwal-portfolio.portfolio-style-1 .view-more .link:hover,
		.amwal-portfolio.portfolio-style-3 .owl-controls .owl-pagination .owl-page,
		.amwal-testimonials .owl-controls .owl-pagination .owl-page,
		.wpcf7-form input.wpcf7-form-control:focus,.wpcf7-form textarea.wpcf7-form-control:focus,
		.wpcf7-form .fancy-select ul.options,
		.wpcf7-form div.fancy-select select:focus + div.trigger,
		.amwal-call-to-action .view-more:hover,
		.amwal-posts .owl-controls .owl-pagination .owl-page,
		.amwal-team.team-nav-center .owl-controls .owl-pagination .owl-page,
		.amwal-contacts-carousel .owl-controls .owl-page span,
		.amwal-planning-carousel .owl-planning-list .owl-controls .owl-pagination .owl-page span,
		.vc_tta.vc_tta-accordion.vc_tta-color-white .vc_tta-panel.vc_active .vc_tta-panel-heading,.vc_tta.vc_tta-accordion.vc_tta-color-orange .vc_tta-panel.vc_active .vc_tta-panel-heading{border-color: $main_color}
		/*Border Top*/

		.amwal-team.team-nav-top .owl-controls .owl-buttons .owl-prev:before,
		.amwal-planning-carousel .owl-planning-list .owl-controls .owl-buttons .owl-prev:before{border-top-color: $main_color}
		/*Border Left*/

		blockquote{border-left-color: $main_color}
		/*Border Bottom*/

		.amwal-team.team-nav-top .owl-controls .owl-buttons .owl-next:before,
		.amwal-planning-carousel .owl-planning-list .owl-controls .owl-buttons .owl-next:before,
		.tooltip .tooltip-arrow{border-bottom-color: $main_color}
		/*Color*/


		.amwal-services-carousel.services-style-3 .item-services.no-bg .service-content .service-box-content .title,
		.amwal-services-carousel.services-style-3 .item-services.no-bg .service-content .service-box-content .title .title-link,
		.amwal-call-to-action.light-text .view-more:hover,
		.amwal-pricing .pricing-box .pricing-info .p-money,
		#job-manager-job-dashboard .job-manager-jobs tr .job_title a{color: $main_color}

		/* Secondary Color */

		/*Background Color*/

		.btn-primary,
		.btn-default,
		.woo-btn:hover,.woo-btn:focus,
		.woo-btn-2,
		.owl-controls .owl-buttons div,
		.owl-controls .owl-buttons div:hover,
		.amwal-icon-box:hover .b-icon,
		.title-block .bottom-title,
		.section-title.title-style-2 .title:after,
		.amwal-clients.clients-style-2 .owl-controls .owl-pagination .owl-page:hover,
		.amwal-clients.clients-style-2 .owl-controls .owl-pagination .owl-page.active,
		.amwal-clients.clients-style-2 .owl-controls .owl-buttons div:hover,
		.amwal-services-carousel .owl-controls .owl-pagination .owl-page:hover,
		.amwal-services-carousel .owl-controls .owl-pagination .owl-page.active,
		.amwal-services-carousel.services-style-1 .button-link .view-more:hover,
		.amwal-services-carousel.services-style-1 .owl-controls .owl-buttons div:hover,
		.amwal-services-carousel.services-style-2 .item-services .service-content:hover .view-more:hover,
		.amwal-services-carousel.services-style-3 .item-services.no-bg .service-content .service-box-content .view-more:hover,
		.amwal-portfolio .filters-dropdown ul.option-set li a,
		.amwal-portfolio .filters-dropdown ul.option-set li a.selected,.amwal-portfolio .filters-dropdown ul.option-set li a:hover,
		.amwal-portfolio.portfolio-style-1 .portfolio-item .portfolio-image .content .title:after,.amwal-portfolio.portfolio-style-3 .portfolio-item .portfolio-image .content .title:after,
		.amwal-portfolio.portfolio-style-3 .owl-controls .owl-pagination .owl-page:hover,
		.amwal-portfolio.portfolio-style-3 .owl-controls .owl-pagination .owl-page.active,
		.amwal-testimonials.testimonial-style-1 .item-testimonial .testimonial-content .name:before,
		.amwal-testimonials.testimonial-style-2 .item-testimonial .testimonial-content .name:before,
		.amwal-testimonials .owl-controls .owl-pagination .owl-page:hover,
		.amwal-testimonials .owl-controls .owl-pagination .owl-page.active,
		.wpcf7-form input.wpcf7-form-control.wpcf7-submit:hover,.wpcf7-form textarea.wpcf7-form-control.wpcf7-submit:hover,
		.wpcf7-form .fancy-select ul.options li:hover,
		.wpcf7-form .fancy-select ul.options li.selected,
		.amwal-contact-form.light-skin .wpcf7-form input.wpcf7-form-control.wpcf7-submit:hover,
		.amwal-call-to-action.light-text .view-more,
		.amwal-pricing .pricing-box .view-more:hover,
		.amwal-pricing.featured .pricing-title,
		.amwal-pricing.featured .pricing-box .view-more,
		.amwal-posts.posts-style-2 .title-block .view-more,
		.amwal-posts .owl-controls .owl-pagination .owl-page:hover,
		.amwal-posts .owl-controls .owl-pagination .owl-page.active,
		.amwal-team.team-nav-center .owl-controls .owl-pagination .owl-page:hover,
		.amwal-team.team-nav-center .owl-controls .owl-pagination .owl-page.active,
		.amwal-team.team-nav-center .owl-controls .owl-buttons div:hover,
		.amwal-team.team-nav-top .owl-controls .owl-buttons div:hover,
		.amwal-contacts-carousel .item-contact .title,
		.amwal-contacts-carousel .owl-controls .owl-page.active span,.amwal-contacts-carousel .owl-controls .owl-page:hover span,
		.amwal-planning-carousel .owl-planning-list .item-planning .number-step,
		.amwal-planning-carousel .owl-planning-list .owl-controls .owl-buttons div:hover,
		.amwal-planning-carousel .owl-planning-list .owl-controls .owl-pagination .owl-page.active span,.amwal-planning-carousel .owl-planning-list .owl-controls .owl-pagination .owl-page:hover span,
		.amwal-company-history.history-style-1 .header-content .year,
		.amwal-company-history.history-style-2 .box-content:after,
		.amwal-partner .view-more,
		.amwal-abouts-carousel .owl-abouts-content-list .view-more,
		.amwal-abouts-carousel .owl-abouts-content-list .view-more:hover,
		.amwal-abouts-carousel .owl-abouts-img-list .owl-controls .owl-pagination .owl-page.active,.amwal-abouts-carousel .owl-abouts-img-list .owl-controls .owl-pagination .owl-page:hover,
		.vc_tta.vc_tta-accordion.vc_tta-color-orange .vc_tta-panel .vc_tta-panel-heading:hover,
		.vc_tta.vc_tta-accordion.vc_tta-color-orange .vc_tta-panel.vc_active .vc_tta-panel-heading,
		.vc_tta.vc_tta-accordion.vc_tta-color-grey .vc_tta-panel.vc_active .vc_tta-panel-title > a .vc_tta-title-text,
		.vc_progress_bar .vc_single_bar .vc_label_units span,
		.vc_tta.vc_general.vc_tta-color-grey.vc_tta-style-classic .vc_tta-tab.vc_active > a,
		.joblist h2:after,
		.joblist .job-body .job-info:hover,
		.joblist .job-body.active .job-info,
		.single-job .title-area h3:after,.single-job .apply-job h3:after,
		.job-manager-form input.button,
		.job-manager-form h2:after{
			background-color: $sub_color
		}
		/*Border Color*/

		.amwal-icon-box .b-icon,
		.title-block .top-title,
		.amwal-clients.clients-style-2 .owl-controls .owl-pagination .owl-page.active,
		.amwal-services-carousel .owl-controls .owl-pagination .owl-page.active,
		.amwal-services-carousel.services-style-1 .button-link .view-more:hover,
		.amwal-services-carousel.services-style-2 .item-services .service-content:hover .view-more:hover,
		.amwal-services-carousel.services-style-3 .item-services.no-bg .service-content .service-box-content .view-more:hover,
		.amwal-portfolio.portfolio-style-3 .owl-controls .owl-pagination .owl-page.active,
		.amwal-testimonials .owl-controls .owl-pagination .owl-page.active,
		.amwal-contact-form.light-skin .wpcf7-form input.wpcf7-form-control.wpcf7-submit:hover,
		.amwal-posts .owl-controls .owl-pagination .owl-page.active,
		.amwal-team.team-nav-center .owl-controls .owl-pagination .owl-page.active,
		.amwal-contacts-carousel .owl-controls .owl-page.active span,.amwal-contacts-carousel .owl-controls .owl-page:hover span,
		.amwal-planning-carousel .owl-planning-list .owl-controls .owl-pagination .owl-page.active span,.amwal-planning-carousel .owl-planning-list .owl-controls .owl-pagination .owl-page:hover span,
		.amwal-video-banner .video-content .status,
		.amwal-company-history.history-style-2:hover .box-content:after,
		.amwal-abouts-carousel .owl-abouts-content-list .b-icon,
		.amwal-abouts-carousel .owl-abouts-img-list .owl-controls .owl-pagination .owl-page.active,.amwal-abouts-carousel .owl-abouts-img-list .owl-controls .owl-pagination .owl-page:hover,
		.vc_tta.vc_tta-accordion.vc_tta-color-orange .vc_tta-panel.vc_active .vc_tta-panel-heading{border-color: $sub_color}
		/*Border Top*/

		.amwal-services-carousel.services-style-1 .owl-controls .owl-buttons .owl-prev:hover:before,
		.wpcf7-form div.fancy-select div.trigger.open::after,
		.amwal-team.team-nav-top .owl-controls .owl-buttons .owl-prev:hover:before,
		.amwal-planning-carousel .owl-planning-list .owl-controls .owl-buttons .owl-prev:hover:before,
		.vc_progress_bar .vc_single_bar .vc_label_units span:after{border-top-color: $sub_color}
		/*Border Left*/

		.vc_progress_bar .vc_single_bar .vc_label_units span:after{border-left-color: $sub_color}
		/*Border Bottom*/

		.amwal-services-carousel.services-style-1 .owl-controls .owl-buttons .owl-next:hover:before,
		.amwal-team.team-nav-top .owl-controls .owl-buttons .owl-next:hover:before,
		.amwal-planning-carousel .owl-planning-list .owl-controls .owl-buttons .owl-next:hover:before{border-bottom-color: $sub_color}
		/*Color*/

		.amwal-icon-box .b-icon,
		.amwal-counter .b-icon,
		.amwal-services-carousel .item-services .service-content .service-box-content .b-icon,
		.amwal-services-carousel .item-services .service-content .service-box-content .title .title-link:hover,
		.amwal-services-carousel.services-style-1.service-light-text .item-services .service-content .service-box-content .title .title-link:hover,
		.amwal-services-carousel.services-style-2 .item-services .service-content:hover .title .title-link:hover,
		.amwal-services-carousel.services-style-3.service-has-padding .owl-services-list .item-services .service-content .service-box-content .title,
		.amwal-services-carousel.services-style-3.service-has-padding .owl-services-list .item-services .service-content .service-box-content .title .title-link,
		.amwal-portfolio.portfolio-style-1 .portfolio-item .portfolio-image .content .title,.amwal-portfolio.portfolio-style-3 .portfolio-item .portfolio-image .content .title,
		.amwal-portfolio.portfolio-style-2 .portfolio-item .portfolio-image .content .title,
		.amwal-testimonials .item-testimonial .testimonial-content .name,
		.amwal-info-box .info-content .info-icon,
		.amwal-newletter .b-content .title .primary-color,
		.amwal-newletter .b-form .letter-field:after,
		.amwal-call-to-action .title .primary-color,
		.amwal-posts .single-blog-item .box-content-blog .blog-content .post-title .post-link:hover,
		.amwal-posts .single-blog-item .box-content-blog .blog-content .blog-date .b-icon,.amwal-posts .single-blog-item .box-content-blog .blog-content .blog-author .b-icon,.amwal-posts .single-blog-item .box-content-blog .blog-content .blog-comment .b-icon,
		.amwal-posts .single-blog-item .box-content-blog .blog-content .blog-author .p-author:hover,
		.amwal-team .team-item .socials-icon li a:hover,
		.amwal-contacts-carousel .item-contact .desc p i,
		.amwal-video-banner .video-content .status i,
		.amwal-partner .title:hover,
		.amwal-abouts-carousel .owl-abouts-content-list .b-icon,
		.amwal-abouts-carousel .owl-abouts-content-list .desc .list-stars-content li:before,
		.amwal-map-shortcode .amwal-map .amwal-map-info .list-contact-info li i,
		ul.list-icon-action li:before,
		.joblist .job-body i,
		.single-job .responsibility i,.single-job .skills i{color: $sub_color}

		.el-btn-bg-sub a.vc_btn3 {
			background-color: $sub_color !important;
		}
		.el-btn-bg-main a.vc_btn3 {
			background-color: $main_color !important;
		}
		.amwal-company-history.history-style-2 .box-content .history-desc:before {
			border-color: transparent $main_color transparent transparent;
		}


CSS;
	}

}
