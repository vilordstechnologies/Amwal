<?php
/**
 * Custom functions for Visual Composer
 *
 * @package    amwal
 * @subpackage Visual Composer
 */

if ( ! function_exists( 'is_plugin_active' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

/**
 * Class Amwal_VC
 *
 * @since 1.0.0
 */
class Amwal_VC {
	/**
	 * List of available icons
	 *
	 * @var array
	 */
	public $icons;

	/**
	 * Construction
	 */
	function __construct() {
		// Stop if VC is not installed
		if ( ! is_plugin_active( 'js_composer/js_composer.php' ) ) {
			return false;
		}

		$this->icons = self::get_icons();

		if ( function_exists( 'vc_add_shortcode_param' ) ) {

			vc_add_shortcode_param( 'icon', array( $this, 'icon_param' ), AMWAL_ADDONS_URL . '/assets/js/vc/icon-field.js' );

		} elseif ( function_exists( 'add_shortcode_param' ) ) {

			add_shortcode_param( 'icon', array( $this, 'icon_param' ), AMWAL_ADDONS_URL . '/assets/js/vc/icon-field.js' );

		} else {
			return false;
		}

		add_action( 'init', array( $this, 'map_shortcodes' ), 20 );
	}

	/**
	 * Define icon classes
	 *
	 * @since  1.0.0
	 *
	 * @return array
	 */
	public static function get_icons() {
		$icons_awesome    = array(
			'fa fa-adjust', 'fa fa-adn', 'fa fa-align-center', 'fa fa-align-justify', 'fa fa-align-left', 'fa fa-align-right', 'fa fa-ambulance', 'fa fa-anchor', 'fa fa-android', 'fa fa-angellist', 'fa fa-angle-double-down', 'fa fa-angle-double-left', 'fa fa-angle-double-right', 'fa fa-angle-double-up', 'fa fa-angle-down', 'fa fa-angle-left', 'fa fa-angle-right', 'fa fa-angle-up', 'fa fa-apple', 'fa fa-archive', 'fa fa-area-chart', 'fa fa-arrow-circle-down', 'fa fa-arrow-circle-left', 'fa fa-arrow-circle-o-down', 'fa fa-arrow-circle-o-left', 'fa fa-arrow-circle-o-right', 'fa fa-arrow-circle-o-up', 'fa fa-arrow-circle-right', 'fa fa-arrow-circle-up', 'fa fa-arrow-down', 'fa fa-arrow-left', 'fa fa-arrow-right', 'fa fa-arrow-up', 'fa fa-arrows', 'fa fa-arrows-alt', 'fa fa-arrows-h', 'fa fa-arrows-v', 'fa fa-asterisk', 'fa fa-at', 'fa fa-automobile', 'fa fa-backward', 'fa fa-ban', 'fa fa-bank', 'fa fa-bar-chart', 'fa fa-bar-chart-o', 'fa fa-barcode', 'fa fa-bars', 'fa fa-beer', 'fa fa-behance', 'fa fa-behance-square', 'fa fa-bell', 'fa fa-bell-o', 'fa fa-bell-slash', 'fa fa-bell-slash-o', 'fa fa-bicycle', 'fa fa-binoculars', 'fa fa-birthday-cake', 'fa fa-bitbucket', 'fa fa-bitbucket-square', 'fa fa-bitcoin', 'fa fa-bold', 'fa fa-bolt', 'fa fa-bomb', 'fa fa-book', 'fa fa-bookmark', 'fa fa-bookmark-o', 'fa fa-briefcase', 'fa fa-btc', 'fa fa-bug', 'fa fa-building', 'fa fa-building-o', 'fa fa-bullhorn', 'fa fa-bullseye', 'fa fa-bus', 'fa fa-cab', 'fa fa-calculator', 'fa fa-calendar', 'fa fa-calendar-o', 'fa fa-camera', 'fa fa-camera-retro', 'fa fa-car', 'fa fa-caret-down', 'fa fa-caret-left', 'fa fa-caret-right', 'fa fa-caret-square-o-down', 'fa fa-caret-square-o-left', 'fa fa-caret-square-o-right', 'fa fa-caret-square-o-up', 'fa fa-caret-up', 'fa fa-cc', 'fa fa-cc-amex', 'fa fa-cc-discover', 'fa fa-cc-mastercard', 'fa fa-cc-paypal', 'fa fa-cc-stripe', 'fa fa-cc-visa', 'fa fa-certificate', 'fa fa-chain', 'fa fa-chain-broken', 'fa fa-check', 'fa fa-check-circle', 'fa fa-check-circle-o', 'fa fa-check-square', 'fa fa-check-square-o', 'fa fa-chevron-circle-down', 'fa fa-chevron-circle-left', 'fa fa-chevron-circle-right', 'fa fa-chevron-circle-up', 'fa fa-chevron-down', 'fa fa-chevron-left', 'fa fa-chevron-right', 'fa fa-chevron-up', 'fa fa-child', 'fa fa-circle', 'fa fa-circle-o', 'fa fa-circle-o-notch', 'fa fa-circle-thin', 'fa fa-clipboard', 'fa fa-clock-o', 'fa fa-close', 'fa fa-cloud', 'fa fa-cloud-download', 'fa fa-cloud-upload', 'fa fa-cny', 'fa fa-code', 'fa fa-code-fork', 'fa fa-codepen', 'fa fa-coffee', 'fa fa-cog', 'fa fa-cogs', 'fa fa-columns', 'fa fa-comment', 'fa fa-comment-o', 'fa fa-comments', 'fa fa-comments-o', 'fa fa-compass', 'fa fa-compress', 'fa fa-copy', 'fa fa-copyright', 'fa fa-credit-card', 'fa fa-crop', 'fa fa-crosshairs', 'fa fa-css3', 'fa fa-cube', 'fa fa-cubes', 'fa fa-cut', 'fa fa-cutlery', 'fa fa-dashboard', 'fa fa-database', 'fa fa-dedent', 'fa fa-delicious', 'fa fa-desktop', 'fa fa-deviantart', 'fa fa-digg', 'fa fa-dollar', 'fa fa-dot-circle-o', 'fa fa-download', 'fa fa-dribbble', 'fa fa-dropbox', 'fa fa-drupal', 'fa fa-edit', 'fa fa-eject', 'fa fa-ellipsis-h', 'fa fa-ellipsis-v', 'fa fa-empire', 'fa fa-envelope', 'fa fa-envelope-o', 'fa fa-envelope-square', 'fa fa-eraser', 'fa fa-eur', 'fa fa-euro', 'fa fa-exchange', 'fa fa-exclamation', 'fa fa-exclamation-circle', 'fa fa-exclamation-triangle', 'fa fa-expand', 'fa fa-external-link', 'fa fa-external-link-square', 'fa fa-eye', 'fa fa-eye-slash', 'fa fa-eyedropper', 'fa fa-facebook', 'fa fa-facebook-square', 'fa fa-fast-backward', 'fa fa-fast-forward', 'fa fa-fax', 'fa fa-female', 'fa fa-fighter-jet', 'fa fa-file', 'fa fa-file-archive-o', 'fa fa-file-audio-o', 'fa fa-file-code-o', 'fa fa-file-excel-o', 'fa fa-file-image-o', 'fa fa-file-movie-o', 'fa fa-file-o', 'fa fa-file-pdf-o', 'fa fa-file-photo-o', 'fa fa-file-picture-o', 'fa fa-file-powerpoint-o', 'fa fa-file-sound-o', 'fa fa-file-text', 'fa fa-file-text-o', 'fa fa-file-video-o', 'fa fa-file-word-o', 'fa fa-file-zip-o', 'fa fa-files-o', 'fa fa-film', 'fa fa-filter', 'fa fa-fire', 'fa fa-fire-extinguisher', 'fa fa-flag', 'fa fa-flag-checkered', 'fa fa-flag-o', 'fa fa-flash', 'fa fa-flask', 'fa fa-flickr', 'fa fa-floppy-o', 'fa fa-folder', 'fa fa-folder-o', 'fa fa-folder-open', 'fa fa-folder-open-o', 'fa fa-font', 'fa fa-forward', 'fa fa-foursquare', 'fa fa-frown-o', 'fa fa-futbol-o', 'fa fa-gamepad', 'fa fa-gavel', 'fa fa-gbp', 'fa fa-ge', 'fa fa-gear', 'fa fa-gears', 'fa fa-gift', 'fa fa-git', 'fa fa-git-square', 'fa fa-github', 'fa fa-github-alt', 'fa fa-github-square', 'fa fa-gittip', 'fa fa-glass', 'fa fa-globe', 'fa fa-google', 'fa fa-google-plus', 'fa fa-google-plus-square', 'fa fa-google-wallet', 'fa fa-graduation-cap', 'fa fa-group', 'fa fa-h-square', 'fa fa-hacker-news', 'fa fa-hand-o-down', 'fa fa-hand-o-left', 'fa fa-hand-o-right', 'fa fa-hand-o-up', 'fa fa-hdd-o', 'fa fa-header', 'fa fa-headphones', 'fa fa-heart', 'fa fa-heart-o', 'fa fa-history', 'fa fa-home', 'fa fa-hospital-o', 'fa fa-html5', 'fa fa-ils', 'fa fa-image', 'fa fa-inbox', 'fa fa-indent', 'fa fa-info', 'fa fa-info-circle', 'fa fa-inr', 'fa fa-instagram', 'fa fa-institution', 'fa fa-ioxhost', 'fa fa-italic', 'fa fa-joomla', 'fa fa-jpy', 'fa fa-jsfiddle', 'fa fa-key', 'fa fa-keyboard-o', 'fa fa-krw', 'fa fa-language', 'fa fa-laptop', 'fa fa-lastfm', 'fa fa-lastfm-square', 'fa fa-leaf', 'fa fa-legal', 'fa fa-lemon-o', 'fa fa-level-down', 'fa fa-level-up', 'fa fa-life-bouy', 'fa fa-life-buoy', 'fa fa-life-ring', 'fa fa-life-saver', 'fa fa-lightbulb-o', 'fa fa-line-chart', 'fa fa-link', 'fa fa-linkedin', 'fa fa-linkedin-square', 'fa fa-linux', 'fa fa-list', 'fa fa-list-alt', 'fa fa-list-ol', 'fa fa-list-ul', 'fa fa-location-arrow', 'fa fa-lock', 'fa fa-long-arrow-down', 'fa fa-long-arrow-left', 'fa fa-long-arrow-right', 'fa fa-long-arrow-up', 'fa fa-magic', 'fa fa-magnet', 'fa fa-mail-forward', 'fa fa-mail-reply', 'fa fa-mail-reply-all', 'fa fa-male', 'fa fa-map-marker', 'fa fa-maxcdn', 'fa fa-meanpath', 'fa fa-medkit', 'fa fa-meh-o', 'fa fa-microphone', 'fa fa-microphone-slash', 'fa fa-minus', 'fa fa-minus-circle', 'fa fa-minus-square', 'fa fa-minus-square-o', 'fa fa-mobile', 'fa fa-mobile-phone', 'fa fa-money', 'fa fa-moon-o', 'fa fa-mortar-board', 'fa fa-music', 'fa fa-navicon', 'fa fa-newspaper-o', 'fa fa-openid', 'fa fa-outdent', 'fa fa-pagelines', 'fa fa-paint-brush', 'fa fa-paper-plane', 'fa fa-paper-plane-o', 'fa fa-paperclip', 'fa fa-paragraph', 'fa fa-paste', 'fa fa-pause', 'fa fa-paw', 'fa fa-paypal', 'fa fa-pencil', 'fa fa-pencil-square', 'fa fa-pencil-square-o', 'fa fa-phone', 'fa fa-phone-square', 'fa fa-photo', 'fa fa-picture-o', 'fa fa-pie-chart', 'fa fa-pied-piper', 'fa fa-pied-piper-alt', 'fa fa-pinterest', 'fa fa-pinterest-square', 'fa fa-plane', 'fa fa-play', 'fa fa-play-circle', 'fa fa-play-circle-o', 'fa fa-plug', 'fa fa-plus', 'fa fa-plus-circle', 'fa fa-plus-square', 'fa fa-plus-square-o', 'fa fa-power-off', 'fa fa-print', 'fa fa-puzzle-piece', 'fa fa-qq', 'fa fa-qrcode', 'fa fa-question', 'fa fa-question-circle', 'fa fa-quote-left', 'fa fa-quote-right', 'fa fa-ra', 'fa fa-random', 'fa fa-rebel', 'fa fa-recycle', 'fa fa-reddit', 'fa fa-reddit-square', 'fa fa-refresh', 'fa fa-remove', 'fa fa-renren', 'fa fa-reorder', 'fa fa-repeat', 'fa fa-reply', 'fa fa-reply-all', 'fa fa-retweet', 'fa fa-rmb', 'fa fa-road', 'fa fa-rocket', 'fa fa-rotate-left', 'fa fa-rotate-right', 'fa fa-rouble', 'fa fa-rss', 'fa fa-rss-square', 'fa fa-rub', 'fa fa-ruble', 'fa fa-rupee', 'fa fa-save', 'fa fa-scissors', 'fa fa-search', 'fa fa-search-minus', 'fa fa-search-plus', 'fa fa-send', 'fa fa-send-o', 'fa fa-share', 'fa fa-share-alt', 'fa fa-share-alt-square', 'fa fa-share-square', 'fa fa-share-square-o', 'fa fa-shekel', 'fa fa-sheqel', 'fa fa-shield', 'fa fa-shopping-cart', 'fa fa-sign-in', 'fa fa-sign-out', 'fa fa-signal', 'fa fa-sitemap', 'fa fa-skype', 'fa fa-slack', 'fa fa-sliders', 'fa fa-slideshare', 'fa fa-smile-o', 'fa fa-soccer-ball-o', 'fa fa-sort', 'fa fa-sort-alpha-asc', 'fa fa-sort-alpha-desc', 'fa fa-sort-amount-asc', 'fa fa-sort-amount-desc', 'fa fa-sort-asc', 'fa fa-sort-desc', 'fa fa-sort-down', 'fa fa-sort-numeric-asc', 'fa fa-sort-numeric-desc', 'fa fa-sort-up', 'fa fa-soundcloud', 'fa fa-space-shuttle', 'fa fa-spinner', 'fa fa-spoon', 'fa fa-spotify', 'fa fa-square', 'fa fa-square-o', 'fa fa-stack-exchange', 'fa fa-stack-overflow', 'fa fa-star', 'fa fa-star-half', 'fa fa-star-half-empty', 'fa fa-star-half-full', 'fa fa-star-half-o', 'fa fa-star-o', 'fa fa-steam', 'fa fa-steam-square', 'fa fa-step-backward', 'fa fa-step-forward', 'fa fa-stethoscope', 'fa fa-stop', 'fa fa-strikethrough', 'fa fa-stumbleupon', 'fa fa-stumbleupon-circle', 'fa fa-subscript', 'fa fa-suitcase', 'fa fa-sun-o', 'fa fa-superscript', 'fa fa-support', 'fa fa-table', 'fa fa-tablet', 'fa fa-tachometer', 'fa fa-tag', 'fa fa-tags', 'fa fa-tasks', 'fa fa-taxi', 'fa fa-tencent-weibo', 'fa fa-terminal', 'fa fa-text-height', 'fa fa-text-width', 'fa fa-th', 'fa fa-th-large', 'fa fa-th-list', 'fa fa-thumb-tack', 'fa fa-thumbs-down', 'fa fa-thumbs-o-down', 'fa fa-thumbs-o-up', 'fa fa-thumbs-up', 'fa fa-ticket', 'fa fa-times', 'fa fa-times-circle', 'fa fa-times-circle-o', 'fa fa-tint', 'fa fa-toggle-down', 'fa fa-toggle-left', 'fa fa-toggle-off', 'fa fa-toggle-on', 'fa fa-toggle-right', 'fa fa-toggle-up', 'fa fa-trash', 'fa fa-trash-o', 'fa fa-tree', 'fa fa-trello', 'fa fa-trophy', 'fa fa-truck', 'fa fa-try', 'fa fa-tty', 'fa fa-tumblr', 'fa fa-tumblr-square', 'fa fa-turkish-lira', 'fa fa-twitch', 'fa fa-twitter', 'fa fa-twitter-square', 'fa fa-umbrella', 'fa fa-underline', 'fa fa-undo', 'fa fa-university', 'fa fa-unlink', 'fa fa-unlock', 'fa fa-unlock-alt', 'fa fa-unsorted', 'fa fa-upload', 'fa fa-usd', 'fa fa-user', 'fa fa-user-md', 'fa fa-users', 'fa fa-video-camera', 'fa fa-vimeo-square', 'fa fa-vine', 'fa fa-vk', 'fa fa-volume-down', 'fa fa-volume-off', 'fa fa-volume-up', 'fa fa-warning', 'fa fa-wechat', 'fa fa-weibo', 'fa fa-weixin', 'fa fa-wheelchair', 'fa fa-wifi', 'fa fa-windows', 'fa fa-won', 'fa fa-wordpress', 'fa fa-wrench', 'fa fa-xing', 'fa fa-xing-square', 'fa fa-yahoo', 'fa fa-yelp', 'fa fa-yen', 'fa fa-youtube', 'fa fa-youtube-play', 'fa fa-youtube-square',
		);
		$icons_icomoon    = array(
			'icon-agreement', 'icon-amount', 'icon-analysis', 'icon-calculator3', 'icon-calculator-1', 'icon-chart', 'icon-coins', 'icon-contract', 'icon-diagram', 'icon-documentation', 'icon-dollar-coins', 'icon-dollar-symbol', 'icon-pie-chart3', 'icon-statistics', 'icon-suitcase', 'icon-tactics', 'icon-task', 'icon-chat', 'icon-chat-alt-stroke', 'icon-chat-alt-fill', 'icon-comment-alt1-stroke', 'icon-comment', 'icon-comment-stroke', 'icon-comment-fill', 'icon-comment-alt2-stroke', 'icon-comment-alt2-fill', 'icon-checkmark4', 'icon-check-alt', 'icon-x', 'icon-x-altx-alt', 'icon-denied', 'icon-cursor', 'icon-rss4', 'icon-rss-alt', 'icon-wrench3', 'icon-dial', 'icon-cog3', 'icon-calendar3', 'icon-calendar-alt-stroke', 'icon-calendar-alt-fill', 'icon-share4', 'icon-mail6', 'icon-heart-stroke', 'icon-heart-fill', 'icon-movie', 'icon-document-alt-stroke', 'icon-document-alt-fill', 'icon-document-stroke', 'icon-document-fill', 'icon-plus3', 'icon-plus-alt', 'icon-minus3', 'icon-minus-alt', 'icon-pin', 'icon-link3', 'icon-bolt', 'icon-move', 'icon-move-alt1', 'icon-move-alt2', 'icon-equalizer4', 'icon-award-fill', 'icon-award-stroke', 'icon-magnifying-glass', 'icon-trash-stroke', 'icon-trash-fill', 'icon-beaker-alt', 'icon-beaker', 'icon-key-stroke', 'icon-key-fill', 'icon-new-window', 'icon-lightbulb', 'icon-spin-alt', 'icon-spin', 'icon-curved-arrow', 'icon-undo4', 'icon-reload', 'icon-reload-alt', 'icon-loop4', 'icon-loop-alt1', 'icon-loop-alt2', 'icon-loop-alt3', 'icon-loop-alt4', 'icon-transfer', 'icon-move-vertical', 'icon-move-vertical-alt1', 'icon-move-vertical-alt2', 'icon-move-horizontal', 'icon-move-horizontal-alt1', 'icon-move-horizontal-alt2', 'icon-arrow-left4', 'icon-arrow-left-alt1', 'icon-arrow-left-alt2', 'icon-arrow-right4', 'icon-arrow-right-alt1', 'icon-arrow-right-alt2', 'icon-arrow-up4', 'icon-arrow-up-alt1', 'icon-arrow-up-alt2', 'icon-arrow-down4', 'icon-arrow-down-alt1', 'icon-arrow-down-alt2', 'icon-cd', 'icon-steering-wheel', 'icon-microphone', 'icon-headphones3', 'icon-volume', 'icon-volume-mute4', 'icon-play5', 'icon-pause4', 'icon-stop4', 'icon-eject3', 'icon-first3', 'icon-last3', 'icon-play-alt', 'icon-fullscreen-exit', 'icon-fullscreen-exit-alt', 'icon-fullscreen', 'icon-fullscreen-alt', 'icon-iphone', 'icon-battery-empty', 'icon-battery-half', 'icon-battery-full', 'icon-battery-charging', 'icon-compass4', 'icon-box', 'icon-folder-stroke', 'icon-folder-fill', 'icon-at', 'icon-ampersand', 'icon-info3', 'icon-question-mark', 'icon-pilcrow3', 'icon-hash', 'icon-left-quote', 'icon-right-quote', 'icon-left-quote-alt', 'icon-right-quote-alt', 'icon-article', 'icon-read-more', 'icon-list4', 'icon-list-nested', 'icon-book3', 'icon-book-alt', 'icon-book-alt2', 'icon-pen3', 'icon-pen-alt-stroke', 'icon-pen-alt-fill', 'icon-pen-alt2', 'icon-brush', 'icon-brush-alt', 'icon-eyedropper3', 'icon-layers-alt', 'icon-layers', 'icon-image3', 'icon-camera3', 'icon-aperture', 'icon-aperture-alt', 'icon-chart2', 'icon-chart-alt', 'icon-bars', 'icon-bars-alt', 'icon-eye3', 'icon-user3', 'icon-home5', 'icon-clock4', 'icon-lock-stroke', 'icon-lock-fill', 'icon-unlock-stroke', 'icon-unlock-fill', 'icon-tag-stroke', 'icon-tag-fill', 'icon-sun-stroke', 'icon-sun-fill', 'icon-moon-stroke', 'icon-moon-fill', 'icon-cloud3', 'icon-rain', 'icon-umbrella', 'icon-star', 'icon-map-pin-stroke', 'icon-map-pin-fill', 'icon-map-pin-alt', 'icon-target3', 'icon-download5', 'icon-upload5', 'icon-cloud-download3', 'icon-cloud-upload3', 'icon-fork', 'icon-paperclip', 'icon-home4', 'icon-home22', 'icon-home32', 'icon-office2', 'icon-newspaper2', 'icon-pencil3', 'icon-pencil22', 'icon-quill2', 'icon-pen2', 'icon-blog2', 'icon-eyedropper2', 'icon-droplet2', 'icon-paint-format2', 'icon-image2', 'icon-images2', 'icon-camera2', 'icon-headphones2', 'icon-music2', 'icon-play4', 'icon-film2', 'icon-video-camera2', 'icon-dice2', 'icon-pacman2', 'icon-spades2', 'icon-clubs2', 'icon-diamonds2', 'icon-bullhorn2', 'icon-connection2', 'icon-podcast2', 'icon-feed2', 'icon-mic2', 'icon-book2', 'icon-books2', 'icon-library2', 'icon-file-text3', 'icon-profile2', 'icon-file-empty2', 'icon-files-empty2', 'icon-file-text22', 'icon-file-picture2', 'icon-file-music2', 'icon-file-play2', 'icon-file-video2', 'icon-file-zip2', 'icon-copy2', 'icon-paste2', 'icon-stack2', 'icon-folder2', 'icon-folder-open2', 'icon-folder-plus2', 'icon-folder-minus2', 'icon-folder-download2', 'icon-folder-upload2', 'icon-price-tag2', 'icon-price-tags2', 'icon-barcode2', 'icon-qrcode2', 'icon-ticket2', 'icon-cart2', 'icon-coin-dollar2', 'icon-coin-euro2', 'icon-coin-pound2', 'icon-coin-yen2', 'icon-credit-card2', 'icon-calculator2', 'icon-lifebuoy2', 'icon-phone2', 'icon-phone-hang-up2', 'icon-address-book2', 'icon-envelop2', 'icon-pushpin2', 'icon-location3', 'icon-location22', 'icon-compass3', 'icon-compass22', 'icon-map3', 'icon-map22', 'icon-history2', 'icon-clock3', 'icon-clock22', 'icon-alarm2', 'icon-bell2', 'icon-stopwatch2', 'icon-calendar2', 'icon-printer2', 'icon-keyboard2', 'icon-display2', 'icon-laptop2', 'icon-mobile3', 'icon-mobile22', 'icon-tablet2', 'icon-tv2', 'icon-drawer3', 'icon-drawer22', 'icon-box-add2', 'icon-box-remove2', 'icon-download4', 'icon-upload4', 'icon-floppy-disk2', 'icon-drive2', 'icon-database2', 'icon-undo3', 'icon-redo3', 'icon-undo22', 'icon-redo22', 'icon-forward4', 'icon-reply2', 'icon-bubble3', 'icon-bubbles5', 'icon-bubbles22', 'icon-bubble22', 'icon-bubbles32', 'icon-bubbles42', 'icon-user2', 'icon-users2', 'icon-user-plus2', 'icon-user-minus2', 'icon-user-check2', 'icon-user-tie2', 'icon-quotes-left2', 'icon-quotes-right2', 'icon-hour-glass2', 'icon-spinner12', 'icon-spinner22', 'icon-spinner32', 'icon-spinner42', 'icon-spinner52', 'icon-spinner62', 'icon-spinner72', 'icon-spinner82', 'icon-spinner92', 'icon-spinner102', 'icon-spinner112', 'icon-binoculars2', 'icon-search2', 'icon-zoom-in2', 'icon-zoom-out2', 'icon-enlarge3', 'icon-shrink3', 'icon-enlarge22', 'icon-shrink22', 'icon-key3', 'icon-key22', 'icon-lock2', 'icon-unlocked2', 'icon-wrench2', 'icon-equalizer3', 'icon-equalizer22', 'icon-cog2', 'icon-cogs2', 'icon-hammer3', 'icon-magic-wand2', 'icon-aid-kit2', 'icon-bug2', 'icon-pie-chart2', 'icon-stats-dots2', 'icon-stats-bars3', 'icon-stats-bars22', 'icon-trophy2', 'icon-gift2', 'icon-glass3', 'icon-glass22', 'icon-mug2', 'icon-spoon-knife2', 'icon-leaf2', 'icon-rocket2', 'icon-meter3', 'icon-meter22', 'icon-hammer22', 'icon-fire2', 'icon-lab2', 'icon-magnet2', 'icon-bin3', 'icon-bin22', 'icon-briefcase2', 'icon-airplane2', 'icon-truck2', 'icon-road2', 'icon-accessibility2', 'icon-target2', 'icon-shield2', 'icon-power2', 'icon-switch2', 'icon-power-cord2', 'icon-clipboard2', 'icon-list-numbered2', 'icon-list3', 'icon-list22', 'icon-tree2', 'icon-menu5', 'icon-menu22', 'icon-menu32', 'icon-menu42', 'icon-cloud2', 'icon-cloud-download2', 'icon-cloud-upload2', 'icon-cloud-check2', 'icon-download22', 'icon-upload22', 'icon-download32', 'icon-upload32', 'icon-sphere2', 'icon-earth2', 'icon-link2', 'icon-flag2', 'icon-attachment2', 'icon-eye2', 'icon-eye-plus2', 'icon-eye-minus2', 'icon-eye-blocked2', 'icon-bookmark2', 'icon-bookmarks2', 'icon-sun2', 'icon-contrast2', 'icon-brightness-contrast2', 'icon-star-empty2', 'icon-star-half2', 'icon-star-full2', 'icon-heart2', 'icon-heart-broken2', 'icon-man2', 'icon-woman2', 'icon-man-woman2', 'icon-happy3', 'icon-happy22', 'icon-smile3', 'icon-smile22', 'icon-tongue3', 'icon-tongue22', 'icon-sad3', 'icon-sad22', 'icon-wink3', 'icon-wink22', 'icon-grin3', 'icon-grin22', 'icon-cool3', 'icon-cool22', 'icon-angry3', 'icon-angry22', 'icon-evil3', 'icon-evil22', 'icon-shocked3', 'icon-shocked22', 'icon-baffled3', 'icon-baffled22', 'icon-confused3', 'icon-confused22', 'icon-neutral3', 'icon-neutral22', 'icon-hipster3', 'icon-hipster22', 'icon-wondering3', 'icon-wondering22', 'icon-sleepy3', 'icon-sleepy22', 'icon-frustrated3', 'icon-frustrated22', 'icon-crying3', 'icon-crying22', 'icon-point-up2', 'icon-point-right2', 'icon-point-down2', 'icon-point-left2', 'icon-warning2', 'icon-notification2', 'icon-question2', 'icon-plus2', 'icon-minus2', 'icon-info2', 'icon-cancel-circle2', 'icon-blocked2', 'icon-cross2', 'icon-checkmark3', 'icon-checkmark22', 'icon-spell-check2', 'icon-enter2', 'icon-exit2', 'icon-play22', 'icon-pause3', 'icon-stop3', 'icon-previous3', 'icon-next3', 'icon-backward3', 'icon-forward22', 'icon-play32', 'icon-pause22', 'icon-stop22', 'icon-backward22', 'icon-forward32', 'icon-first2', 'icon-last2', 'icon-previous22', 'icon-next22', 'icon-eject2', 'icon-volume-high2', 'icon-volume-medium2', 'icon-volume-low2', 'icon-volume-mute3', 'icon-volume-mute22', 'icon-volume-increase2', 'icon-volume-decrease2', 'icon-loop3', 'icon-loop22', 'icon-infinite2', 'icon-shuffle2', 'icon-arrow-up-left3', 'icon-arrow-up3', 'icon-arrow-up-right3', 'icon-arrow-right3', 'icon-arrow-down-right3', 'icon-arrow-down3', 'icon-arrow-down-left3', 'icon-arrow-left3', 'icon-arrow-up-left22', 'icon-arrow-up22', 'icon-arrow-up-right22', 'icon-arrow-right22', 'icon-arrow-down-right22', 'icon-arrow-down22', 'icon-arrow-down-left22', 'icon-arrow-left22', 'icon-circle-up2', 'icon-circle-right2', 'icon-circle-down2', 'icon-circle-left2', 'icon-tab2', 'icon-move-up2', 'icon-move-down2', 'icon-sort-alpha-asc2', 'icon-sort-alpha-desc2', 'icon-sort-numeric-asc2', 'icon-sort-numberic-desc2', 'icon-sort-amount-asc2', 'icon-sort-amount-desc2', 'icon-command2', 'icon-shift2', 'icon-ctrl2', 'icon-opt2', 'icon-checkbox-checked2', 'icon-checkbox-unchecked2', 'icon-radio-checked3', 'icon-radio-checked22', 'icon-radio-unchecked2', 'icon-crop2', 'icon-make-group2', 'icon-ungroup2', 'icon-scissors2', 'icon-filter2', 'icon-font2', 'icon-ligature3', 'icon-ligature22', 'icon-text-height2', 'icon-text-width2', 'icon-font-size2', 'icon-bold2', 'icon-underline2', 'icon-italic2', 'icon-strikethrough2', 'icon-omega2', 'icon-sigma2', 'icon-page-break2', 'icon-superscript3', 'icon-subscript3', 'icon-superscript22', 'icon-subscript22', 'icon-text-color2', 'icon-pagebreak2', 'icon-clear-formatting2', 'icon-table3', 'icon-table22', 'icon-insert-template2', 'icon-pilcrow2', 'icon-ltr2', 'icon-rtl2', 'icon-section2', 'icon-paragraph-left2', 'icon-paragraph-center2', 'icon-paragraph-right2', 'icon-paragraph-justify2', 'icon-indent-increase2', 'icon-indent-decrease2', 'icon-share3', 'icon-new-tab2', 'icon-embed3', 'icon-embed22', 'icon-terminal2', 'icon-share22', 'icon-mail5', 'icon-mail22', 'icon-mail32', 'icon-mail42', 'icon-amazon2', 'icon-google4', 'icon-google22', 'icon-google32', 'icon-google-plus4', 'icon-google-plus22', 'icon-google-plus32', 'icon-hangouts2', 'icon-google-drive2', 'icon-facebook3', 'icon-facebook22', 'icon-instagram2', 'icon-whatsapp2', 'icon-spotify2', 'icon-telegram2', 'icon-twitter2', 'icon-vine2', 'icon-vk2', 'icon-renren2', 'icon-sina-weibo2', 'icon-rss3', 'icon-rss22', 'icon-youtube3', 'icon-youtube22', 'icon-twitch2', 'icon-vimeo3', 'icon-vimeo22', 'icon-lanyrd2', 'icon-flickr5', 'icon-flickr22', 'icon-flickr32', 'icon-flickr42', 'icon-dribbble2', 'icon-behance3', 'icon-behance22', 'icon-deviantart2', 'icon-500px2', 'icon-steam3', 'icon-steam22', 'icon-dropbox2', 'icon-onedrive2', 'icon-github2', 'icon-npm2', 'icon-basecamp2', 'icon-trello2', 'icon-wordpress2', 'icon-joomla2', 'icon-ello2', 'icon-blogger3', 'icon-blogger22', 'icon-tumblr3', 'icon-tumblr22', 'icon-yahoo3', 'icon-yahoo22', 'icon-tux2', 'icon-appleinc2', 'icon-finder2', 'icon-android2', 'icon-windows2', 'icon-windows82', 'icon-soundcloud3', 'icon-soundcloud22', 'icon-skype2', 'icon-reddit2', 'icon-hackernews2', 'icon-wikipedia2', 'icon-linkedin3', 'icon-linkedin22', 'icon-lastfm3', 'icon-lastfm22', 'icon-delicious2', 'icon-stumbleupon3', 'icon-stumbleupon22', 'icon-stackoverflow2', 'icon-pinterest3', 'icon-pinterest22', 'icon-xing3', 'icon-xing22', 'icon-flattr2', 'icon-foursquare2', 'icon-yelp2', 'icon-paypal2', 'icon-chrome2', 'icon-firefox2', 'icon-IE2', 'icon-edge2', 'icon-safari2', 'icon-opera2', 'icon-file-pdf2', 'icon-file-openoffice2', 'icon-file-word2', 'icon-file-excel2', 'icon-libreoffice2', 'icon-html-five3', 'icon-html-five22', 'icon-css32', 'icon-git2', 'icon-codepen2', 'icon-svg2', 'icon-IcoMoon2', 'icon-home', 'icon-home2', 'icon-home3', 'icon-office', 'icon-newspaper', 'icon-pencil', 'icon-pencil2', 'icon-quill', 'icon-pen', 'icon-blog', 'icon-eyedropper', 'icon-droplet', 'icon-paint-format', 'icon-image', 'icon-images', 'icon-camera', 'icon-headphones', 'icon-music', 'icon-play', 'icon-film', 'icon-video-camera', 'icon-dice', 'icon-pacman', 'icon-spades', 'icon-clubs', 'icon-diamonds', 'icon-bullhorn', 'icon-connection', 'icon-podcast', 'icon-feed', 'icon-mic', 'icon-book', 'icon-books', 'icon-library', 'icon-file-text', 'icon-profile', 'icon-file-empty', 'icon-files-empty', 'icon-file-text2', 'icon-file-picture', 'icon-file-music', 'icon-file-play', 'icon-file-video', 'icon-file-zip', 'icon-copy', 'icon-paste', 'icon-stack', 'icon-folder', 'icon-folder-open', 'icon-folder-plus', 'icon-folder-minus', 'icon-folder-download', 'icon-folder-upload', 'icon-price-tag', 'icon-price-tags', 'icon-barcode', 'icon-qrcode', 'icon-ticket', 'icon-cart', 'icon-coin-dollar', 'icon-coin-euro', 'icon-coin-pound', 'icon-coin-yen', 'icon-credit-card', 'icon-calculator', 'icon-lifebuoy', 'icon-phone', 'icon-phone-hang-up', 'icon-address-book', 'icon-envelop', 'icon-pushpin', 'icon-location', 'icon-location2', 'icon-compass', 'icon-compass2', 'icon-map', 'icon-map2', 'icon-history', 'icon-clock', 'icon-clock2', 'icon-alarm', 'icon-bell', 'icon-stopwatch', 'icon-calendar', 'icon-printer', 'icon-keyboard', 'icon-display', 'icon-laptop', 'icon-mobile', 'icon-mobile2', 'icon-tablet', 'icon-tv', 'icon-drawer', 'icon-drawer2', 'icon-box-add', 'icon-box-remove', 'icon-download', 'icon-upload', 'icon-floppy-disk', 'icon-drive', 'icon-database', 'icon-undo', 'icon-redo', 'icon-undo2', 'icon-redo2', 'icon-forward', 'icon-reply', 'icon-bubble', 'icon-bubbles', 'icon-bubbles2', 'icon-bubble2', 'icon-bubbles3', 'icon-bubbles4', 'icon-user', 'icon-users', 'icon-user-plus', 'icon-user-minus', 'icon-user-check', 'icon-user-tie', 'icon-quotes-left', 'icon-quotes-right', 'icon-hour-glass', 'icon-spinner', 'icon-spinner2', 'icon-spinner3', 'icon-spinner4', 'icon-spinner5', 'icon-spinner6', 'icon-spinner7', 'icon-spinner8', 'icon-spinner9', 'icon-spinner10', 'icon-spinner11', 'icon-binoculars', 'icon-search', 'icon-zoom-in', 'icon-zoom-out', 'icon-enlarge', 'icon-shrink', 'icon-enlarge2', 'icon-shrink2', 'icon-key', 'icon-key2', 'icon-lock', 'icon-unlocked', 'icon-wrench', 'icon-equalizer', 'icon-equalizer2', 'icon-cog', 'icon-cogs', 'icon-hammer', 'icon-magic-wand', 'icon-aid-kit', 'icon-bug', 'icon-pie-chart', 'icon-stats-dots', 'icon-stats-bars', 'icon-stats-bars2', 'icon-trophy', 'icon-gift', 'icon-glass', 'icon-glass2', 'icon-mug', 'icon-spoon-knife', 'icon-leaf', 'icon-rocket', 'icon-meter', 'icon-meter2', 'icon-hammer2', 'icon-fire', 'icon-lab', 'icon-magnet', 'icon-bin', 'icon-bin2', 'icon-briefcase', 'icon-airplane', 'icon-truck', 'icon-road', 'icon-accessibility', 'icon-target', 'icon-shield', 'icon-power', 'icon-switch', 'icon-power-cord', 'icon-clipboard', 'icon-list-numbered', 'icon-list', 'icon-list2', 'icon-tree', 'icon-menu', 'icon-menu2', 'icon-menu3', 'icon-menu4', 'icon-cloud', 'icon-cloud-download', 'icon-cloud-upload', 'icon-cloud-check', 'icon-download2', 'icon-upload2', 'icon-download3', 'icon-upload3', 'icon-sphere', 'icon-earth', 'icon-link', 'icon-flag', 'icon-attachment', 'icon-eye', 'icon-eye-plus', 'icon-eye-minus', 'icon-eye-blocked', 'icon-bookmark', 'icon-bookmarks', 'icon-sun', 'icon-contrast', 'icon-brightness-contrast', 'icon-star-empty', 'icon-star-half', 'icon-star-full', 'icon-heart', 'icon-heart-broken', 'icon-man', 'icon-woman', 'icon-man-woman', 'icon-happy', 'icon-happy2', 'icon-smile', 'icon-smile2', 'icon-tongue', 'icon-tongue2', 'icon-sad', 'icon-sad2', 'icon-wink', 'icon-wink2', 'icon-grin', 'icon-grin2', 'icon-cool', 'icon-cool2', 'icon-angry', 'icon-angry2', 'icon-evil', 'icon-evil2', 'icon-shocked', 'icon-shocked2', 'icon-baffled', 'icon-baffled2', 'icon-confused', 'icon-confused2', 'icon-neutral', 'icon-neutral2', 'icon-hipster', 'icon-hipster2', 'icon-wondering', 'icon-wondering2', 'icon-sleepy', 'icon-sleepy2', 'icon-frustrated', 'icon-frustrated2', 'icon-crying', 'icon-crying2', 'icon-point-up', 'icon-point-right', 'icon-point-down', 'icon-point-left', 'icon-warning', 'icon-notification', 'icon-question', 'icon-plus', 'icon-minus', 'icon-info', 'icon-cancel-circle', 'icon-blocked', 'icon-cross', 'icon-checkmark', 'icon-checkmark2', 'icon-spell-check', 'icon-enter', 'icon-exit', 'icon-play2', 'icon-pause', 'icon-stop', 'icon-previous', 'icon-next', 'icon-backward', 'icon-forward2', 'icon-play3', 'icon-pause2', 'icon-stop2', 'icon-backward2', 'icon-forward3', 'icon-first', 'icon-last', 'icon-previous2', 'icon-next2', 'icon-eject', 'icon-volume-high', 'icon-volume-medium', 'icon-volume-low', 'icon-volume-mute', 'icon-volume-mute2', 'icon-volume-increase', 'icon-volume-decrease', 'icon-loop', 'icon-loop2', 'icon-infinite', 'icon-shuffle', 'icon-arrow-up-left', 'icon-arrow-up', 'icon-arrow-up-right', 'icon-arrow-right', 'icon-arrow-down-right', 'icon-arrow-down', 'icon-arrow-down-left', 'icon-arrow-left', 'icon-arrow-up-left2', 'icon-arrow-up2', 'icon-arrow-up-right2', 'icon-arrow-right2', 'icon-arrow-down-right2', 'icon-arrow-down2', 'icon-arrow-down-left2', 'icon-arrow-left2', 'icon-circle-up', 'icon-circle-right', 'icon-circle-down', 'icon-circle-left', 'icon-tab', 'icon-move-up', 'icon-move-down', 'icon-sort-alpha-asc', 'icon-sort-alpha-desc', 'icon-sort-numeric-asc', 'icon-sort-numberic-desc', 'icon-sort-amount-asc', 'icon-sort-amount-desc', 'icon-command', 'icon-shift', 'icon-ctrl', 'icon-opt', 'icon-checkbox-checked', 'icon-checkbox-unchecked', 'icon-radio-checked', 'icon-radio-checked2', 'icon-radio-unchecked', 'icon-crop', 'icon-make-group', 'icon-ungroup', 'icon-scissors', 'icon-filter', 'icon-font', 'icon-ligature', 'icon-ligature2', 'icon-text-height', 'icon-text-width', 'icon-font-size', 'icon-bold', 'icon-underline', 'icon-italic', 'icon-strikethrough', 'icon-omega', 'icon-sigma', 'icon-page-break', 'icon-superscript', 'icon-subscript', 'icon-superscript2', 'icon-subscript2', 'icon-text-color', 'icon-pagebreak', 'icon-clear-formatting', 'icon-table', 'icon-table2', 'icon-insert-template', 'icon-pilcrow', 'icon-ltr', 'icon-rtl', 'icon-section', 'icon-paragraph-left', 'icon-paragraph-center', 'icon-paragraph-right', 'icon-paragraph-justify', 'icon-indent-increase', 'icon-indent-decrease', 'icon-share', 'icon-new-tab', 'icon-embed', 'icon-embed2', 'icon-terminal', 'icon-share2', 'icon-mail', 'icon-mail2', 'icon-mail3', 'icon-mail4', 'icon-amazon', 'icon-google', 'icon-google2', 'icon-google3', 'icon-google-plus', 'icon-google-plus2', 'icon-google-plus3', 'icon-hangouts', 'icon-google-drive', 'icon-facebook', 'icon-facebook2', 'icon-instagram', 'icon-whatsapp', 'icon-spotify', 'icon-telegram', 'icon-twitter', 'icon-vine', 'icon-vk', 'icon-renren', 'icon-sina-weibo', 'icon-rss', 'icon-rss2', 'icon-youtube', 'icon-youtube2', 'icon-twitch', 'icon-vimeo', 'icon-vimeo2', 'icon-lanyrd', 'icon-flickr', 'icon-flickr2', 'icon-flickr3', 'icon-flickr4', 'icon-dribbble', 'icon-behance', 'icon-behance2', 'icon-deviantart', 'icon-500px', 'icon-steam', 'icon-steam2', 'icon-dropbox', 'icon-onedrive', 'icon-github', 'icon-npm', 'icon-basecamp', 'icon-trello', 'icon-wordpress', 'icon-joomla', 'icon-ello', 'icon-blogger', 'icon-blogger2', 'icon-tumblr', 'icon-tumblr2', 'icon-yahoo', 'icon-yahoo2', 'icon-tux', 'icon-appleinc', 'icon-finder', 'icon-android', 'icon-windows', 'icon-windows8', 'icon-soundcloud', 'icon-soundcloud2', 'icon-skype', 'icon-reddit', 'icon-hackernews', 'icon-wikipedia', 'icon-linkedin', 'icon-linkedin2', 'icon-lastfm', 'icon-lastfm2', 'icon-delicious', 'icon-stumbleupon', 'icon-stumbleupon2', 'icon-stackoverflow', 'icon-pinterest', 'icon-pinterest2', 'icon-xing', 'icon-xing2', 'icon-flattr', 'icon-foursquare', 'icon-yelp', 'icon-paypal', 'icon-chrome', 'icon-firefox', 'icon-IE', 'icon-edge', 'icon-safari', 'icon-opera', 'icon-file-pdf', 'icon-file-openoffice', 'icon-file-word', 'icon-file-excel', 'icon-libreoffice', 'icon-html-five', 'icon-html-five2', 'icon-css3', 'icon-git', 'icon-codepen', 'icon-svg', 'icon-IcoMoon'
		);
		$icons_linearicon = array(
			'lnr-home', 'lnr-apartment', 'lnr-pencil', 'lnr-magic-wand', 'lnr-drop', 'lnr-lighter', 'lnr-poop', 'lnr-sun', 'lnr-moon', 'lnr-cloud', 'lnr-cloud-upload', 'lnr-cloud-download', 'lnr-cloud-sync', 'lnr-cloud-check', 'lnr-database', 'lnr-lock', 'lnr-cog', 'lnr-trash', 'lnr-dice', 'lnr-heart', 'lnr-star', 'lnr-star-half', 'lnr-star-empty', 'lnr-flag', 'lnr-envelope', 'lnr-paperclip', 'lnr-inbox', 'lnr-eye', 'lnr-printer', 'lnr-file-empty', 'lnr-file-add', 'lnr-enter', 'lnr-exit', 'lnr-graduation-hat', 'lnr-license', 'lnr-music-note', 'lnr-film-play', 'lnr-camera-video', 'lnr-camera', 'lnr-picture', 'lnr-book', 'lnr-bookmark', 'lnr-user', 'lnr-users', 'lnr-shirt', 'lnr-store', 'lnr-cart', 'lnr-tag', 'lnr-phone-handset', 'lnr-phone', 'lnr-pushpin', 'lnr-map-marker', 'lnr-map', 'lnr-location', 'lnr-calendar-full', 'lnr-keyboard', 'lnr-spell-check', 'lnr-screen', 'lnr-smartphone', 'lnr-tablet', 'lnr-laptop', 'lnr-laptop-phone', 'lnr-power-switch', 'lnr-bubble', 'lnr-heart-pulse', 'lnr-construction', 'lnr-pie-chart', 'lnr-chart-bars', 'lnr-gift', 'lnr-diamond', 'lnr-linearicons', 'lnr-dinner', 'lnr-coffee-cup', 'lnr-leaf', 'lnr-paw', 'lnr-rocket', 'lnr-briefcase', 'lnr-bus', 'lnr-car', 'lnr-train', 'lnr-bicycle', 'lnr-wheelchair', 'lnr-select', 'lnr-earth', 'lnr-smile', 'lnr-sad', 'lnr-neutral', 'lnr-mustache', 'lnr-alarm', 'lnr-bullhorn', 'lnr-volume-high', 'lnr-volume-medium', 'lnr-volume-low', 'lnr-volume', 'lnr-mic', 'lnr-hourglass', 'lnr-undo', 'lnr-redo', 'lnr-sync', 'lnr-history', 'lnr-clock', 'lnr-download', 'lnr-upload', 'lnr-enter-down', 'lnr-exit-up', 'lnr-bug', 'lnr-code', 'lnr-link', 'lnr-unlink', 'lnr-thumbs-up', 'lnr-thumbs-down', 'lnr-magnifier', 'lnr-cross', 'lnr-menu', 'lnr-list', 'lnr-chevron-up', 'lnr-chevron-down', 'lnr-chevron-left', 'lnr-chevron-right', 'lnr-arrow-up', 'lnr-arrow-down', 'lnr-arrow-left', 'lnr-arrow-right', 'lnr-move', 'lnr-warning', 'lnr-question-circle', 'lnr-menu-circle', 'lnr-checkmark-circle', 'lnr-cross-circle', 'lnr-plus-circle', 'lnr-circle-minus', 'lnr-arrow-up-circle', 'lnr-arrow-down-circle', 'lnr-arrow-left-circle', 'lnr-arrow-right-circle', 'lnr-chevron-up-circle', 'lnr-chevron-down-circle', 'lnr-chevron-left-circle', 'lnr-chevron-right-circle', 'lnr-crop', 'lnr-frame-expand', 'lnr-frame-contract', 'lnr-layers', 'lnr-funnel', 'lnr-text-format', 'lnr-text-format-remove', 'lnr-text-size', 'lnr-bold', 'lnr-italic', 'lnr-underline', 'lnr-strikethrough', 'lnr-highlight', 'lnr-text-align-left', 'lnr-text-align-center', 'lnr-text-align-right', 'lnr-text-align-justify', 'lnr-line-spacing', 'lnr-indent-increase', 'lnr-indent-decrease', 'lnr-pilcrow', 'lnr-direction-ltr', 'lnr-direction-rtl', 'lnr-page-break', 'lnr-sort-alpha-asc', 'lnr-sort-amount-asc', 'lnr-hand', 'lnr-pointer-up', 'lnr-pointer-right', 'lnr-pointer-down', 'lnr-pointer-left'
		);

		$icons = array_merge( $icons_awesome, $icons_icomoon, $icons_linearicon );

		return apply_filters( 'amwal_theme_icons', $icons );
	}

	/**
	 * Add new params or add new shortcode to VC
	 *
	 * @since 1.0
	 *
	 * @return void
	 */
	function map_shortcodes() {

		$attributes = array(
			array(
				'type'        => 'checkbox',
				'heading'     => esc_html__( 'Enable Background Full Width', 'amwal' ),
				'param_name'  => 'bg_full_width',
				'group'       => esc_html__( 'Design Options', 'amwal' ),
				'value'       => array( esc_html__( 'Enable', 'amwal' ) => 'yes' ),
				'description' => esc_html__( 'Enable this option if you want to have background on this column as full with. When you enable this option, please set background image or background color as "Theme defaults" to make it works.', 'amwal' ),
			),
		);
		vc_add_params( 'vc_column', $attributes );

		vc_remove_param( 'vc_row', 'parallax_image' );
		vc_remove_param( 'vc_row', 'parallax' );
		vc_remove_param( 'vc_row', 'parallax_speed_bg' );
		$attributes = array(
			array(
				'type'        => 'checkbox',
				'heading'     => esc_html__( 'Enable Parallax effect', 'amwal' ),
				'param_name'  => 'enable_parallax',
				'group'       => esc_html__( 'Design Options', 'amwal' ),
				'value'       => array( esc_html__( 'Enable', 'amwal' ) => 'yes' ),
				'description' => esc_html__( 'Enable this option if you want to have parallax effect on this row. When you enable this option, please set background repeat option as "Theme defaults" to make it works.', 'amwal' ),
			),
			array(
				'type'        => 'colorpicker',
				'heading'     => esc_html__( 'Overlay', 'amwal' ),
				'param_name'  => 'overlay',
				'group'       => esc_html__( 'Design Options', 'amwal' ),
				'value'       => '',
				'description' => esc_html__( 'Select an overlay color for this row', 'amwal' ),
			),
		);
		vc_add_params( 'vc_row', $attributes );


		// Add instagram shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Section Title', 'amwal' ),
				'base'     => 'amwal_section_title',
				'class'    => '',
				'category' => esc_html__( 'Content', 'amwal' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'amwal' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Style 1', 'amwal' ) => '1',
							esc_html__( 'Style 2', 'amwal' ) => '2',
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title content', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Subtitle', 'amwal' ),
						'param_name'  => 'subtitle',
						'value'       => '',
						'description' => esc_html__( 'Enter the subtitle', 'amwal' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),
					array(
						'type'        => 'textarea_html',
						'heading'     => esc_html__( 'Description', 'amwal' ),
						'param_name'  => 'content',
						'description' => esc_html__( 'Enter the description of section title', 'amwal' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Text Align', 'amwal' ),
						'param_name' => 'text_position',
						'value'      => array(
							esc_html__( 'Left ', 'amwal' )   => 'left',
							esc_html__( 'Center ', 'amwal' ) => 'center',
						),
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Light Skin', 'amwal' ),
						'param_name' => 'light_skin',
						'value'      => '',
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
					),
				),
			)
		);

		// Add job shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Job List', 'amwal' ),
				'base'     => 'amwal_job_list',
				'class'    => '',
				'category' => esc_html__( 'Amwal', 'amwal' ),
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'description' => esc_html__( 'Enter the title', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Number of job', 'amwal' ),
						'param_name'  => 'number',
						'value'       => 'All',
						'description' => esc_html__( 'Set numbers of Projects you want to display', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'amwal' ),
					)
				),
			)
		);


		// Add icon box shortcode
		vc_map(
			array(
				'name'              => esc_html__( 'Icon Box', 'amwal' ),
				'base'              => 'amwal_icon_box',
				'class'             => '',
				'category'          => esc_html__( 'Amwal', 'amwal' ),
				'admin_enqueue_css' => AMWAL_ADDONS_URL . '/assets/css/vc/icon-field.css',
				'params'            => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'amwal' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Style 1', 'amwal' ) => '1',
							esc_html__( 'Style 2', 'amwal' ) => '2',
						),
					),
					array(
						'type'       => 'icon',
						'heading'    => esc_html__( 'Icon', 'amwal' ),
						'param_name' => 'icon',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title of content', 'amwal' ),
					),
					array(
						'type'        => 'textarea_html',
						'heading'     => esc_html__( 'Description', 'amwal' ),
						'param_name'  => 'content',
						'value'       => '',
						'description' => esc_html__( 'Enter the content of this box', 'amwal' ),
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Text center', 'amwal' ),
						'param_name' => 'text_center',
						'value'      => array( esc_html__( 'Yes', 'amwal' ) => 'yes' ),
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),
					array(
						'type'       => 'vc_link',
						'heading'    => esc_html__( 'Link', 'amwal' ),
						'param_name' => 'link',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'amwal' ),
					)
				),
			)
		);

		// Add Counter shortcode
		vc_map(
			array(
				'name'              => esc_html__( 'Counter', 'amwal' ),
				'base'              => 'amwal_counter',
				'class'             => '',
				'category'          => esc_html__( 'Amwal', 'amwal' ),
				'admin_enqueue_css' => AMWAL_ADDONS_URL . '/assets/css/vc/icon-field.css',
				'params'            => array(
					array(
						'type'       => 'icon',
						'heading'    => esc_html__( 'Icon', 'amwal' ),
						'param_name' => 'icon',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Number', 'amwal' ),
						'param_name'  => 'number',
						'value'       => '',
						'description' => esc_html__( 'Enter the number of counter', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Description', 'amwal' ),
						'param_name'  => 'desc',
						'value'       => '',
						'description' => esc_html__( 'Enter the content of counter', 'amwal' ),
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Dark Text', 'amwal' ),
						'param_name' => 'dark_text',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'amwal' ),
					)
				),
			)
		);

		// Add images carousel shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Clients', 'amwal' ),
				'base'     => 'amwal_clients',
				'class'    => '',
				'category' => esc_html__( 'Amwal', 'amwal' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'amwal' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Grid', 'amwal' )     => '1',
							esc_html__( 'Carousel', 'amwal' ) => '2',
						),
					),
					array(
						'type'        => 'attach_images',
						'heading'     => esc_html__( 'Images', 'amwal' ),
						'param_name'  => 'images',
						'value'       => '',
						'description' => esc_html__( 'Select images from media library', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Image size', 'amwal' ),
						'param_name'  => 'image_size',
						'value'       => '',
						'description' => esc_html__( 'Enter image size . Example: thumbnail, medium, large, full . Leave empty to use "thumbnail" size . ', 'amwal' ),
					),
					array(
						'type'        => 'exploded_textarea_safe',
						'heading'     => esc_html__( 'Custom links', 'amwal' ),
						'param_name'  => 'custom_links',
						'description' => esc_html__( 'Enter links for each slide here. Divide links with linebreaks (Enter).', 'amwal' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Custom link target', 'amwal' ),
						'param_name'  => 'custom_links_target',
						'value'       => array(
							esc_html__( 'Same window', 'amwal' ) => '_self',
							esc_html__( 'New window', 'amwal' )  => '_blank',
						),
						'description' => esc_html__( 'Select where to open custom links.', 'amwal' ),
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Hide Border Image', 'amwal' ),
						'param_name' => 'hide_border',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Slider autoplay', 'amwal' ),
						'param_name'  => 'autoplay',
						'value'       => 0,
						'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'amwal' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '2' )
						),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Hide navigation', 'amwal' ),
						'param_name'  => 'navigation',
						'value'       => array( esc_html__( 'Yes', 'amwal' ) => 'false' ),
						'description' => esc_html__( 'If "YES" prev / next control will be removed . ', 'amwal' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '2' )
						),
					),

					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Hide Pagination', 'amwal' ),
						'param_name'  => 'pagination',
						'value'       => array( esc_html__( 'Yes', 'amwal' ) => 'yes' ),
						'description' => esc_html__( 'If "YES" pagination control will be removed.', 'amwal' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '2' )
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'amwal' ),
					),
				),
			)
		);

		// Add Service Shortcode
		vc_map(
			array(
				'name'            => esc_html__( 'Amwal Services', 'amwal' ),
				'base'            => 'amwal_services',
				'as_parent'       => array( 'only' => 'amwal_service' ),
				'category'        => esc_html__( 'Amwal', 'amwal' ),
				'content_element' => true,
				'params'          => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'amwal' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Style 1', 'amwal' ) => '1',
							esc_html__( 'Style 2', 'amwal' ) => '2',
							esc_html__( 'Style 3', 'amwal' ) => '3',
						),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Number of column', 'amwal' ),
						'param_name' => 'number',
						'value'      => array(
							esc_html__( '4 Columns', 'amwal' ) => '4',
							esc_html__( '3 Columns', 'amwal' ) => '3',
						),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Services View', 'amwal' ),
						'param_name' => 'services_view',
						'value'      => array(
							esc_html__( 'Carousel', 'amwal' ) => '1',
							esc_html__( 'Grid', 'amwal' )     => '0',
						),
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Service Background Transparent', 'amwal' ),
						'param_name' => 'service_transparent',
						'value'      => '',
						'dependency' => array(
							'element' => 'services_view',
							'value'   => array( '1' )
						),
					),

					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Light Text', 'amwal' ),
						'param_name' => 'light_text',
						'value'      => '',
						'dependency' => array(
							'element' => 'services_view',
							'value'   => array( '1' )
						),
					),
					array(
						'type'       => 'vc_link',
						'heading'    => esc_html__( 'Link', 'amwal' ),
						'param_name' => 'link',
						'value'      => '',
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Slider autoplay', 'amwal' ),
						'param_name'  => 'autoplay',
						'value'       => 0,
						'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'amwal' ),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Show Padding', 'amwal' ),
						'param_name'  => 'padding',
						'value'       => array( esc_html__( 'Yes', 'amwal' ) => 'yes' ),
						'description' => esc_html__( 'If "YES" service item will has padding.', 'amwal' ),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Hide Button', 'amwal' ),
						'param_name'  => 'hide_btn',
						'value'       => array( esc_html__( 'Yes', 'amwal' ) => 'yes' ),
						'description' => esc_html__( 'If "YES" button on service item will be hided.', 'amwal' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '2' )
						),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Hide Pagination', 'amwal' ),
						'param_name'  => 'pagination',
						'value'       => array( esc_html__( 'Yes', 'amwal' ) => 'yes' ),
						'description' => esc_html__( 'If "YES" pagination control will be removed.', 'amwal' ),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Hide Navigation', 'amwal' ),
						'param_name'  => 'navigation',
						'value'       => array( esc_html__( 'Yes', 'amwal' ) => 'false' ),
						'description' => esc_html__( 'If "YES" navigation control will be removed.', 'amwal' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
					),
				),
				'js_view'         => 'VcColumnView'
			)
		);

		vc_map(
			array(
				'name'              => esc_html__( 'Amwal Service', 'amwal' ),
				'base'              => 'amwal_service',
				'content_element'   => true,
				'as_child'          => array( 'only' => 'amwal_services' ),
				'admin_enqueue_css' => AMWAL_ADDONS_URL . '/assets/css/vc/icon-field.css',
				'params'            => array(
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Image', 'amwal' ),
						'param_name'  => 'image',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Image Size', 'amwal' ),
						'param_name'  => 'image_size',
						'value'       => '',
						'description' => esc_html__( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 970x534 (Width x Height)).', 'amwal' ),
					),
					array(
						'type'       => 'icon',
						'heading'    => esc_html__( 'Icon', 'amwal' ),
						'param_name' => 'icon',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title of content', 'amwal' ),
					),
					array(
						'type'        => 'textarea_html',
						'heading'     => esc_html__( 'Description', 'amwal' ),
						'param_name'  => 'content',
						'value'       => '',
						'description' => esc_html__( 'Enter the content of this box', 'amwal' ),
					),
					array(
						'type'       => 'vc_link',
						'heading'    => esc_html__( 'Link', 'amwal' ),
						'param_name' => 'link',
						'value'      => '',
					),
				)
			)
		);


		// Add Contact Info Shortcode
		vc_map(
			array(
				'name'            => esc_html__( 'Amwal Contacts Info', 'amwal' ),
				'base'            => 'amwal_contacts_info',
				'as_parent'       => array( 'only' => 'amwal_contact_info' ),
				'category'        => esc_html__( 'Amwal', 'amwal' ),
				'content_element' => true,
				'params'          => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'amwal' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Carousel', 'amwal' ) => '1',
							esc_html__( 'Grid', 'amwal' )     => '2',
						),
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Show item box shadow', 'amwal' ),
						'param_name' => 'box_shadow',
						'value'      => '',
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Slider autoplay', 'amwal' ),
						'param_name'  => 'autoplay',
						'value'       => 0,
						'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'amwal' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Hide Pagination', 'amwal' ),
						'param_name'  => 'pagination',
						'value'       => array( esc_html__( 'Yes', 'amwal' ) => 'yes' ),
						'description' => esc_html__( 'If "YES" pagination control will be removed.', 'amwal' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
					),
				),
				'js_view'         => 'VcColumnView'
			)
		);

		vc_map(
			array(
				'name'            => esc_html__( 'Amwal Contact Info', 'amwal' ),
				'base'            => 'amwal_contact_info',
				'content_element' => true,
				'as_child'        => array( 'only' => 'amwal_contacts_info' ),
				'params'          => array(

					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title of content', 'amwal' ),
					),
					array(
						'type'        => 'textarea_html',
						'heading'     => esc_html__( 'Description', 'amwal' ),
						'param_name'  => 'content',
						'value'       => '',
						'description' => esc_html__( 'Enter the content of this box', 'amwal' ),
					),
				)
			)
		);

		// Add Planning Steps Shortcode
		vc_map(
			array(
				'name'            => esc_html__( 'Amwal Planning Steps', 'amwal' ),
				'base'            => 'amwal_planning_steps',
				'as_parent'       => array( 'only' => 'amwal_planning_step' ),
				'category'        => esc_html__( 'Amwal', 'amwal' ),
				'content_element' => true,
				'params'          => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Slider autoplay', 'amwal' ),
						'param_name'  => 'autoplay',
						'value'       => 0,
						'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'amwal' ),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Hide navigation', 'amwal' ),
						'param_name'  => 'navigation',
						'value'       => array( esc_html__( 'Yes', 'amwal' ) => 'false' ),
						'description' => esc_html__( 'If "YES" prev / next control will be removed . ', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
					),
				),
				'js_view'         => 'VcColumnView'
			)
		);

		vc_map(
			array(
				'name'            => esc_html__( 'Amwal Planning Step', 'amwal' ),
				'base'            => 'amwal_planning_step',
				'content_element' => true,
				'as_child'        => array( 'only' => 'amwal_planning_steps' ),
				'params'          => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Number', 'amwal' ),
						'param_name'  => 'number',
						'value'       => '',
						'description' => esc_html__( 'Enter the number of step', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title of content', 'amwal' ),
					),
					array(
						'type'        => 'textarea_html',
						'heading'     => esc_html__( 'Description', 'amwal' ),
						'param_name'  => 'content',
						'value'       => '',
						'description' => esc_html__( 'Enter the content of this box', 'amwal' ),
					),
				)
			)
		);

		// Add Abouts Carousel Shortcode
		vc_map(
			array(
				'name'            => esc_html__( 'Amwal Abouts Carousel', 'amwal' ),
				'base'            => 'amwal_abouts_carousel',
				'as_parent'       => array( 'only' => 'amwal_about_carousel' ),
				'category'        => esc_html__( 'Amwal', 'amwal' ),
				'content_element' => true,
				'params'          => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title content', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Subtitle', 'amwal' ),
						'param_name'  => 'subtitle',
						'value'       => '',
						'description' => esc_html__( 'Enter the subtitle', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Slider autoplay', 'amwal' ),
						'param_name'  => 'autoplay',
						'value'       => 0,
						'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'amwal' ),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Hide Pagination', 'amwal' ),
						'param_name'  => 'pagination',
						'value'       => array( esc_html__( 'Yes', 'amwal' ) => 'yes' ),
						'description' => esc_html__( 'If "YES" pagination control will be removed.', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
					),
				),
				'js_view'         => 'VcColumnView'
			)
		);

		vc_map(
			array(
				'name'              => esc_html__( 'Amwal About Carousel', 'amwal' ),
				'base'              => 'amwal_about_carousel',
				'content_element'   => true,
				'as_child'          => array( 'only' => 'amwal_abouts_carousel' ),
				'admin_enqueue_css' => AMWAL_ADDONS_URL . '/assets/css/vc/icon-field.css',
				'params'            => array(
					array(
						'type'       => 'icon',
						'heading'    => esc_html__( 'Icon', 'amwal' ),
						'param_name' => 'icon',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title of content', 'amwal' ),
					),
					array(
						'type'        => 'textarea_html',
						'heading'     => esc_html__( 'Description', 'amwal' ),
						'param_name'  => 'content',
						'value'       => '',
						'description' => esc_html__( 'Enter the content of this box', 'amwal' ),
					),
					array(
						'type'       => 'vc_link',
						'heading'    => esc_html__( 'Link', 'amwal' ),
						'param_name' => 'link',
						'value'      => '',
					),
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Image', 'amwal' ),
						'param_name'  => 'image',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'amwal' ),
					),
				)
			)
		);

		// Add Line Charts Shortcode
		vc_map(
			array(
				'name'            => esc_html__( 'Amwal Line Charts', 'amwal' ),
				'base'            => 'amwal_line_charts',
				'as_parent'       => array( 'only' => 'amwal_line_chart' ),
				'category'        => esc_html__( 'Amwal', 'amwal' ),
				'content_element' => true,
				'params'          => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Width', 'amwal' ),
						'param_name'  => 'width',
						'value'       => 0,
						'description' => esc_html__( 'Enter width in pixels ( Example: 300 ).', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Height', 'amwal' ),
						'param_name'  => 'height',
						'value'       => 0,
						'description' => esc_html__( 'Enter height in pixels ( Example: 300 ).', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Label', 'amwal' ),
						'param_name'  => 'label',
						'value'       => '27 May|29 May',
						'description' => esc_html__( 'Enter the label in this format "A|B" to add new element.', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title of line chart."', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
					),
				),
				'js_view'         => 'VcColumnView'
			)
		);

		vc_map(
			array(
				'name'            => esc_html__( 'Amwal Line Chart', 'amwal' ),
				'base'            => 'amwal_line_chart',
				'content_element' => true,
				'as_child'        => array( 'only' => 'amwal_line_charts' ),
				'params'          => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title of content', 'amwal' ),
					),
					array(
						'type'        => 'colorpicker',
						'heading'     => esc_html__( 'Background Color', 'amwal' ),
						'param_name'  => 'bg_color',
						'value'       => '',
						'description' => esc_html__( 'Select an color for this background', 'amwal' ),
					),
					array(
						'type'        => 'colorpicker',
						'heading'     => esc_html__( 'Border Color', 'amwal' ),
						'param_name'  => 'bd_color',
						'value'       => '',
						'description' => esc_html__( 'Select an color for this border', 'amwal' ),
					),
					array(
						'type'        => 'colorpicker',
						'heading'     => esc_html__( 'Point Border Color', 'amwal' ),
						'param_name'  => 'point_bd_color',
						'value'       => '',
						'description' => esc_html__( 'Select an color for this point border color', 'amwal' ),
					),
					array(
						'type'        => 'colorpicker',
						'heading'     => esc_html__( 'Point Background Color', 'amwal' ),
						'param_name'  => 'point_bg_color',
						'value'       => '',
						'description' => esc_html__( 'Select an color for this point background color', 'amwal' ),
					),
					array(
						'type'        => 'colorpicker',
						'heading'     => esc_html__( 'Point Hover Border Color', 'amwal' ),
						'param_name'  => 'point_hover_bd',
						'value'       => '',
						'description' => esc_html__( 'Select an color for this point hover border color', 'amwal' ),
					),
					array(
						'type'        => 'colorpicker',
						'heading'     => esc_html__( 'Point Hover Background Color', 'amwal' ),
						'param_name'  => 'point_hover_bg',
						'value'       => '',
						'description' => esc_html__( 'Select an color for this point hover background color', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Data', 'amwal' ),
						'param_name'  => 'data',
						'value'       => '11|20',
						'description' => esc_html__( 'Enter the label in this format "A|B" to add new data value.', 'amwal' ),
					),
				)
			)
		);

		// Add Line Charts Shortcode
		vc_map(
			array(
				'name'            => esc_html__( 'Amwal Bar Charts', 'amwal' ),
				'base'            => 'amwal_bar_charts',
				'as_parent'       => array( 'only' => 'amwal_bar_chart' ),
				'category'        => esc_html__( 'Amwal', 'amwal' ),
				'content_element' => true,
				'params'          => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Label', 'amwal' ),
						'param_name'  => 'label',
						'value'       => '27 May|29 May',
						'description' => esc_html__( 'Enter the label in this format "A|B" to add new element.', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
					),
				),
				'js_view'         => 'VcColumnView'
			)
		);

		vc_map(
			array(
				'name'            => esc_html__( 'Amwal Bar Chart', 'amwal' ),
				'base'            => 'amwal_bar_chart',
				'content_element' => true,
				'as_child'        => array( 'only' => 'amwal_bar_charts' ),
				'params'          => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title of content', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Data', 'amwal' ),
						'param_name'  => 'data',
						'value'       => '11|20',
						'description' => esc_html__( 'Enter the label in this format "A|B" to add new data value.', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Backgroud Color', 'amwal' ),
						'param_name'  => 'bg_color',
						'value'       => 'rgba(255, 99, 132, 0.2)|rgba(54, 162, 235, 0.2)',
						'description' => esc_html__( 'Enter the label in this format "A|B" to add new color.', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Border Color', 'amwal' ),
						'param_name'  => 'bd_color',
						'value'       => 'rgba(255,99,132,1)|rgba(54, 162, 235, 1)',
						'description' => esc_html__( 'Enter the label in this format "A|B" to add new color.', 'amwal' ),
					),
				)
			)
		);

		// Add Round Charts Shortcode
		vc_map(
			array(
				'name'            => esc_html__( 'Amwal Round Charts', 'amwal' ),
				'base'            => 'amwal_pie_doughnut',
				'category'        => esc_html__( 'Amwal', 'amwal' ),
				'content_element' => true,
				'params'          => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Type', 'amwal' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Doughnut', 'amwal' ) => 'doughnut',
							esc_html__( 'Pie', 'amwal' )      => 'pie',
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Width', 'amwal' ),
						'param_name'  => 'width',
						'value'       => 0,
						'description' => esc_html__( 'Enter width in pixels ( Example: 300 (300px) ).', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Height', 'amwal' ),
						'param_name'  => 'height',
						'value'       => 0,
						'description' => esc_html__( 'Enter height in pixels ( Example: 300 (300px) ).', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Label', 'amwal' ),
						'param_name'  => 'label',
						'value'       => 'Red|Blue|Yellow',
						'description' => esc_html__( 'Enter the label in this format "A|B" to add new element.', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Background Color', 'amwal' ),
						'param_name'  => 'bg_color',
						'value'       => '#FF6384|#36A2EB|#FFCE56',
						'description' => esc_html__( 'Enter the label in this format "A|B" to add new color.', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Hover Background Color', 'amwal' ),
						'param_name'  => 'hover_bg_color',
						'value'       => '#FF6384|#36A2EB|#FFCE56',
						'description' => esc_html__( 'Enter the label in this format "A|B" to add new color.', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Data', 'amwal' ),
						'param_name'  => 'data',
						'value'       => '300|50|100',
						'description' => esc_html__( 'Enter the label in this format "A|B" to add new value.', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
					),
				),
			)
		);

		// Add Polar Are Charts Shortcode
		vc_map(
			array(
				'name'            => esc_html__( 'Amwal Polar Area Charts', 'amwal' ),
				'base'            => 'amwal_polar_area',
				'category'        => esc_html__( 'Amwal', 'amwal' ),
				'content_element' => true,
				'params'          => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Width', 'amwal' ),
						'param_name'  => 'width',
						'value'       => 0,
						'description' => esc_html__( 'Enter width in pixels ( Example: 300 (300px) ).', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Height', 'amwal' ),
						'param_name'  => 'height',
						'value'       => 0,
						'description' => esc_html__( 'Enter height in pixels ( Example: 300 (300px) ).', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Labels', 'amwal' ),
						'param_name'  => 'label',
						'value'       => 'Red|Blue|Yellow|Green|Grey',
						'description' => esc_html__( 'Enter the label in this format "A|B" to add new element.', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => 'My dataset',
						'description' => esc_html__( 'Enter the label for dataset.', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Background Color', 'amwal' ),
						'param_name'  => 'bg_color',
						'value'       => '#FF6384|#4BC0C0|#FFCE56|#E7E9ED|#36A2EB',
						'description' => esc_html__( 'Enter the label in this format "A|B" to add new color.', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Data', 'amwal' ),
						'param_name'  => 'data',
						'value'       => '11|16|7|3|14',
						'description' => esc_html__( 'Enter the label in this format "A|B" to add new value.', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
					),
				),
			)
		);

		// Add Portfolio shortcode
		if ( post_type_exists( 'portfolio_project' ) && taxonomy_exists( 'portfolio_category' ) ) {

			vc_map(
				array(
					'name'     => esc_html__( 'Amwal Portfolio', 'amwal' ),
					'base'     => 'amwal_portfolio',
					'class'    => '',
					'category' => esc_html__( 'Amwal', 'amwal' ),
					'params'   => array(
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Style', 'amwal' ),
							'param_name' => 'style',
							'value'      => array(
								esc_html__( 'Masonry', 'amwal' )  => '1',
								esc_html__( 'Grid', 'amwal' )     => '2',
								esc_html__( 'Carousel', 'amwal' ) => '3',
							),
						),
						array(
							'type'       => 'textfield',
							'heading'    => esc_html__( 'Total Posts', 'amwal' ),
							'param_name' => 'total',
							'value'      => '4',
						),
						array(
							'type'       => 'checkbox',
							'heading'    => esc_html__( 'Show padding', 'amwal' ),
							'param_name' => 'show_padding',
							'value'      => '',
						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Number of column', 'amwal' ),
							'param_name' => 'number',
							'value'      => array(
								esc_html__( '4 Columns', 'amwal' ) => '4',
								esc_html__( '3 Columns', 'amwal' ) => '3',
								esc_html__( '2 Columns', 'amwal' ) => '2',
							),
							'dependency' => array(
								'element' => 'style',
								'value'   => array( '3' )
							),

						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Filter Position', 'amwal' ),
							'param_name' => 'filter_position',
							'value'      => array(
								esc_html__( 'Center', 'amwal' ) => 'center',
								esc_html__( 'Right', 'amwal' )  => 'right',
							),
							'dependency' => array(
								'element' => 'style',
								'value'   => array( '2' )
							),

						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Button Position', 'amwal' ),
							'param_name' => 'button_position',
							'value'      => array(
								esc_html__( 'Top Right', 'amwal' )     => 'top',
								esc_html__( 'Bottom Center', 'amwal' ) => 'bottom',
							),
							'dependency' => array(
								'element' => 'style',
								'value'   => array( '1' )
							),

						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Slider autoplay', 'amwal' ),
							'param_name'  => 'autoplay',
							'value'       => '0',
							'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'amwal' ),
							'dependency'  => array(
								'element' => 'style',
								'value'   => array( '3' )
							),
						),
						array(
							'type'        => 'checkbox',
							'heading'     => esc_html__( 'Hide Pagination', 'amwal' ),
							'param_name'  => 'pagination',
							'value'       => array( esc_html__( 'Yes', 'amwal' ) => 'yes' ),
							'description' => esc_html__( 'If "YES" pagination control will be removed.', 'amwal' ),
							'dependency'  => array(
								'element' => 'style',
								'value'   => array( '3' )
							),
						),
						array(
							'type'       => 'vc_link',
							'heading'    => esc_html__( 'Link', 'amwal' ),
							'param_name' => 'link',
							'value'      => '',
							'dependency' => array(
								'element' => 'style',
								'value'   => array( '1' )
							),
						),
						array(
							'type'       => 'checkbox',
							'heading'    => esc_html__( 'Show Filter Category', 'amwal' ),
							'param_name' => 'show_filter',
							'value'      => '',
							'dependency' => array(
								'element' => 'style',
								'value'   => array( '1', '2' )
							),
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Extra class name', 'amwal' ),
							'param_name'  => 'el_class',
							'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
						),
					),
				)
			);
		}

		// Add Testimonials Shortcode
		if ( post_type_exists( 'testimonial' ) && taxonomy_exists( 'testimonial_category' ) ) {
			$categories = get_terms( 'testimonial_category' );
			$cats       = array( esc_html__( 'All Categories', 'amwal' ) => '' );
			foreach ( $categories as $category ) {
				$cats[$category->name] = $category->slug;
			}
			vc_map(
				array(
					'name'        => esc_html__( 'Testimonials', 'amwal' ),
					'description' => esc_html__( 'Testimonial carousel', 'amwal' ),
					'base'        => 'amwal_testimonials',
					'class'       => '',
					'category'    => esc_html__( 'Amwal', 'amwal' ),
					'params'      => array(
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Style', 'amwal' ),
							'param_name' => 'style',
							'value'      => array(
								esc_html__( 'Style 1', 'amwal' ) => '1',
								esc_html__( 'Style 2', 'amwal' ) => '2',
							),
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Number', 'amwal' ),
							'param_name'  => 'number',
							'value'       => 3,
							'admin_label' => true,
							'description' => esc_html__( 'Number of testimonials', 'amwal' ),
						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Category', 'amwal' ),
							'param_name' => 'category',
							'value'      => $cats,
						),
						array(
							'type'       => 'checkbox',
							'heading'    => esc_html__( 'Light Skin', 'amwal' ),
							'param_name' => 'light_skin',
							'value'      => '',
						),
						array(
							'type'        => 'checkbox',
							'heading'     => esc_html__( 'Hide avatar', 'amwal' ),
							'param_name'  => 'hide_avatar',
							'value'       => '',
							'description' => esc_html__( 'If "YES" testimonial avatar will be removed . ', 'amwal' ),
							'dependency'  => array(
								'element' => 'style',
								'value'   => array( '2' )
							),
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Slider autoplay', 'amwal' ),
							'param_name'  => 'autoplay',
							'value'       => '0',
							'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'amwal' ),
						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Pagination position', 'amwal' ),
							'param_name' => 'pagi_position',
							'value'      => array(
								esc_html__( 'Top', 'amwal' )    => 'top',
								esc_html__( 'Bottom', 'amwal' ) => 'bottom',
							),
							'dependency' => array(
								'element' => 'style',
								'value'   => array( '1' )
							),
						),
						array(
							'type'        => 'checkbox',
							'heading'     => esc_html__( 'Hide Pagination', 'amwal' ),
							'param_name'  => 'pagination',
							'value'       => array( esc_html__( 'Yes', 'amwal' ) => 'yes' ),
							'description' => esc_html__( 'If "YES" pagination control will be removed.', 'amwal' ),
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Extra class name', 'amwal' ),
							'param_name'  => 'el_class',
							'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'amwal' ),
						),
					),
				)
			);
		}

		vc_map(
			array(
				'name'     => esc_html__( 'Amwal Image Box', 'amwal' ),
				'base'     => 'amwal_image_box',
				'class'    => '',
				'category' => esc_html__( 'Amwal', 'amwal' ),
				'params'   => array(
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Image', 'amwal' ),
						'param_name'  => 'image',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Image Size', 'amwal' ),
						'param_name'  => 'image_size',
						'value'       => '',
						'description' => esc_html__( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 970x534 (Width x Height)).', 'amwal' ),
					),

					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title of content', 'amwal' ),
					),
					array(
						'type'        => 'textarea_html',
						'heading'     => esc_html__( 'Description', 'amwal' ),
						'param_name'  => 'content',
						'value'       => '',
						'description' => esc_html__( 'Enter the content of this box', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
					),
				)
			)
		);


		// Add Contact Form 7 shortcode
		// get form id of Contact Form
		$contact_forms    = get_posts( 'post_type=wpcf7_contact_form&posts_per_page=-1' );
		$contact_form_ids = array();

		if ( is_array( $contact_forms ) ) {
			foreach ( $contact_forms as $form ) {
				$contact_form_ids[$form->post_title] = $form->ID;
			}
			vc_map(
				array(
					'name'     => esc_html__( 'Amwal Contact Form 7', 'amwal' ),
					'base'     => 'amwal_contact_form',
					'class'    => '',
					'category' => esc_html__( 'Amwal', 'amwal' ),
					'params'   => array(
						array(
							'type'       => 'checkbox',
							'heading'    => esc_html__( 'Light Skin', 'amwal' ),
							'param_name' => 'light_skin',
							'value'      => '',
						),
						array(
							'type'       => 'dropdown',
							'heading'    => esc_html__( 'Contact Form', 'amwal' ),
							'param_name' => 'form',
							'value'      => $contact_form_ids,
						),
						array(
							'type'        => 'textfield',
							'heading'     => esc_html__( 'Extra class name', 'amwal' ),
							'param_name'  => 'el_class',
							'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
						),
					),
				)
			);
		}


		// Add Info box shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Info Box', 'amwal' ),
				'base'     => 'amwal_info_box',
				'class'    => '',
				'category' => esc_html__( 'Amwal', 'amwal' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'amwal' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Style 1', 'amwal' ) => '1',
							esc_html__( 'Style 2', 'amwal' ) => '2',
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Time Between', 'amwal' ),
						'param_name'  => 'between',
						'value'       => esc_html__( 'Mon-Sat|10.00am - 6.00p.m', 'amwal' ),
						'description' => esc_html__( 'Enter the title in this format "A|B and the B element has padding left."', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Time Final', 'amwal' ),
						'param_name'  => 'final',
						'value'       => esc_html__( 'Sun|11.30am - 3.00p.m', 'amwal' ),
						'description' => esc_html__( 'Enter the title in this format "A|B and the B element has padding left."', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Phone Number', 'amwal' ),
						'param_name'  => 'phone',
						'value'       => '',
						'description' => esc_html__( 'Enter the Phone number', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Email', 'amwal' ),
						'param_name'  => 'email',
						'value'       => '',
						'description' => esc_html__( 'Enter the Email', 'amwal' ),
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Light Text', 'amwal' ),
						'param_name' => 'light_skin',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'amwal' ),
					)
				),
			)
		);

		// Add newsletter shortcode
		// get form id of mailchimp
		$mail_forms    = get_posts( 'post_type=mc4wp-form&number=-1' );
		$mail_form_ids = array();
		foreach ( $mail_forms as $form ) {
			$mail_form_ids[$form->post_title] = $form->ID;
		}
		vc_map(
			array(
				'name'     => esc_html__( 'Newsletter', 'amwal' ),
				'base'     => 'amwal_newsletter',
				'class'    => '',
				'category' => esc_html__( 'Amwal', 'amwal' ),
				'params'   => array(
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Light Text', 'amwal' ),
						'param_name' => 'light_skin',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Sub Title', 'amwal' ),
						'param_name' => 'sub_title',
						'value'      => '',
					),
					array(
						'type'        => 'textarea_html',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'content',
						'value'       => '',
						'description' => esc_html__( 'Enter the title', 'amwal' ),
					),

					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Mailchimp Form', 'amwal' ),
						'param_name' => 'form',
						'value'      => $mail_form_ids,
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
					),
				),
			)
		);

		// Shortcode Call to action
		vc_map(
			array(
				'name'     => esc_html__( 'Call To Action', 'amwal' ),
				'base'     => 'amwal_cta',
				'class'    => '',
				'category' => esc_html__( 'Amwal', 'amwal' ),
				'params'   => array(
					array(
						'type'        => 'textarea_html',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'content',
						'value'       => '',
						'description' => esc_html__( 'Enter the title', 'amwal' ),
					),
					array(
						'type'       => 'vc_link',
						'heading'    => esc_html__( 'Link', 'amwal' ),
						'param_name' => 'link',
						'value'      => '',
					),

					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Light Skin', 'amwal' ),
						'param_name' => 'light_skin',
						'value'      => '',
					),

					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
					),
				),
			)
		);

		// Add pricing shortcode
		vc_map(
			array(
				'name'     => __( 'Pricing Table', 'amwal' ),
				'base'     => 'amwal_pricing',
				'class'    => '',
				'category' => __( 'Content', 'amwal' ),
				'params'   => array(
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Featured', 'amwal' ),
						'param_name' => 'featured',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Title', 'amwal' ),
						'param_name' => 'title',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Price', 'amwal' ),
						'param_name' => 'price',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Unit', 'amwal' ),
						'param_name' => 'unit',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Time Duration', 'amwal' ),
						'param_name' => 'time_duration',
						'value'      => '',
					),
					array(
						'type'        => 'textarea_html',
						'heading'     => __( 'Description', 'amwal' ),
						'param_name'  => 'content',
						'value'       => '',
						'description' => esc_html__( 'Enter a short description', 'amwal' ),
					),
					array(
						'type'       => 'vc_link',
						'heading'    => esc_html__( 'Button', 'amwal' ),
						'param_name' => 'link',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'amwal' ),
					)
				),
			)
		);

		// Add posts carousel shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Amwal Posts', 'amwal' ),
				'base'     => 'amwal_posts',
				'class'    => '',
				'category' => esc_html__( 'Amwal', 'amwal' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Posts View', 'amwal' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Carousel', 'amwal' ) => '1',
							esc_html__( 'Grid', 'amwal' )     => '2',
						),

					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title content', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Subtitle', 'amwal' ),
						'param_name'  => 'subtitle',
						'value'       => '',
						'description' => esc_html__( 'Enter the subtitle', 'amwal' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Number of column', 'amwal' ),
						'param_name' => 'number',
						'value'      => array(
							esc_html__( '4 Columns', 'amwal' ) => '4',
							esc_html__( '3 Columns', 'amwal' ) => '3',
							esc_html__( '2 Columns', 'amwal' ) => '2',
						),

					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Total Posts', 'amwal' ),
						'param_name' => 'total',
						'value'      => '4',
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Category', 'amwal' ),
						'param_name'  => 'category',
						'value'       => $this->get_categories(),
						'description' => esc_html__( 'Select a category or all categories.', 'amwal' ),
					),
					array(
						'type'       => 'vc_link',
						'heading'    => esc_html__( 'Link', 'amwal' ),
						'param_name' => 'link',
						'value'      => '',
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '2' )
						),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Show Padding', 'amwal' ),
						'param_name'  => 'padding',
						'value'       => '',
						'description' => esc_html__( 'If "YES" post item will has padding.', 'amwal' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Pagination Position', 'amwal' ),
						'param_name' => 'pag_position',
						'value'      => array(
							esc_html__( 'Top', 'amwal' )    => 'top',
							esc_html__( 'Bottom', 'amwal' ) => 'bottom',
						),
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '1' )
						),

					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Slider autoplay', 'amwal' ),
						'param_name'  => 'autoplay',
						'value'       => '0',
						'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'amwal' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Hide Pagination', 'amwal' ),
						'param_name'  => 'pagination',
						'value'       => array( esc_html__( 'Yes', 'amwal' ) => 'yes' ),
						'description' => esc_html__( 'If "YES" pagination control will be removed.', 'amwal' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
					),
				),
			)
		);

		// Add team shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Team', 'amwal' ),
				'base'     => 'amwal_team',
				'class'    => '',
				'category' => esc_html__( 'Content', 'amwal' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Type', 'amwal' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Carousel', 'amwal' ) => '1',
							esc_html__( 'Grid', 'amwal' )     => '2',
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Total members', 'amwal' ),
						'param_name'  => 'total',
						'value'       => '4',
						'description' => esc_html__( 'Set numbers of members to show . ', 'amwal' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Team Groups', 'amwal' ),
						'param_name'  => 'groupteams',
						'value'       => $this->get_teamgroups(),
						'description' => esc_html__( 'Select team groups.', 'amwal' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Number of column', 'amwal' ),
						'param_name' => 'number',
						'value'      => array(
							esc_html__( '4 Columns', 'amwal' ) => '4',
							esc_html__( '3 Columns', 'amwal' ) => '3',
							esc_html__( '2 Columns', 'amwal' ) => '2',
						),
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Slider autoplay', 'amwal' ),
						'param_name'  => 'autoplay',
						'value'       => '0',
						'description' => esc_html__( 'Duration of animation between slides (in ms). Enter the value is 0 or empty if you want the slider is not autoplay', 'amwal' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),

					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Navigation Position', 'amwal' ),
						'param_name' => 'nav_position',
						'value'      => array(
							esc_html__( 'Center', 'amwal' ) => 'center',
							esc_html__( 'Top', 'amwal' )    => 'top',
						),
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),

					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Hide navigation', 'amwal' ),
						'param_name'  => 'navigation',
						'value'       => array( esc_html__( 'Yes', 'amwal' ) => 'false' ),
						'description' => esc_html__( 'If "YES" prev / next control will be removed . ', 'amwal' ),
						'dependency'  => array(
							'element' => 'style',
							'value'   => array( '1' )
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'amwal' ),
					)
				),
			)
		);

		// Video Banner
		vc_map(
			array(
				'name'     => esc_html__( 'Video Banner', 'amwal' ),
				'base'     => 'amwal_video',
				'category' => esc_html__( 'Amwal', 'amwal' ),
				'params'   => array(
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Video file URL', 'amwal' ),
						'param_name' => 'video',
						'value'      => '',
					),
					array(
						'type'       => 'attach_image',
						'heading'    => esc_html__( 'Poster Image', 'amwal' ),
						'param_name' => 'image',
					),

					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Video title', 'amwal' ),
						'description' => esc_html__( 'Enter the title of video', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
					),
					array(
						'type'        => 'checkbox',
						'heading'     => esc_html__( 'Enable Poster Full Width', 'amwal' ),
						'param_name'  => 'poster_full_width',
						'value'       => '',
						'description' => esc_html__( 'Enable this option if you want to have poster on this video as full with. When you enable this option, please set poster images to make it works.', 'amwal' ),
					),

					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'amwal' ),
					),
				),
			)
		);

		// Add instagram shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Company History', 'amwal' ),
				'base'     => 'amwal_company_history',
				'class'    => '',
				'category' => esc_html__( 'Content', 'amwal' ),
				'params'   => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'amwal' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Style 1', 'amwal' ) => '1',
							esc_html__( 'Style 2', 'amwal' ) => '2',
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Year', 'amwal' ),
						'param_name'  => 'year',
						'value'       => '',
						'description' => esc_html__( 'Enter the year', 'amwal' ),

					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title content', 'amwal' ),
					),
					array(
						'type'        => 'textarea_html',
						'heading'     => esc_html__( 'Description', 'amwal' ),
						'param_name'  => 'content',
						'description' => esc_html__( 'Enter the description of section title', 'amwal' ),

					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Hide Padding Bottom', 'amwal' ),
						'param_name' => 'hide_padding',
						'value'      => '',
						'dependency' => array(
							'element' => 'style',
							'value'   => array( '2' )
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
					),
				),
			)
		);


		vc_map(
			array(
				'name'     => esc_html__( 'Amwal Portfolio Info', 'amwal' ),
				'base'     => 'amwal_portfolio_info',
				'class'    => '',
				'category' => esc_html__( 'Amwal', 'amwal' ),
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title of content', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Subtitle', 'amwal' ),
						'param_name'  => 'subtitle',
						'value'       => '',
						'description' => esc_html__( 'Enter the subtitle', 'amwal' ),
					),

					array(
						'type'        => 'textarea_html',
						'heading'     => esc_html__( 'Description', 'amwal' ),
						'param_name'  => 'content',
						'value'       => '',
						'description' => esc_html__( 'Enter the content of this box', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
					),
				)
			)
		);

		vc_map(
			array(
				'name'     => esc_html__( 'Amwal Portfolio Advisors', 'amwal' ),
				'base'     => 'amwal_portfolio_advisors',
				'class'    => '',
				'category' => esc_html__( 'Amwal', 'amwal' ),
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title of content', 'amwal' ),
					),
					array(
						'type'        => 'textarea_html',
						'heading'     => esc_html__( 'Description', 'amwal' ),
						'param_name'  => 'content',
						'value'       => '',
						'description' => esc_html__( 'Enter the content of this box', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
					),
				)
			)
		);

		// Add shortcode About
		vc_map(
			array(
				'name'     => esc_html__( 'About', 'amwal' ),
				'base'     => 'amwal_about',
				'class'    => '',
				'category' => esc_html__( 'Amwal', 'amwal' ),
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title content', 'amwal' ),
					),
					array(
						'type'        => 'textarea_html',
						'heading'     => esc_html__( 'Description', 'amwal' ),
						'param_name'  => 'content',
						'value'       => '',
						'description' => esc_html__( 'Enter a short description for section', 'amwal' ),
					),
					array(
						'type'       => 'attach_image',
						'heading'    => esc_html__( 'About Image', 'amwal' ),
						'param_name' => 'image',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'amwal' ),
					),
				),
			)
		);

		// Add shortcode About
		vc_map(
			array(
				'name'     => esc_html__( 'About 2', 'amwal' ),
				'base'     => 'amwal_about_2',
				'class'    => '',
				'category' => esc_html__( 'Amwal', 'amwal' ),
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title content', 'amwal' ),
					),
					array(
						'type'        => 'textarea_html',
						'heading'     => esc_html__( 'Description', 'amwal' ),
						'param_name'  => 'content',
						'value'       => '',
						'description' => esc_html__( 'Enter a short description for section', 'amwal' ),
					),
					array(
						'type'       => 'attach_image',
						'heading'    => esc_html__( 'About Image', 'amwal' ),
						'param_name' => 'image',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Image Size', 'amwal' ),
						'param_name'  => 'image_size',
						'value'       => '',
						'description' => esc_html__( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 970x534 (Width x Height)).', 'amwal' ),
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Video file URL', 'amwal' ),
						'param_name' => 'video',
						'value'      => '',
					),
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Light Skin', 'amwal' ),
						'param_name' => 'light_skin',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'amwal' ),
					),
				),
			)
		);

		// Add Call to Coming soon shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Coming Soon', 'amwal' ),
				'base'     => 'amwal_coming_soon',
				'class'    => '',
				'category' => esc_html__( 'Content', 'amwal' ),
				'params'   => array(
					array(
						'type'       => 'attach_image',
						'heading'    => esc_html__( 'Comming Logo', 'amwal' ),
						'param_name' => 'image',
					),
					array(
						'type'       => 'textarea_html',
						'heading'    => esc_html__( 'Title', 'amwal' ),
						'param_name' => 'content',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Date', 'amwal' ),
						'param_name'  => 'date',
						'value'       => '',
						'description' => esc_html__( 'Enter the date by format: YYYY/MM/DD', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'amwal' ),
					)
				),
			)
		);

		vc_map(
			array(
				'name'     => esc_html__( 'Socials', 'amwal' ),
				'base'     => 'amwal_socials',
				'class'    => '',
				'category' => esc_html__( 'Content', 'amwal' ),
				'params'   => array(
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Title', 'amwal' ),
						'param_name' => 'title',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Facebook URL', 'amwal' ),
						'param_name' => 'facebook',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Twitter URL', 'amwal' ),
						'param_name' => 'twitter',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Google Plus URL', 'amwal' ),
						'param_name' => 'google-plus',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Linkedin URL', 'amwal' ),
						'param_name' => 'linkedin',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Behance URL', 'amwal' ),
						'param_name' => 'behance',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Instagram URL', 'amwal' ),
						'param_name' => 'instagram',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Skype URL', 'amwal' ),
						'param_name' => 'skype',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Apple URL', 'amwal' ),
						'param_name' => 'apple',
						'value'      => '',
					),

					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Youtube URL', 'amwal' ),
						'param_name' => 'youtube',
						'value'      => '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'value'       => '',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'amwal' ),
					)
				),
			)
		);


		// Add instagram shortcode
		vc_map(
			array(
				'name'     => esc_html__( 'Amwal Partner', 'amwal' ),
				'base'     => 'amwal_partner',
				'class'    => '',
				'category' => esc_html__( 'Content', 'amwal' ),
				'params'   => array(
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Image', 'amwal' ),
						'param_name'  => 'image',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Title', 'amwal' ),
						'param_name'  => 'title',
						'value'       => '',
						'description' => esc_html__( 'Enter the title content', 'amwal' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Subtitle', 'amwal' ),
						'param_name'  => 'subtitle',
						'value'       => '',
						'description' => esc_html__( 'Enter the subtitle', 'amwal' ),

					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Address', 'amwal' ),
						'param_name'  => 'address',
						'value'       => '',
						'description' => esc_html__( 'Enter the address of partner', 'amwal' ),

					),
					array(
						'type'        => 'textarea_html',
						'heading'     => esc_html__( 'Description', 'amwal' ),
						'param_name'  => 'content',
						'description' => esc_html__( 'Enter the description of section title', 'amwal' ),

					),
					array(
						'type'       => 'vc_link',
						'heading'    => esc_html__( 'Link', 'amwal' ),
						'param_name' => 'link',
						'value'      => '',
					),

					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'amwal' ),
					),
				),
			)

		);


		vc_map(
			array(
				'name'            => esc_html__( 'Google MultiMaps', 'amwal' ),
				'base'            => 'amwal_multimaps',
				'as_parent'       => array( 'only' => 'amwal_gmap' ),
				'content_element' => true,
				'params'          => array(
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Api Key', 'amwal' ),
						'param_name'  => 'api_key',
						'value'       => '',
						'description' => sprintf( __( 'Please go to <a href="%s">Google Maps APIs</a> to get a key', 'amwal' ), esc_url( 'https://developers.google.com/maps/documentation/javascript/get-api-key#get-an-api-key' ) ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'amwal' ),
						'param_name' => 'style',
						'value'      => array(
							esc_html__( 'Style 1', 'amwal' ) => '1',
							esc_html__( 'Style 2', 'amwal' ) => '2',
						),
					),
					array(
						'type'        => 'attach_image',
						'heading'     => esc_html__( 'Marker', 'amwal' ),
						'param_name'  => 'marker',
						'value'       => '',
						'description' => esc_html__( 'Select an image from media library', 'amwal' ),
					),

					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Width(px)', 'amwal' ),
						'param_name' => 'width',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Height(px)', 'amwal' ),
						'param_name' => 'height',
						'value'      => '450',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Zoom', 'amwal' ),
						'param_name' => 'zoom',
						'value'      => '13',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra class name', 'amwal' ),
						'param_name'  => 'el_class',
						'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file . ', 'amwal' ),
					),
				),
				'js_view'         => 'VcColumnView'
			)
		);

		vc_map(
			array(
				'name'            => esc_html__( 'Google Map', 'amwal' ),
				'base'            => 'amwal_gmap',
				'content_element' => true,
				'as_child'        => array( 'only' => 'amwal_multimaps' ),
				'params'          => array(
					array(
						'type'       => 'textarea',
						'heading'    => esc_html__( 'Address', 'amwal' ),
						'param_name' => 'address',
						'value'      => '',
					),
					array(
						'type'       => 'textarea_html',
						'heading'    => esc_html__( 'Content', 'amwal' ),
						'param_name' => 'content',
						'value'      => '',
					),
				)
			)
		);

	}

	/**
	 * Get categories
	 *
	 * @return array|string
	 */
	function get_categories( $taxonomy = 'category' ) {
		$output[esc_html__( 'All', 'amwal' )] = '';
		$categories                           = get_terms( $taxonomy );
		if ( $categories ) {
			foreach ( $categories as $category ) {
				if ( $category ) {
					$output[$category->name] = $category->slug;
				}
			}
		}

		return $output;
	}

	/**
	 * Get taxonomies
	 *
	 * @return array|string
	 */
	function get_teamgroups() {
		$output[esc_html__( 'All', 'amwal' )] = '';
		$taxonomies                           = get_terms( 'team_group' );
		if ( ! is_wp_error( $taxonomies ) && $taxonomies ) {
			foreach ( $taxonomies as $taxonomy ) {
				$output[$taxonomy->name] = $taxonomy->term_id;
			}
		}

		return $output;
	}

	/**
	 * Return setting UI for icon param type
	 *
	 * @param  array  $settings
	 * @param  string $value
	 *
	 * @return string
	 */
	function icon_param( $settings, $value ) {
		// Generate dependencies if there are any
		$icons = array();
		foreach ( $this->icons as $icon ) {
			$icons[] = sprintf(
				'<i data-icon="%1$s" class="%1$s %2$s"></i>',
				$icon,
				$icon == $value ? 'selected' : ''
			);
		}

		return sprintf(
			'<div class="icon_block">
				<span class="icon-preview" ><i class="%s" ></i ></span>
				<input type = "text" class="icon-search" placeholder = "%s">
				<input type = "hidden" name = "%s" value = "%s" class="wpb_vc_param_value wpb-textinput %s %s_field">
				<div class="icon-selector" >%s </div>
			</div > ',
			esc_attr( $value ),
			esc_attr__( 'Quick Search', 'amwal' ),
			esc_attr( $settings['param_name'] ),
			esc_attr( $value ),
			esc_attr( $settings['param_name'] ),
			esc_attr( $settings['type'] ),
			implode( '', $icons )
		);

	}
}


if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_amwal_services extends WPBakeryShortCodesContainer {
	}

	class WPBakeryShortCode_amwal_contacts_info extends WPBakeryShortCodesContainer {
	}

	class WPBakeryShortCode_amwal_planning_steps extends WPBakeryShortCodesContainer {
	}

	class WPBakeryShortCode_amwal_line_charts extends WPBakeryShortCodesContainer {
	}

	class WPBakeryShortCode_amwal_bar_charts extends WPBakeryShortCodesContainer {
	}

	class WPBakeryShortCode_amwal_multimaps extends WPBakeryShortCodesContainer {
	}

	class WPBakeryShortCode_amwal_abouts_carousel extends WPBakeryShortCodesContainer {
	}

}

if ( class_exists( 'WPBakeryShortCode' ) ) {
	class WPBakeryShortCode_amwal_service extends WPBakeryShortCode {
	}

	class WPBakeryShortCode_amwal_contact_info extends WPBakeryShortCode {
	}

	class WPBakeryShortCode_amwal_planning_step extends WPBakeryShortCode {
	}

	class WPBakeryShortCode_amwal_line_chart extends WPBakeryShortCode {
	}

	class WPBakeryShortCode_amwal_bar_chart extends WPBakeryShortCode {
	}

	class WPBakeryShortCode_amwal_gmap extends WPBakeryShortCode {
	}

	class WPBakeryShortCode_amwal_about_carousel extends WPBakeryShortCode {
	}
}

