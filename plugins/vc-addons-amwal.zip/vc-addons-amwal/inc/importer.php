<?php
/**
 * Hooks for importer
 *
 * @package FactoryPlus
 */


/**
 * Importer the demo content
 *
 * @since  1.0
 *
 */
function amwal_vc_addons_importer() {
	return array(
		array(
			'name'       => 'Amwal Home 1',
			'preview'    => 'http://creative-wp.com/demos/amwal/importer/home-page-1/preview1.jpg',
			'content'    => 'http://creative-wp.com/demos/amwal/importer/demo-content.xml',
			'customizer' => 'http://creative-wp.com/demos/amwal/importer/home-page-1/customizer.dat',
			'widgets'    => 'http://creative-wp.com/demos/amwal/importer/home-page-1/widgets.wie',
			'sliders'    => 'http://creative-wp.com/demos/amwal/importer/home-page-1/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Page 1',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
				'footer'  => 'footer-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 360,
					'height' => 485,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 360,
					'height' => 540,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Amwal Home 2',
			'preview'    => 'http://creative-wp.com/demos/amwal/importer/home-page-2/preview2.jpg',
			'content'    => 'http://creative-wp.com/demos/amwal/importer/demo-content.xml',
			'customizer' => 'http://creative-wp.com/demos/amwal/importer/home-page-2/customizer.dat',
			'widgets'    => 'http://creative-wp.com/demos/amwal/importer/home-page-2/widgets.wie',
			'sliders'    => 'http://creative-wp.com/demos/amwal/importer/home-page-2/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Page 2',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
				'footer'  => 'footer-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 360,
					'height' => 485,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 360,
					'height' => 540,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Amwal Home 3',
			'preview'    => 'http://creative-wp.com/demos/amwal/importer/home-page-3/preview3.jpg',
			'content'    => 'http://creative-wp.com/demos/amwal/importer/demo-content.xml',
			'customizer' => 'http://creative-wp.com/demos/amwal/importer/home-page-3/customizer.dat',
			'widgets'    => 'http://creative-wp.com/demos/amwal/importer/home-page-3/widgets.wie',
			'sliders'    => 'http://creative-wp.com/demos/amwal/importer/home-page-3/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Page 3',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
				'footer'  => 'footer-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 360,
					'height' => 485,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 360,
					'height' => 540,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Amwal Home 4',
			'preview'    => 'http://creative-wp.com/demos/amwal/importer/home-page-4/preview4.jpg',
			'content'    => 'http://creative-wp.com/demos/amwal/importer/demo-content.xml',
			'customizer' => 'http://creative-wp.com/demos/amwal/importer/home-page-4/customizer.dat',
			'widgets'    => 'http://creative-wp.com/demos/amwal/importer/home-page-4/widgets.wie',
			'sliders'    => 'http://creative-wp.com/demos/amwal/importer/home-page-4/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Page 4',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
				'footer'  => 'footer-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 360,
					'height' => 485,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 360,
					'height' => 540,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Amwal Home 5',
			'preview'    => 'http://creative-wp.com/demos/amwal/importer/home-page-5/preview5.jpg',
			'content'    => 'http://creative-wp.com/demos/amwal/importer/demo-content.xml',
			'customizer' => 'http://creative-wp.com/demos/amwal/importer/home-page-5/customizer.dat',
			'widgets'    => 'http://creative-wp.com/demos/amwal/importer/home-page-5/widgets.wie',
			'sliders'    => 'http://creative-wp.com/demos/amwal/importer/home-page-5/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Page 5',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
				'footer'  => 'footer-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 360,
					'height' => 485,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 360,
					'height' => 540,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Amwal Home 6',
			'preview'    => 'http://creative-wp.com/demos/amwal/importer/home-page-6/preview6.jpg',
			'content'    => 'http://creative-wp.com/demos/amwal/importer/demo-content.xml',
			'customizer' => 'http://creative-wp.com/demos/amwal/importer/home-page-6/customizer.dat',
			'widgets'    => 'http://creative-wp.com/demos/amwal/importer/home-page-6/widgets.wie',
			'sliders'    => 'http://creative-wp.com/demos/amwal/importer/home-page-6/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Page 6',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
				'footer'  => 'footer-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 360,
					'height' => 485,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 360,
					'height' => 540,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Amwal Home 7',
			'preview'    => 'http://creative-wp.com/demos/amwal/importer/home-page-7/preview7.jpg',
			'content'    => 'http://creative-wp.com/demos/amwal/importer/demo-content.xml',
			'customizer' => 'http://creative-wp.com/demos/amwal/importer/home-page-7/customizer.dat',
			'widgets'    => 'http://creative-wp.com/demos/amwal/importer/home-page-7/widgets.wie',
			'sliders'    => 'http://creative-wp.com/demos/amwal/importer/home-page-7/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Page 7',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
				'footer'  => 'footer-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 360,
					'height' => 485,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 360,
					'height' => 540,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Amwal Home 8',
			'preview'    => 'http://creative-wp.com/demos/amwal/importer/home-page-8/preview8.jpg',
			'content'    => 'http://creative-wp.com/demos/amwal/importer/demo-content.xml',
			'customizer' => 'http://creative-wp.com/demos/amwal/importer/home-page-8/customizer.dat',
			'widgets'    => 'http://creative-wp.com/demos/amwal/importer/home-page-8/widgets.wie',
			'sliders'    => 'http://creative-wp.com/demos/amwal/importer/home-page-8/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Page 8',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
				'footer'  => 'footer-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 360,
					'height' => 485,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 360,
					'height' => 540,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Amwal Home 9',
			'preview'    => 'http://creative-wp.com/demos/amwal/importer/home-page-9/preview9.jpg',
			'content'    => 'http://creative-wp.com/demos/amwal/importer/demo-content.xml',
			'customizer' => 'http://creative-wp.com/demos/amwal/importer/home-page-9/customizer.dat',
			'widgets'    => 'http://creative-wp.com/demos/amwal/importer/home-page-9/widgets.wie',
			'sliders'    => 'http://creative-wp.com/demos/amwal/importer/home-page-9/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Page 9',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
				'footer'  => 'footer-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 360,
					'height' => 485,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 360,
					'height' => 540,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),
		array(
			'name'       => 'Amwal Home 10',
			'preview'    => 'http://creative-wp.com/demos/amwal/importer/home-page-10/preview10.jpg',
			'content'    => 'http://creative-wp.com/demos/amwal/importer/demo-content.xml',
			'customizer' => 'http://creative-wp.com/demos/amwal/importer/home-page-10/customizer.dat',
			'widgets'    => 'http://creative-wp.com/demos/amwal/importer/home-page-10/widgets.wie',
			'sliders'    => 'http://creative-wp.com/demos/amwal/importer/home-page-10/sliders.zip',
			'pages'      => array(
				'front_page' => 'Home Page 10',
				'blog'       => 'Blog',
				'shop'       => 'Shop',
				'cart'       => 'Cart',
				'checkout'   => 'Checkout',
				'my_account' => 'My Account',
			),
			'menus'      => array(
				'primary' => 'primary-menu',
				'footer'  => 'footer-menu',
			),
			'options'    => array(
				'shop_catalog_image_size'   => array(
					'width'  => 360,
					'height' => 485,
					'crop'   => 1,
				),
				'shop_single_image_size'    => array(
					'width'  => 360,
					'height' => 540,
					'crop'   => 1,
				),
				'shop_thumbnail_image_size' => array(
					'width'  => 70,
					'height' => 70,
					'crop'   => 1,
				),
			),
		),

	);
}

add_filter( 'soo_demo_packages', 'amwal_vc_addons_importer', 20 );
