<?php
/**
 * Plugin Name: Amwal Visual Composer Addons
 * Plugin URI: http://creativewp.com/amwal
 * Description: Extra elements for Visual Composer. It was built for Amwal theme.
 * Version: 1.0.1
 * Author: creative-wp
 * Author URI: http://creativewp.com/
 * License: GPL2+
 * Text Domain: amwal
 * Domain Path: /lang/
 */
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

if ( ! defined( 'AMWAL_ADDONS_DIR' ) ) {
	define( 'AMWAL_ADDONS_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'AMWAL_ADDONS_URL' ) ) {
	define( 'AMWAL_ADDONS_URL', plugin_dir_url( __FILE__ ) );
}

require_once AMWAL_ADDONS_DIR . '/inc/visual-composer.php';
require_once AMWAL_ADDONS_DIR . '/inc/shortcodes.php';

if( is_admin()) {
	require_once AMWAL_ADDONS_DIR . '/inc/importer.php';
}

/**
 * Init
 */
function amwal_vc_addons_init() {
	load_plugin_textdomain( 'amwal', false, dirname( plugin_basename( __FILE__ ) ) . '/lang' );

	new Amwal_VC;
	new Amwal_Shortcodes;

}

add_action( 'after_setup_theme', 'amwal_vc_addons_init', 20 );
