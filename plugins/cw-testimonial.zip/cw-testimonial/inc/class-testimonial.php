<?php
/**
 * Register Testimonial CPT
 *
 * @package CW Testimonial
 */

/**
 * Class CW_Testimonial
 */
class CW_Testimonial {

	private $post_type = 'testimonial';
	private $taxonomy_type = 'testimonial_category';
	private $option = 'cw_testimonial';

	/**
	 * Construction function
	 *
	 * @since 1.0.0
	 *
	 * @return CW_Testimonial
	 */
	public function __construct() {

		// Add an option to enable the CPT
		add_action( 'admin_init', array( $this, 'settings_api_init' ) );

		// Register custom post type and custom taxonomy
		add_action( 'init', array( $this, 'register_post_type' ) );
		add_action( 'init', array( $this, 'register_taxonomy' ) );

		add_action( 'add_option_' . $this->post_type, 'flush_rewrite_rules' );
		add_action( 'update_option_' . $this->post_type, 'flush_rewrite_rules' );
		add_action( 'publish_' . $this->post_type, 'flush_rewrite_rules' );

		// Handle post columns
		add_filter( 'manage_testimonial_posts_columns', array( $this, 'register_custom_columns' ) );
		add_action( 'manage_testimonial_posts_custom_column', array( $this, 'manage_custom_columns' ), 10, 2 );

		// Adjust CPT archive and custom taxonomies to obey CPT reading setting
		add_filter( 'pre_get_posts', array( $this, 'query_reading_setting' ) );

		// Template redirect
		add_action( 'template_redirect', array( $this, 'template_redirect' ) );
	}

	/**
	 * Register custom post type for testimonails
	 *
	 * @since  1.0.0
	 *
	 * @return void
	 */
	public function register_post_type() {
		// Return if post type is exists
		if ( post_type_exists( $this->post_type ) ) {
			return;
		}

		$testimonial_page_id   = get_option( $this->option . '_page_id' );

		$labels = array(
			'name'               => _x( 'Testimonials', 'Post Type General Name', 'cw-testimonial' ),
			'singular_name'      => _x( 'Testimonial', 'Post Type Singular Name', 'cw-testimonial' ),
			'menu_name'          => __( 'Testimonials', 'cw-testimonial' ),
			'parent_item_colon'  => __( 'Parent Testimonial', 'cw-testimonial' ),
			'all_items'          => __( 'All Testimonial', 'cw-testimonial' ),
			'view_item'          => __( 'View Testimonial', 'cw-testimonial' ),
			'add_new_item'       => __( 'Add New Testimonial', 'cw-testimonial' ),
			'add_new'            => __( 'Add New', 'cw-testimonial' ),
			'edit_item'          => __( 'Edit Testimonial', 'cw-testimonial' ),
			'update_item'        => __( 'Update Testimonial', 'cw-testimonial' ),
			'search_items'       => __( 'Search Testimonial', 'cw-testimonial' ),
			'not_found'          => __( 'Not found', 'cw-testimonial' ),
			'not_found_in_trash' => __( 'Not found in Trash', 'cw-testimonial' ),
		);
		$args   = array(
			'label'               => __( 'Testimonial', 'cw-testimonial' ),
			'description'         => __( 'Create and manage all testimonials', 'cw-testimonial' ),
			'labels'              => $labels,
			'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', ),
			'hierarchical'        => false,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => false,
			'show_in_admin_bar'   => false,
			'menu_position'       => 5,
			'rewrite'             => array( 'slug' => _x( 'testimonial', 'slug', 'cw-testimonial' ) ),
			'can_export'          => true,
			'has_archive'         => $testimonial_page_id && get_option( $testimonial_page_id ) ? get_page_uri( $testimonial_page_id ) : 'testimonial',
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'capability_type'     => 'post',
			'menu_icon'           => 'dashicons-format-quote',
		);
		register_post_type( $this->post_type, $args );
	}

	/**
	 * Register Testimonial category taxonomy
	 *
	 * @since  1.0.0
	 *
	 * @return void
	 */
	public function register_taxonomy() {
		$labels = array(
			'name'              => __( 'Categories', 'cw-testimonial' ),
			'singular_name'     => __( 'Category', 'cw-testimonial' ),
			'search_items'      => __( 'Search Category', 'cw-testimonial' ),
			'all_items'         => __( 'All Categories', 'cw-testimonial' ),
			'parent_item'       => __( 'Parent Category', 'cw-testimonial' ),
			'parent_item_colon' => __( 'Parent Category:', 'cw-testimonial' ),
			'edit_item'         => __( 'Edit Category', 'cw-testimonial' ),
			'update_item'       => __( 'Update Category', 'cw-testimonial' ),
			'add_new_item'      => __( 'Add New Category', 'cw-testimonial' ),
			'new_item_name'     => __( 'New Category Name', 'cw-testimonial' ),
			'menu_name'         => _x( 'Categories', 'Category Taxonomy Menu', 'cw-testimonial' ),
		);

		$args = array(
			'labels'            => $labels,
			'public'            => true,
			'hierarchical'      => true,
			'show_admin_column' => false,
			'show_in_nav_menus' => false,
			'rewrite'           => array(
				'slug'         => apply_filters( 'cw_testimonial_category_slug', 'testimonial-cat' ),
				'with_front'   => true,
				'hierarchical' => false,
			),
		);

		register_taxonomy( $this->taxonomy_type, $this->post_type, $args );
	}

	/**
	 * Add custom column to manage testimonials screen
	 * Add image column
	 *
	 * @since  1.0.0
	 *
	 * @param  array $columns Default columns
	 *
	 * @return array
	 */
	public function register_custom_columns( $columns ) {
		$cb          = array_slice( $columns, 0, 1 );
		$cb['image'] = __( 'Image', 'cw-testimonial' );

		return array_merge( $cb, $columns );
	}

	/**
	 * Handle custom column display
	 *
	 * @since  1.0.0
	 *
	 * @param  string $column
	 * @param  int    $post_id
	 *
	 * @return void
	 */
	public function manage_custom_columns( $column, $post_id ) {
		if ( 'image' == $column ) {
			echo get_the_post_thumbnail( $post_id, array( 50, 50 ) );
		}
	}

	/**
	 * Add  field in 'Settings' > 'Reading'
	 * for enabling CPT functionality.
	 */
	public function settings_api_init() {

		// Reading settings
		add_settings_section(
			'creative_testimonial_section',
			'<span id="testimonial-options">' . esc_html__( 'Testimonial', 'cw-testimonial' ) . '</span>',
			array( $this, 'reading_section_html' ),
			'reading'
		);

		add_settings_field(
			$this->option . '_page_id',
			'<span class="testimonial-options">' . esc_html__( 'Testimonial page', 'cw-testimonial' ) . '</span>',
			array( $this, 'page_field_html' ),
			'reading',
			'creative_testimonial_section'
		);

		register_setting(
			'reading',
			$this->option . '_page_id',
			'intval'
		);

	}

	/**
	 * Add reading setting section
	 */
	public function reading_section_html() {
		?>
		<p>
			<?php esc_html_e( 'Use these settings to control custom post type content', 'cw-testimonial' ); ?>
		</p>
		<?php
	}

	/**
	 * HTML code to display a drop-down of option for testimonial page
	 */
	public function page_field_html() {
		wp_dropdown_pages( array(
			'selected'          => get_option( $this->option . '_page_id' ),
			'name'              => $this->option . '_page_id',
			'show_option_none'  => esc_html__( '&mdash; Select &mdash;', 'cw-testimonial' ),
			'option_none_value' => 0,
		) );
	}

	/**
	 * Follow CPT reading setting on CPT archive and taxonomy pages
	 *
	 * @TODO Check if testimonial archive is set as front page. See WC_Query->pre_get_posts
	 */
	function query_reading_setting( $query ) {

		if ( ! is_admin() && $query->is_page() ) {
			$testimonial_page_id = intval( get_option( $this->option . '_page_id' ) );

			// Fix for verbose page rules
			if ( $GLOBALS['wp_rewrite']->use_verbose_page_rules && isset( $query->queried_object->ID ) && $query->queried_object->ID === $testimonial_page_id ) {
				$query->set( 'post_type', $this->post_type );
				$query->set( 'page', '' );
				$query->set( 'pagename', '' );

				// Fix conditional Functions
				$query->is_archive           = true;
				$query->is_post_type_archive = true;
				$query->is_singular          = false;
				$query->is_page              = false;
			}
		}
	}

	/**
	 * Handle redirects before content is output - hooked into template_redirect so is_page works.
	 */
	public function template_redirect() {
		if ( ! is_page() ) {
			return;
		}

		// When default permalinks are enabled, redirect testimonial page to post type archive url
		if ( ! empty( $_GET['page_id'] ) && '' === get_option( 'permalink_structure' ) && $_GET['page_id'] == get_option( $this->option . '_page_id' ) ) {
			wp_safe_redirect( get_post_type_archive_link( $this->post_type ) );
			exit;
		}
	}

}
