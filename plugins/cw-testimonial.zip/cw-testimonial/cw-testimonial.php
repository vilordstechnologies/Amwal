<?php
/*
 * Plugin Name: CW Testimonial
 * Version: 1.0.1
 * Plugin URI: http://creativewp.com
 * Description: Create and manage testimonial in the easiest way.
 * Author: creative-wp
 * Author URI: http://creativewp.com
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Define constants **/
define( 'CW_TESTIMONIAL_VER', '1.0.0' );
define( 'CW_TESTIMONIAL_DIR', plugin_dir_path( __FILE__ ) );
define( 'CW_TESTIMONIAL_URL', plugin_dir_url( __FILE__ ) );

/** Load files **/
require_once CW_TESTIMONIAL_DIR . '/inc/class-testimonial.php';
require_once CW_TESTIMONIAL_DIR . '/inc/frontend.php';

new CW_Testimonial;

/**
 * Load language file
 *
 * @since  1.0.0
 *
 * @return void
 */
function cw_testimonial_load_text_domain() {
	load_plugin_textdomain( 'cw-testimonial', false, dirname( plugin_basename( __FILE__ ) ) . '/lang/' );
}

add_action( 'init', 'cw_testimonial_load_text_domain' );
