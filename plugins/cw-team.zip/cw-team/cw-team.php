<?php
/*
 * Plugin Name: CW Team
 * Version: 1.0.1
 * Plugin URI: http://creativewp.com
 * Description: Create and manage your team member present them in the easiest way.
 * Author: creative-wp
 * Author URI: http://creativewp.com/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Define constants **/
define( 'CW_TEAM_VER', '1.0.0' );
define( 'CW_TEAM_DIR', plugin_dir_path( __FILE__ ) );
define( 'CW_TEAM_URL', plugin_dir_url( __FILE__ ) );

/** Load files **/
require_once CW_TEAM_DIR . '/inc/class-team-member.php';
require_once CW_TEAM_DIR . '/inc/frontend.php';

new CW_Team_Member;

/**
 * Add image sizes
 *
 * @since  1.0.0
 *
 * @return void
 */
function cw_team_image_sizes_init() {
	add_image_size( 'team-member', 300, 300, true );
}

add_action( 'init', 'cw_team_image_sizes_init' );

/**
 * Load language file
 *
 * @since  1.0.0
 *
 * @return void
 */
function cw_team_load_text_domain() {
	load_plugin_textdomain( 'cw-team', false, dirname( plugin_basename( __FILE__ ) ) . '/lang/' );
}

add_action( 'init', 'cw_team_load_text_domain' );
