<?php
/*
 * Plugin Name: CW Portfolio Management
 * Version: 1.0.1
 * Plugin URI: http://creativewp.com
 * Description: Create and manage your works you have done and present them in the easiest way.
 * Author: creative-wp
 * Author URI: http://creativewp.com/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CW_PORTFOLIO_DIR', plugin_dir_path( __FILE__ ) );
define( 'CW_PORTFOLIO_URL', plugin_dir_url( __FILE__ ) );

/** Load files */
require_once CW_PORTFOLIO_DIR . '/inc/class-portfolio.php';
require_once CW_PORTFOLIO_DIR . '/inc/frontend.php';

new CW_Portfolio;


/**
 * Load language file
 *
 * @since  1.0.0
 *
 * @return void
 */
function cf_portfolio_load_text_domain() {
	load_plugin_textdomain( 'cf-portfolio', false, dirname( plugin_basename( __FILE__ ) ) . '/lang/' );
}

add_action( 'init', 'cf_portfolio_load_text_domain' );
